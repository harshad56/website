import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Code, FileCode, Terminal } from 'lucide-react';

function CPPTutorial() {
  const topics = [
    {
      title: "C++ Fundamentals",
      description: "Learn the basics of C++ programming",
      icon: BookOpen,
      lessons: [
        { title: "Introduction to C++", path: "/tutorials/cpp/introduction" },
        { title: "Setting up C++", path: "/tutorials/cpp/setup" },
        { title: "First C++ Program", path: "/tutorials/cpp/first-program" }
      ]
    },
    {
      title: "Object-Oriented C++",
      description: "Master OOP concepts in C++",
      icon: Code,
      lessons: [
        { title: "Classes and Objects", path: "/tutorials/cpp/classes" },
        { title: "Inheritance", path: "/tutorials/cpp/inheritance" },
        { title: "Polymorphism", path: "/tutorials/cpp/polymorphism" }
      ]
    },
    {
      title: "Advanced C++",
      description: "Advanced C++ features and concepts",
      icon: FileCode,
      lessons: [
        { title: "Templates", path: "/tutorials/cpp/templates" },
        { title: "STL", path: "/tutorials/cpp/stl" },
        { title: "Smart Pointers", path: "/tutorials/cpp/smart-pointers" }
      ]
    },
    {
      title: "C++ Projects",
      description: "Build real-world C++ applications",
      icon: Terminal,
      lessons: [
        { title: "Data Structures", path: "/tutorials/cpp/data-structures" },
        { title: "Algorithms", path: "/tutorials/cpp/algorithms" },
        { title: "Game Development", path: "/tutorials/cpp/game-dev" }
      ]
    }
  ];

  return (
    <div>
      <h1 className="text-4xl font-bold text-white mb-8">C++ Programming Tutorial</h1>
      <p className="text-xl text-white/70 mb-12">
        Master C++ programming from basics to advanced topics
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        {topics.map((topic, index) => (
          <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
            <div className="flex items-start mb-4">
              <topic.icon className="h-8 w-8 text-purple-400 mr-4" />
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">{topic.title}</h3>
                <p className="text-white/70 mb-4">{topic.description}</p>
              </div>
            </div>
            <ul className="space-y-2">
              {topic.lessons.map((lesson, lessonIndex) => (
                <li key={lessonIndex} className="flex items-center">
                  <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                  <Link 
                    to={lesson.path}
                    className="text-white/70 hover:text-purple-400 transition-colors"
                  >
                    {lesson.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-white/5 rounded-xl p-8 backdrop-blur-lg border border-white/10">
        <h2 className="text-2xl font-bold text-white mb-4">Practice C++</h2>
        <p className="text-white/70 mb-6">
          Test your C++ skills with interactive coding challenges
        </p>
        <Link 
          to="/playground" 
          className="inline-flex items-center px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
        >
          Open Code Playground
        </Link>
      </div>
    </div>
  );
}

export default CPPTutorial;