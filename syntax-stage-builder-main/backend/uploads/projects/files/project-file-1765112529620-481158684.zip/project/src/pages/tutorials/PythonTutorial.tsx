import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Code, FileCode, Terminal } from 'lucide-react';

function PythonTutorial() {
  const topics = [
    {
      title: "Python Basics",
      description: "Learn the fundamentals of Python programming",
      icon: BookOpen,
      lessons: [
        { title: "Introduction to Python", path: "/tutorials/python/introduction" },
        { title: "Python Installation", path: "/tutorials/python/installation" },
        { title: "First Python Program", path: "/tutorials/python/first-program" }
      ]
    },
    {
      title: "Data Structures",
      description: "Master Python's built-in data structures",
      icon: Code,
      lessons: [
        { title: "Lists and Tuples", path: "/tutorials/python/lists-tuples" },
        { title: "Dictionaries", path: "/tutorials/python/dictionaries" },
        { title: "Sets", path: "/tutorials/python/sets" }
      ]
    },
    {
      title: "Advanced Python",
      description: "Advanced Python concepts and features",
      icon: FileCode,
      lessons: [
        { title: "Object-Oriented Programming", path: "/tutorials/python/oop" },
        { title: "Decorators", path: "/tutorials/python/decorators" },
        { title: "Generators", path: "/tutorials/python/generators" }
      ]
    },
    {
      title: "Python Libraries",
      description: "Essential Python libraries and frameworks",
      icon: Terminal,
      lessons: [
        { title: "NumPy Basics", path: "/tutorials/python/numpy" },
        { title: "Pandas Fundamentals", path: "/tutorials/python/pandas" },
        { title: "Matplotlib", path: "/tutorials/python/matplotlib" }
      ]
    }
  ];

  return (
    <div>
      <h1 className="text-4xl font-bold text-white mb-8">Python Programming Tutorial</h1>
      <p className="text-xl text-white/70 mb-12">
        Learn Python from basics to advanced concepts
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        {topics.map((topic, index) => (
          <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
            <div className="flex items-start mb-4">
              <topic.icon className="h-8 w-8 text-purple-400 mr-4" />
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">{topic.title}</h3>
                <p className="text-white/70 mb-4">{topic.description}</p>
              </div>
            </div>
            <ul className="space-y-2">
              {topic.lessons.map((lesson, lessonIndex) => (
                <li key={lessonIndex} className="flex items-center">
                  <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                  <Link 
                    to={lesson.path}
                    className="text-white/70 hover:text-purple-400 transition-colors"
                  >
                    {lesson.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-white/5 rounded-xl p-8 backdrop-blur-lg border border-white/10">
        <h2 className="text-2xl font-bold text-white mb-4">Practice Python</h2>
        <p className="text-white/70 mb-6">
          Test your Python skills with interactive coding challenges
        </p>
        <Link 
          to="/playground" 
          className="inline-flex items-center px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
        >
          Open Code Playground
        </Link>
      </div>
    </div>
  );
}

export default PythonTutorial;