import React from 'react';
import { MapPin, Building2, DollarSign, Briefcase, Search, Clock, GraduationCap } from 'lucide-react';

function Jobs() {
  const jobs = [
    {
      title: "Senior Full Stack Developer",
      company: "TechCorp Solutions",
      location: "San Francisco, CA",
      salary: "$120K - $180K",
      type: "Full-time",
      experience: "5+ years",
      skills: ["React", "Node.js", "PostgreSQL", "AWS"],
      posted: "2 days ago"
    },
    {
      title: "Machine Learning Engineer",
      company: "AI Innovations",
      location: "Remote",
      salary: "$140K - $200K",
      type: "Full-time",
      experience: "3+ years",
      skills: ["Python", "TensorFlow", "PyTorch", "MLOps"],
      posted: "1 day ago"
    },
    {
      title: "DevOps Engineer",
      company: "Cloud Systems Inc",
      location: "New York, NY",
      salary: "$130K - $190K",
      type: "Full-time",
      experience: "4+ years",
      skills: ["Kubernetes", "Docker", "CI/CD", "AWS"],
      posted: "3 days ago"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-white mb-4">Tech Jobs</h1>
        <p className="text-xl text-white/70">Find your dream job in tech</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Job title or keyword"
              className="w-full pl-10 pr-4 py-3 rounded-lg bg-white/10 border border-white/20 focus:outline-none focus:border-purple-500 text-white placeholder-white/60"
            />
            <Search className="absolute left-3 top-3.5 h-5 w-5 text-white/60" />
          </div>
          <div className="relative">
            <input
              type="text"
              placeholder="Location"
              className="w-full pl-10 pr-4 py-3 rounded-lg bg-white/10 border border-white/20 focus:outline-none focus:border-purple-500 text-white placeholder-white/60"
            />
            <MapPin className="absolute left-3 top-3.5 h-5 w-5 text-white/60" />
          </div>
          <div className="relative">
            <select className="w-full pl-10 pr-4 py-3 rounded-lg bg-white/10 border border-white/20 focus:outline-none focus:border-purple-500 text-white appearance-none">
              <option value="">Experience Level</option>
              <option value="entry">Entry Level</option>
              <option value="mid">Mid Level</option>
              <option value="senior">Senior Level</option>
            </select>
            <GraduationCap className="absolute left-3 top-3.5 h-5 w-5 text-white/60" />
          </div>
          <button className="bg-purple-500 text-white px-6 py-3 rounded-lg hover:bg-purple-600 transition-colors">
            Search Jobs
          </button>
        </div>
      </div>

      {/* Job Listings */}
      <div className="space-y-6">
        {jobs.map((job, index) => (
          <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10 hover:border-purple-500/50 transition-colors">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between">
              <div>
                <h2 className="text-2xl font-semibold text-white mb-2">{job.title}</h2>
                <div className="flex flex-wrap gap-4 text-white/70 mb-4">
                  <div className="flex items-center">
                    <Building2 className="w-4 h-4 mr-2" />
                    {job.company}
                  </div>
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-2" />
                    {job.location}
                  </div>
                  <div className="flex items-center">
                    <DollarSign className="w-4 h-4 mr-2" />
                    {job.salary}
                  </div>
                  <div className="flex items-center">
                    <Briefcase className="w-4 h-4 mr-2" />
                    {job.type}
                  </div>
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-2" />
                    {job.posted}
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 mb-4">
                  {job.skills.map((skill, skillIndex) => (
                    <span key={skillIndex} className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded-full text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div className="mt-4 md:mt-0">
                <button className="px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">
                  Apply Now
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Jobs;