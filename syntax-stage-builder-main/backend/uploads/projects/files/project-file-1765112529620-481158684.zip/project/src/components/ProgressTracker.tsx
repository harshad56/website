import React from 'react';
import { CheckCircle, Circle } from 'lucide-react';

interface ProgressTrackerProps {
  steps: string[];
  currentStep: number;
}

function ProgressTracker({ steps, currentStep }: ProgressTrackerProps) {
  return (
    <div className="mb-8">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <React.Fragment key={index}>
            <div className="flex flex-col items-center">
              <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                index <= currentStep 
                  ? 'bg-purple-500 text-white' 
                  : 'bg-white/10 text-white/50'
              }`}>
                {index < currentStep ? (
                  <CheckCircle className="h-6 w-6" />
                ) : (
                  <Circle className="h-6 w-6" />
                )}
              </div>
              <span className={`mt-2 text-sm ${
                index <= currentStep ? 'text-white' : 'text-white/50'
              }`}>
                {step}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div className={`flex-1 h-0.5 mx-4 ${
                index < currentStep ? 'bg-purple-500' : 'bg-white/10'
              }`} />
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

export default ProgressTracker;