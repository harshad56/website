import React from 'react';
import { Terminal, Download, CheckCircle, AlertCircle } from 'lucide-react';
import TutorialNavigation from '../../../components/TutorialNavigation';
import ProgressTracker from '../../../components/ProgressTracker';

function JavaEnvironment() {
  const steps = [
    "Introduction",
    "Environment Setup",
    "First Program",
    "Variables",
    "Control Flow"
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <ProgressTracker steps={steps} currentStep={1} />
      
      <h1 className="text-3xl font-bold text-white mb-6">Setting up Java Environment</h1>

      <div className="space-y-8">
        {/* Overview */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Getting Started</h2>
          <p className="text-white/80 leading-relaxed">
            Setting up your Java development environment is the first step in becoming a Java developer. We'll guide you through installing the Java Development Kit (JDK) and an Integrated Development Environment (IDE).
          </p>
        </section>

        {/* JDK Installation */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Installing the JDK</h2>
          
          <div className="space-y-6">
            {/* Step 1 */}
            <div className="bg-white/5 rounded-lg p-4">
              <h3 className="text-lg font-medium text-purple-400 mb-2 flex items-center">
                <span className="bg-purple-500/20 text-purple-400 w-6 h-6 rounded-full flex items-center justify-center mr-2">1</span>
                Download JDK
              </h3>
              <p className="text-white/70 mb-4">Visit the official Oracle website or download OpenJDK</p>
              <button className="flex items-center space-x-2 bg-purple-500/20 text-purple-400 px-4 py-2 rounded-lg hover:bg-purple-500/30 transition-colors">
                <Download className="h-5 w-5" />
                <span>Download JDK</span>
              </button>
            </div>

            {/* Step 2 */}
            <div className="bg-white/5 rounded-lg p-4">
              <h3 className="text-lg font-medium text-purple-400 mb-2 flex items-center">
                <span className="bg-purple-500/20 text-purple-400 w-6 h-6 rounded-full flex items-center justify-center mr-2">2</span>
                Install JDK
              </h3>
              <div className="space-y-2">
                <p className="text-white/70">Follow the installation wizard:</p>
                <ul className="list-disc list-inside text-white/70 space-y-1">
                  <li>Accept the license agreement</li>
                  <li>Choose installation directory</li>
                  <li>Wait for installation to complete</li>
                </ul>
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-white/5 rounded-lg p-4">
              <h3 className="text-lg font-medium text-purple-400 mb-2 flex items-center">
                <span className="bg-purple-500/20 text-purple-400 w-6 h-6 rounded-full flex items-center justify-center mr-2">3</span>
                Set Environment Variables
              </h3>
              <div className="bg-black/50 rounded-lg p-4 mb-4">
                <pre className="text-white/90 overflow-x-auto">
                  <code>{`# Windows
set JAVA_HOME=C:\\Program Files\\Java\\jdk-17
set PATH=%PATH%;%JAVA_HOME%\\bin

# Linux/Mac
export JAVA_HOME=/usr/lib/jvm/java-17
export PATH=$PATH:$JAVA_HOME/bin`}</code>
                </pre>
              </div>
            </div>

            {/* Step 4 */}
            <div className="bg-white/5 rounded-lg p-4">
              <h3 className="text-lg font-medium text-purple-400 mb-2 flex items-center">
                <span className="bg-purple-500/20 text-purple-400 w-6 h-6 rounded-full flex items-center justify-center mr-2">4</span>
                Verify Installation
              </h3>
              <div className="bg-black/50 rounded-lg p-4 mb-4">
                <pre className="text-white/90 overflow-x-auto">
                  <code>{`java -version
javac -version`}</code>
                </pre>
              </div>
            </div>
          </div>
        </section>

        {/* IDE Setup */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Setting up an IDE</h2>
          
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            {[
              {
                name: "IntelliJ IDEA",
                description: "Powerful IDE with advanced features",
                recommended: true
              },
              {
                name: "Eclipse",
                description: "Popular open-source IDE",
                recommended: false
              },
              {
                name: "VS Code",
                description: "Lightweight editor with Java support",
                recommended: false
              }
            ].map((ide, index) => (
              <div key={index} className="bg-white/5 rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-lg font-medium text-purple-400">{ide.name}</h3>
                  {ide.recommended && (
                    <span className="bg-green-500/20 text-green-400 text-sm px-2 py-1 rounded">
                      Recommended
                    </span>
                  )}
                </div>
                <p className="text-white/70">{ide.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Troubleshooting */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Common Issues</h2>
          
          <div className="space-y-4">
            {[
              {
                issue: "'java' is not recognized",
                solution: "Check your PATH environment variable",
                type: "error"
              },
              {
                issue: "JDK version mismatch",
                solution: "Ensure you have the correct JDK version installed",
                type: "warning"
              },
              {
                issue: "IDE not detecting JDK",
                solution: "Configure JDK location in IDE settings",
                type: "warning"
              }
            ].map((issue, index) => (
              <div key={index} className="flex items-start space-x-4 bg-white/5 rounded-lg p-4">
                {issue.type === "error" ? (
                  <AlertCircle className="h-5 w-5 text-red-400 flex-shrink-0" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-yellow-400 flex-shrink-0" />
                )}
                <div>
                  <h3 className="text-lg font-medium text-white">{issue.issue}</h3>
                  <p className="text-white/70">{issue.solution}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <TutorialNavigation
          previousPath="/tutorials/java/what-is-java"
          previousLabel="Previous: What is Java?"
          nextPath="/tutorials/java/first-program"
          nextLabel="Next: First Java Program"
        />
      </div>
    </div>
  );
}

export default JavaEnvironment;