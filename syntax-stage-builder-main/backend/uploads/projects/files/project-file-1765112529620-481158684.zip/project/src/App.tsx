import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import TutorialLayout from './pages/TutorialLayout';
import JavaTutorial from './pages/tutorials/JavaTutorial';
import PythonTutorial from './pages/tutorials/PythonTutorial';
import HTMLTutorial from './pages/tutorials/HTMLTutorial';
import CSSTutorial from './pages/tutorials/CSSTutorial';
import CPPTutorial from './pages/tutorials/CPPTutorial';
import WebDevTutorial from './pages/tutorials/WebDevTutorial';
import CTutorial from './pages/tutorials/CTutorial';
import RTutorial from './pages/tutorials/RTutorial';
import Practice from './pages/Practice';
import Jobs from './pages/Jobs';
import Contests from './pages/Contests';
import SignIn from './pages/SignIn';
import SignUp from './pages/SignUp';
import CourseDetails from './pages/CourseDetails';
import Feedback from './pages/Feedback';
import Search from './pages/Search';
import CodePlayground from './pages/CodePlayground';

// Tutorial pages
import WhatIsJava from './pages/tutorials/java/WhatIsJava';
import JavaEnvironment from './pages/tutorials/java/JavaEnvironment';
import FirstProgram from './pages/tutorials/java/FirstProgram';

function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <Router>
          <div className="min-h-screen bg-[#0A0118] dark:bg-[#0A0118] light:bg-white">
            <Navbar />
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/tutorials" element={<TutorialLayout />}>
                <Route path="java" element={<JavaTutorial />} />
                <Route path="java/what-is-java" element={<WhatIsJava />} />
                <Route path="java/environment-setup" element={<JavaEnvironment />} />
                <Route path="java/first-program" element={<FirstProgram />} />
                <Route path="python" element={<PythonTutorial />} />
                <Route path="html" element={<HTMLTutorial />} />
                <Route path="css" element={<CSSTutorial />} />
                <Route path="cpp" element={<CPPTutorial />} />
                <Route path="web" element={<WebDevTutorial />} />
                <Route path="c" element={<CTutorial />} />
                <Route path="r" element={<RTutorial />} />
              </Route>
              <Route path="/practice" element={<Practice />} />
              <Route path="/jobs" element={<Jobs />} />
              <Route path="/contests" element={<Contests />} />
              <Route path="/signin" element={<SignIn />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="/course/:courseId" element={<CourseDetails />} />
              <Route path="/feedback" element={<Feedback />} />
              <Route path="/search" element={<Search />} />
              <Route path="/playground" element={<CodePlayground />} />
            </Routes>
          </div>
        </Router>
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;