import React from 'react';
import { Code, BookOpen, CheckCircle } from 'lucide-react';
import TutorialNavigation from '../../../components/TutorialNavigation';
import ProgressTracker from '../../../components/ProgressTracker';

function Variables() {
  const steps = [
    "Introduction",
    "Environment Setup",
    "First Program",
    "Variables",
    "Control Flow"
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <ProgressTracker steps={steps} currentStep={3} />
      
      <h1 className="text-3xl font-bold text-white mb-6">Variables and Data Types</h1>

      <div className="space-y-8">
        {/* Introduction */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Understanding Variables</h2>
          <p className="text-white/80 leading-relaxed">
            Variables are containers for storing data values. In Java, variables have specific types that determine what kind of data they can store.
          </p>
        </section>

        {/* Data Types */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Java Data Types</h2>
          
          <div className="space-y-4">
            {[
              {
                type: "Primitive Types",
                examples: [
                  { name: "int", description: "Stores whole numbers", example: "int age = 25;" },
                  { name: "double", description: "Stores decimal numbers", example: "double price = 19.99;" },
                  { name: "boolean", description: "Stores true/false values", example: "boolean isActive = true;" },
                  { name: "char", description: "Stores single characters", example: "char grade = 'A';" }
                ]
              },
              {
                type: "Reference Types",
                examples: [
                  { name: "String", description: "Stores text", example: 'String name = "John";' },
                  { name: "Array", description: "Stores multiple values", example: "int[] numbers = {1, 2, 3};" },
                  { name: "Object", description: "Stores complex data", example: "Person person = new Person();" }
                ]
              }
            ].map((category, index) => (
              <div key={index} className="bg-white/5 rounded-lg p-4">
                <h3 className="text-lg font-medium text-purple-400 mb-4">{category.type}</h3>
                <div className="grid gap-4">
                  {category.examples.map((item, itemIndex) => (
                    <div key={itemIndex} className="bg-black/30 rounded-lg p-4">
                      <div className="flex items-center mb-2">
                        <Code className="h-5 w-5 text-purple-400 mr-2" />
                        <span className="text-white font-medium">{item.name}</span>
                      </div>
                      <p className="text-white/70 mb-2">{item.description}</p>
                      <code className="block bg-black/50 p-2 rounded text-purple-400">{item.example}</code>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Variable Declaration */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Variable Declaration and Initialization</h2>
          
          <div className="bg-black/50 rounded-lg p-4 mb-6">
            <pre className="text-white/90 overflow-x-auto">
              <code>{`// Variable declaration
int number;

// Variable initialization
number = 42;

// Declaration and initialization in one line
String message = "Hello, Java!";

// Multiple variables of the same type
int x = 1, y = 2, z = 3;`}</code>
            </pre>
          </div>
        </section>

        {/* Practice Section */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Practice Exercise</h2>
          
          <div className="space-y-4">
            <p className="text-white/80">Try creating variables of different types:</p>
            
            <div className="space-y-2">
              {[
                "Create variables to store your personal information (name, age, height)",
                "Create variables for a simple calculator program",
                "Practice type conversion between different data types"
              ].map((exercise, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-purple-400" />
                  <span className="text-white/70">{exercise}</span>
                </div>
              ))}
            </div>

            <button className="mt-4 flex items-center space-x-2 bg-purple-500/20 text-purple-400 px-6 py-3 rounded-lg hover:bg-purple-500/30 transition-colors">
              <Code className="h-5 w-5" />
              <span>Open Practice Editor</span>
            </button>
          </div>
        </section>

        <TutorialNavigation
          previousPath="/tutorials/java/first-program"
          previousLabel="Previous: First Java Program"
          nextPath="/tutorials/java/control-flow"
          nextLabel="Next: Control Flow"
        />
      </div>
    </div>
  );
}

export default Variables;