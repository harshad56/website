import React, { useState, useEffect } from 'react';
import { Search as SearchIcon, Book, Code2, Trophy, Briefcase, Tag } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';

function Search() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');
  const location = useLocation();
  const { theme } = useTheme();

  // Get search query from URL
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const q = params.get('q');
    if (q) {
      setSearchQuery(q);
    }
  }, [location]);

  // Expanded search results
  const searchResults = [
    {
      type: 'course',
      title: 'Complete Java Programming',
      description: 'Master Java from basics to advanced concepts',
      path: '/tutorials/java',
      tags: ['Java', 'Programming', 'Backend'],
      icon: Code2
    },
    {
      type: 'tutorial',
      title: 'Python Data Structures',
      description: 'Learn essential data structures in Python',
      path: '/tutorials/python',
      tags: ['Python', 'Data Structures'],
      icon: Book
    },
    {
      type: 'tutorial',
      title: 'Web Development with HTML & CSS',
      description: 'Build modern responsive websites',
      path: '/tutorials/html',
      tags: ['HTML', 'CSS', 'Web Development'],
      icon: Book
    },
    {
      type: 'course',
      title: 'C++ Programming Masterclass',
      description: 'Learn C++ from scratch to advanced',
      path: '/tutorials/cpp',
      tags: ['C++', 'Programming'],
      icon: Code2
    },
    {
      type: 'contest',
      title: 'Weekly Coding Challenge',
      description: 'Test your skills with our weekly challenges',
      path: '/contests',
      tags: ['Challenge', 'Competition'],
      icon: Trophy
    },
    {
      type: 'job',
      title: 'Senior Full Stack Developer',
      description: 'Remote position at TechCorp Solutions',
      path: '/jobs',
      tags: ['Full Stack', 'Remote'],
      icon: Briefcase
    }
  ];

  const filters = [
    { id: 'all', label: 'All', icon: SearchIcon },
    { id: 'course', label: 'Courses', icon: Code2 },
    { id: 'tutorial', label: 'Tutorials', icon: Book },
    { id: 'contest', label: 'Contests', icon: Trophy },
    { id: 'job', label: 'Jobs', icon: Briefcase }
  ];

  const filteredResults = searchResults.filter(result => {
    const matchesFilter = activeFilter === 'all' || result.type === activeFilter;
    const matchesSearch = !searchQuery || (
      result.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      result.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      result.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    return matchesFilter && matchesSearch;
  });

  const containerClasses = theme === 'dark'
    ? 'bg-[#0A0118] text-white'
    : 'bg-gray-50 text-gray-800';

  return (
    <div className={`min-h-screen ${containerClasses}`}>
      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Search Header */}
        <div className="mb-12">
          <h1 className={`text-4xl font-bold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            Search Results
          </h1>
          <p className={theme === 'dark' ? 'text-white/70' : 'text-gray-600'}>
            {searchQuery ? `Showing results for "${searchQuery}"` : 'Find courses, tutorials, challenges, and more'}
          </p>
        </div>

        {/* Search Input */}
        <div className="relative mb-8">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <SearchIcon className={`h-6 w-6 ${theme === 'dark' ? 'text-white/40' : 'text-gray-400'}`} />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for anything..."
            className={`w-full pl-12 pr-4 py-4 rounded-xl ${
              theme === 'dark'
                ? 'bg-white/5 border border-white/10 text-white placeholder-white/40'
                : 'bg-white border border-gray-200 text-gray-900 placeholder-gray-500'
            } focus:outline-none focus:border-purple-500`}
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-8">
          {filters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                activeFilter === filter.id
                  ? 'bg-purple-500 text-white'
                  : theme === 'dark'
                    ? 'bg-white/5 text-white/70 hover:bg-white/10'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <filter.icon className="h-5 w-5 mr-2" />
              {filter.label}
            </button>
          ))}
        </div>

        {/* Search Results */}
        <div className="space-y-4">
          {filteredResults.map((result, index) => (
            <Link
              key={index}
              to={result.path}
              className={`block rounded-xl p-6 ${
                theme === 'dark'
                  ? 'bg-white/5 border border-white/10 hover:border-purple-500/50'
                  : 'bg-white border border-gray-200 hover:border-purple-500/50'
              } transition-colors`}
            >
              <div className="flex items-start">
                <result.icon className="h-8 w-8 text-purple-400 mr-4 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className={`text-xl font-semibold mb-2 ${
                    theme === 'dark' ? 'text-white' : 'text-gray-900'
                  }`}>{result.title}</h3>
                  <p className={theme === 'dark' ? 'text-white/70' : 'text-gray-600'} className="mb-4">
                    {result.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {result.tags.map((tag, tagIndex) => (
                      <span
                        key={tagIndex}
                        className={`inline-flex items-center px-3 py-1 rounded-full text-sm ${
                          theme === 'dark'
                            ? 'bg-white/10 text-white/70'
                            : 'bg-gray-100 text-gray-700'
                        }`}
                      >
                        <Tag className="h-4 w-4 mr-1" />
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </Link>
          ))}

          {filteredResults.length === 0 && (
            <div className="text-center py-12">
              <p className={theme === 'dark' ? 'text-white/70' : 'text-gray-600'} className="text-lg">
                No results found for "{searchQuery}"
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Search;