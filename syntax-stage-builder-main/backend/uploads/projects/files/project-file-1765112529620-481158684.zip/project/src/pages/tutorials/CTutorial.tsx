import React from 'react';
import { Link } from 'react-router-dom';
import { Code2, Terminal, FileCode, Cpu } from 'lucide-react';

function CTutorial() {
  const topics = [
    {
      title: "C Fundamentals",
      description: "Learn the basics of C programming",
      icon: Code2,
      lessons: [
        { title: "Introduction to C", path: "/tutorials/c/intro" },
        { title: "Variables & Data Types", path: "/tutorials/c/variables" },
        { title: "Control Structures", path: "/tutorials/c/control" },
        { title: "Functions", path: "/tutorials/c/functions" }
      ]
    },
    {
      title: "Memory Management",
      description: "Master C memory concepts",
      icon: Cpu,
      lessons: [
        { title: "Pointers", path: "/tutorials/c/pointers" },
        { title: "Dynamic Memory", path: "/tutorials/c/dynamic-memory" },
        { title: "Arrays & Strings", path: "/tutorials/c/arrays" },
        { title: "Memory Layout", path: "/tutorials/c/memory-layout" }
      ]
    },
    {
      title: "Advanced C",
      description: "Advanced programming concepts",
      icon: FileCode,
      lessons: [
        { title: "Structures & Unions", path: "/tutorials/c/structures" },
        { title: "File Handling", path: "/tutorials/c/files" },
        { title: "Preprocessor", path: "/tutorials/c/preprocessor" },
        { title: "Bit Manipulation", path: "/tutorials/c/bits" }
      ]
    },
    {
      title: "System Programming",
      description: "Low-level programming with C",
      icon: Terminal,
      lessons: [
        { title: "Process Management", path: "/tutorials/c/processes" },
        { title: "System Calls", path: "/tutorials/c/syscalls" },
        { title: "Socket Programming", path: "/tutorials/c/sockets" },
        { title: "Threading", path: "/tutorials/c/threads" }
      ]
    }
  ];

  return (
    <div>
      <h1 className="text-4xl font-bold text-white mb-8">C Programming Tutorial</h1>
      <p className="text-xl text-white/70 mb-12">
        Master C programming from fundamentals to advanced concepts
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        {topics.map((topic, index) => (
          <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
            <div className="flex items-start mb-4">
              <topic.icon className="h-8 w-8 text-purple-400 mr-4" />
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">{topic.title}</h3>
                <p className="text-white/70 mb-4">{topic.description}</p>
              </div>
            </div>
            <ul className="space-y-2">
              {topic.lessons.map((lesson, lessonIndex) => (
                <li key={lessonIndex} className="flex items-center">
                  <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                  <Link 
                    to={lesson.path}
                    className="text-white/70 hover:text-purple-400 transition-colors"
                  >
                    {lesson.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-white/5 rounded-xl p-8 backdrop-blur-lg border border-white/10">
        <h2 className="text-2xl font-bold text-white mb-4">Practice C Programming</h2>
        <p className="text-white/70 mb-6">
          Test your C programming skills with our interactive compiler
        </p>
        <Link 
          to="/playground" 
          className="inline-flex items-center px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
        >
          Start Coding
        </Link>
      </div>
    </div>
  );
}

export default CTutorial;