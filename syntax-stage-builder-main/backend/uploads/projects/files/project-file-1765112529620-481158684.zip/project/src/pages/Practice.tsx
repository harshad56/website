import React from 'react';
import { Code2, Star, Timer, Users } from 'lucide-react';

function Practice() {
  const problems = [
    {
      title: "Two Sum",
      difficulty: "Easy",
      acceptance: "45%",
      topics: ["Arrays", "Hash Table"],
      companies: ["Google", "Amazon", "Facebook"]
    },
    {
      title: "Longest Substring Without Repeating Characters",
      difficulty: "Medium",
      acceptance: "32%",
      topics: ["String", "Sliding Window"],
      companies: ["Amazon", "Microsoft", "Adobe"]
    },
    {
      title: "Median of Two Sorted Arrays",
      difficulty: "Hard",
      acceptance: "28%",
      topics: ["Arrays", "Binary Search"],
      companies: ["Google", "Apple", "Microsoft"]
    }
  ];

  const difficultyColors = {
    Easy: "text-green-500",
    Medium: "text-yellow-500",
    Hard: "text-red-500"
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-white mb-4">Practice Coding</h1>
        <p className="text-xl text-white/70">Solve coding problems and improve your skills</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Filters */}
        <div className="lg:col-span-1">
          <div className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
            <h3 className="text-xl font-semibold text-white mb-6">Filters</h3>
            
            <div className="space-y-6">
              <div>
                <h4 className="text-white/70 mb-3">Difficulty</h4>
                <div className="space-y-2">
                  {["Easy", "Medium", "Hard"].map((level) => (
                    <label key={level} className="flex items-center space-x-2 text-white cursor-pointer">
                      <input type="checkbox" className="rounded border-white/20 bg-white/10" />
                      <span className={difficultyColors[level]}>{level}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-white/70 mb-3">Topics</h4>
                <div className="space-y-2">
                  {["Arrays", "Strings", "Dynamic Programming", "Trees", "Graphs"].map((topic) => (
                    <label key={topic} className="flex items-center space-x-2 text-white cursor-pointer">
                      <input type="checkbox" className="rounded border-white/20 bg-white/10" />
                      <span>{topic}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-white/70 mb-3">Companies</h4>
                <div className="space-y-2">
                  {["Google", "Amazon", "Microsoft", "Facebook", "Apple"].map((company) => (
                    <label key={company} className="flex items-center space-x-2 text-white cursor-pointer">
                      <input type="checkbox" className="rounded border-white/20 bg-white/10" />
                      <span>{company}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Problems List */}
        <div className="lg:col-span-3">
          <div className="space-y-4">
            {problems.map((problem, index) => (
              <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10 hover:border-purple-500/50 transition-colors">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">{problem.title}</h3>
                    <div className="flex items-center space-x-4 text-sm">
                      <span className={`${difficultyColors[problem.difficulty]}`}>
                        {problem.difficulty}
                      </span>
                      <span className="text-white/70">
                        <Users className="w-4 h-4 inline mr-1" />
                        {problem.acceptance} acceptance
                      </span>
                    </div>
                  </div>
                  <button className="px-4 py-2 bg-purple-500/20 text-purple-400 rounded-lg hover:bg-purple-500/30 transition-colors">
                    Solve
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {problem.topics.map((topic, topicIndex) => (
                    <span key={topicIndex} className="px-3 py-1 bg-white/10 text-white/70 rounded-full text-sm">
                      {topic}
                    </span>
                  ))}
                </div>

                <div className="mt-4 pt-4 border-t border-white/10">
                  <div className="flex items-center space-x-4 text-sm text-white/70">
                    <span>Companies:</span>
                    {problem.companies.map((company, companyIndex) => (
                      <span key={companyIndex}>{company}</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Practice;