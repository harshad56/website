import React from 'react';
import { Code, PlayCircle, BookOpen, CheckCircle } from 'lucide-react';
import TutorialNavigation from '../../../components/TutorialNavigation';
import ProgressTracker from '../../../components/ProgressTracker';

function FirstProgram() {
  const steps = [
    "Introduction",
    "Environment Setup",
    "First Program",
    "Variables",
    "Control Flow"
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <ProgressTracker steps={steps} currentStep={2} />
      
      <h1 className="text-3xl font-bold text-white mb-6">Your First Java Program</h1>

      <div className="space-y-8">
        {/* Introduction */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Getting Started with Java Programming</h2>
          <p className="text-white/80 leading-relaxed">
            Let's write your first Java program! We'll start with the classic "Hello, World!" example and break down each component to understand the basics of Java syntax.
          </p>
        </section>

        {/* Hello World Program */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Hello World Program</h2>
          
          <div className="bg-black/50 rounded-lg p-4 mb-6">
            <pre className="text-white/90 overflow-x-auto">
              <code>{`public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}`}</code>
            </pre>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-medium text-white">Code Breakdown</h3>
            
            {[
              {
                line: "public class HelloWorld",
                explanation: "Declares a public class named HelloWorld. The class name must match the file name (HelloWorld.java)."
              },
              {
                line: "public static void main(String[] args)",
                explanation: "The main method - entry point of the program. Java looks for this method to start execution."
              },
              {
                line: 'System.out.println("Hello, World!");',
                explanation: "Prints the text 'Hello, World!' to the console. println adds a new line after the text."
              }
            ].map((item, index) => (
              <div key={index} className="bg-white/5 rounded-lg p-4">
                <code className="text-purple-400 block mb-2">{item.line}</code>
                <p className="text-white/70">{item.explanation}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Running the Program */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Running Your Program</h2>
          
          <div className="space-y-6">
            <div className="bg-white/5 rounded-lg p-4">
              <h3 className="text-lg font-medium text-purple-400 mb-2">1. Save the File</h3>
              <p className="text-white/70">Save your code in a file named <code className="text-purple-400">HelloWorld.java</code></p>
            </div>

            <div className="bg-white/5 rounded-lg p-4">
              <h3 className="text-lg font-medium text-purple-400 mb-2">2. Compile the Program</h3>
              <div className="bg-black/50 rounded-lg p-4">
                <pre className="text-white/90">
                  <code>javac HelloWorld.java</code>
                </pre>
              </div>
            </div>

            <div className="bg-white/5 rounded-lg p-4">
              <h3 className="text-lg font-medium text-purple-400 mb-2">3. Run the Program</h3>
              <div className="bg-black/50 rounded-lg p-4">
                <pre className="text-white/90">
                  <code>java HelloWorld</code>
                </pre>
              </div>
            </div>
          </div>
        </section>

        {/* Common Mistakes */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Common Mistakes to Avoid</h2>
          
          <div className="space-y-4">
            {[
              {
                mistake: "Wrong file name",
                description: "The file name must match the class name and end with .java"
              },
              {
                mistake: "Missing semicolons",
                description: "Each statement must end with a semicolon"
              },
              {
                mistake: "Incorrect capitalization",
                description: "Java is case-sensitive. System, String, etc. must be capitalized correctly"
              }
            ].map((item, index) => (
              <div key={index} className="bg-white/5 rounded-lg p-4">
                <h3 className="text-lg font-medium text-red-400 mb-2">{item.mistake}</h3>
                <p className="text-white/70">{item.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Try It Yourself */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Try It Yourself</h2>
          
          <div className="space-y-4">
            <p className="text-white/80">
              Practice by modifying the Hello World program. Try these exercises:
            </p>
            
            <div className="space-y-2">
              {[
                "Print your name instead of 'Hello, World!'",
                "Print multiple lines using multiple println statements",
                "Use System.out.print() instead of println() and observe the difference"
              ].map((exercise, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-purple-400" />
                  <span className="text-white/70">{exercise}</span>
                </div>
              ))}
            </div>

            <button className="mt-4 flex items-center space-x-2 bg-purple-500/20 text-purple-400 px-6 py-3 rounded-lg hover:bg-purple-500/30 transition-colors">
              <PlayCircle className="h-5 w-5" />
              <span>Open Practice Editor</span>
            </button>
          </div>
        </section>
      </div>

      <TutorialNavigation
        previousPath="/tutorials/java/environment-setup"
        previousLabel="Previous: Setting up Java Environment"
        nextPath="/tutorials/java/variables"
        nextLabel="Next: Variables and Data Types"
      />
    </div>
  );
}

export default FirstProgram;