import React from 'react';
import { Link } from 'react-router-dom';
import { BarChart2, LineChart, PieChart, Table } from 'lucide-react';

function RTutorial() {
  const topics = [
    {
      title: "R Basics",
      description: "Learn fundamental R programming concepts",
      icon: BarChart2,
      lessons: [
        { title: "Introduction to R", path: "/tutorials/r/intro" },
        { title: "Data Types & Variables", path: "/tutorials/r/data-types" },
        { title: "Functions & Packages", path: "/tutorials/r/functions" },
        { title: "Control Structures", path: "/tutorials/r/control" }
      ]
    },
    {
      title: "Data Manipulation",
      description: "Master data handling in R",
      icon: Table,
      lessons: [
        { title: "Data Frames", path: "/tutorials/r/data-frames" },
        { title: "dplyr Package", path: "/tutorials/r/dplyr" },
        { title: "tidyr Package", path: "/tutorials/r/tidyr" },
        { title: "Data Cleaning", path: "/tutorials/r/cleaning" }
      ]
    },
    {
      title: "Data Visualization",
      description: "Create stunning visualizations",
      icon: LineChart,
      lessons: [
        { title: "ggplot2 Basics", path: "/tutorials/r/ggplot2" },
        { title: "Advanced Plotting", path: "/tutorials/r/advanced-plots" },
        { title: "Interactive Plots", path: "/tutorials/r/interactive" },
        { title: "Statistical Plots", path: "/tutorials/r/stat-plots" }
      ]
    },
    {
      title: "Statistical Analysis",
      description: "Perform statistical computations",
      icon: PieChart,
      lessons: [
        { title: "Descriptive Statistics", path: "/tutorials/r/descriptive" },
        { title: "Hypothesis Testing", path: "/tutorials/r/hypothesis" },
        { title: "Regression Analysis", path: "/tutorials/r/regression" },
        { title: "Machine Learning", path: "/tutorials/r/ml" }
      ]
    }
  ];

  return (
    <div>
      <h1 className="text-4xl font-bold text-white mb-8">R Programming Tutorial</h1>
      <p className="text-xl text-white/70 mb-12">
        Learn R programming for data science and statistical computing
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        {topics.map((topic, index) => (
          <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
            <div className="flex items-start mb-4">
              <topic.icon className="h-8 w-8 text-purple-400 mr-4" />
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">{topic.title}</h3>
                <p className="text-white/70 mb-4">{topic.description}</p>
              </div>
            </div>
            <ul className="space-y-2">
              {topic.lessons.map((lesson, lessonIndex) => (
                <li key={lessonIndex} className="flex items-center">
                  <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                  <Link 
                    to={lesson.path}
                    className="text-white/70 hover:text-purple-400 transition-colors"
                  >
                    {lesson.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-white/5 rounded-xl p-8 backdrop-blur-lg border border-white/10">
        <h2 className="text-2xl font-bold text-white mb-4">Start Analyzing Data</h2>
        <p className="text-white/70 mb-6">
          Practice R programming with our interactive R environment
        </p>
        <Link 
          to="/playground" 
          className="inline-flex items-center px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
        >
          Launch R Studio
        </Link>
      </div>
    </div>
  );
}

export default RTutorial;