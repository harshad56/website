import React, { useState } from 'react';
import { Star, Send, MessageSquare } from 'lucide-react';

function Feedback() {
  const [rating, setRating] = useState<number>(0);
  const [feedback, setFeedback] = useState('');
  const [category, setCategory] = useState('general');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically send the feedback to your backend
    console.log({ rating, feedback, category });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-white mb-4">Your Feedback Matters</h1>
        <p className="text-xl text-white/70">Help us improve your learning experience</p>
      </div>

      <div className="bg-white/5 rounded-xl p-8 backdrop-blur-lg border border-white/10">
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Rating */}
          <div>
            <label className="block text-lg font-medium text-white mb-4">
              How would you rate your experience?
            </label>
            <div className="flex space-x-2">
              {[1, 2, 3, 4, 5].map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setRating(value)}
                  className={`p-2 rounded-lg transition-colors ${
                    rating >= value 
                      ? 'text-yellow-400 hover:text-yellow-300' 
                      : 'text-white/30 hover:text-white/50'
                  }`}
                >
                  <Star className="h-8 w-8" fill={rating >= value ? 'currentColor' : 'none'} />
                </button>
              ))}
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="block text-lg font-medium text-white mb-4">
              What area would you like to give feedback about?
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white focus:outline-none focus:border-purple-500"
            >
              <option value="general">General Experience</option>
              <option value="courses">Course Content</option>
              <option value="platform">Platform Features</option>
              <option value="technical">Technical Issues</option>
              <option value="suggestions">Suggestions</option>
            </select>
          </div>

          {/* Feedback Text */}
          <div>
            <label className="block text-lg font-medium text-white mb-4">
              Share your thoughts with us
            </label>
            <div className="relative">
              <MessageSquare className="absolute top-3 left-3 h-5 w-5 text-white/40" />
              <textarea
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                placeholder="Tell us what you think..."
                rows={6}
                className="w-full pl-10 pr-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/40 focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="relative group w-full"
          >
            <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-200"></div>
            <span className="relative flex items-center justify-center px-6 py-3 bg-black rounded-full text-white w-full">
              <Send className="h-5 w-5 mr-2" />
              Submit Feedback
            </span>
          </button>
        </form>
      </div>

      {/* Additional Information */}
      <div className="mt-8 grid md:grid-cols-2 gap-6">
        <div className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h3 className="text-xl font-semibold text-white mb-3">Why Your Feedback Matters</h3>
          <p className="text-white/70">
            Your feedback helps us improve our platform and create better learning experiences for everyone.
            We carefully review all feedback to make informed decisions about future updates and improvements.
          </p>
        </div>
        <div className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h3 className="text-xl font-semibold text-white mb-3">What Happens Next?</h3>
          <p className="text-white/70">
            Our team reviews feedback regularly and uses it to prioritize improvements.
            While we can't respond to every submission individually, your input directly influences our development roadmap.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Feedback;