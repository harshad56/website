import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Laptop, ChevronDown, Menu, Code2, BookOpen, BrainCircuit, Briefcase, Trophy, LogIn, X } from 'lucide-react';
import ThemeToggle from './ThemeToggle';
import { useTheme } from '../contexts/ThemeContext';

function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isTutorialDropdownOpen, setIsTutorialDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { theme } = useTheme();

  // Navigation items definition
  const navItems = [
    { 
      title: "Tutorials",
      icon: BookOpen,
      dropdown: true,
      items: [
        { title: "Java Programming", path: "/tutorials/java" },
        { title: "Python", path: "/tutorials/python" },
        { title: "C++", path: "/tutorials/cpp" },
        { title: "HTML Mastery", path: "/tutorials/html" },
        { title: "CSS & Design", path: "/tutorials/css" }
      ]
    },
    { title: "Practice", icon: BrainCircuit, path: "/practice", dropdown: false },
    { title: "Jobs", icon: Briefcase, path: "/jobs", dropdown: false },
    { title: "Contests", icon: Trophy, path: "/contests", dropdown: false }
  ];

  // All available courses and topics
  const searchItems = [
    {
      type: 'course',
      title: 'C++ Programming',
      path: '/tutorials/cpp',
      description: 'Learn C++ from basics to advanced',
      tags: ['c++', 'programming', 'coding']
    },
    {
      type: 'course',
      title: 'C Programming',
      path: '/tutorials/c',
      description: 'Master C programming language',
      tags: ['c', 'programming', 'coding']
    },
    {
      type: 'course',
      title: 'Python Course',
      path: '/tutorials/python',
      description: 'Complete Python programming tutorial',
      tags: ['python', 'programming', 'coding']
    },
    {
      type: 'course',
      title: 'Java Development',
      path: '/tutorials/java',
      description: 'Java programming from scratch',
      tags: ['java', 'programming', 'coding']
    },
    {
      type: 'topic',
      title: 'Data Structures',
      path: '/practice/data-structures',
      description: 'Learn essential data structures',
      tags: ['dsa', 'algorithms', 'coding']
    },
    {
      type: 'topic',
      title: 'Web Development',
      path: '/tutorials/web',
      description: 'Full stack web development',
      tags: ['web', 'html', 'css', 'javascript']
    },
    {
      type: 'course',
      title: 'CSS Mastery',
      path: '/tutorials/css',
      description: 'Advanced CSS and design',
      tags: ['css', 'web', 'design']
    }
  ];

  // Filter suggestions based on search query
  const filteredSuggestions = searchQuery
    ? searchItems.filter(item => 
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  // Close suggestions when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setShowSuggestions(false);
    }
  };

  const handleSuggestionClick = (path: string) => {
    navigate(path);
    setSearchQuery('');
    setShowSuggestions(false);
  };

  return (
    <nav className={`sticky top-0 z-50 backdrop-blur-lg bg-opacity-90 ${
      theme === 'dark' 
        ? 'bg-gradient-to-r from-blue-900 via-indigo-900 to-purple-900 text-white' 
        : 'bg-white text-gray-800 shadow-md'
    }`}>
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-20">
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-pink-500 to-purple-500 rounded-lg blur opacity-25 group-hover:opacity-75 transition duration-200"></div>
              <Code2 className={`h-10 w-10 relative ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`} />
            </div>
            <span className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-500">
              Study Code
            </span>
          </Link>
          
          <div className="hidden md:flex items-center space-x-8">
            {/* Search Bar with Suggestions */}
            <div className="relative" ref={searchRef}>
              <form onSubmit={handleSearch} className="relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full blur opacity-25"></div>
                <div className="relative flex items-center">
                  <input
                    type="text"
                    placeholder="Search courses, topics..."
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setShowSuggestions(true);
                    }}
                    onFocus={() => setShowSuggestions(true)}
                    className={`w-80 pl-10 pr-10 py-3 rounded-full ${
                      theme === 'dark' 
                        ? 'bg-white/10 border border-white/20 text-white placeholder-white/60' 
                        : 'bg-gray-100 border border-gray-200 text-gray-800 placeholder-gray-500'
                    } focus:outline-none focus:border-purple-500 relative`}
                  />
                  <Search className={`absolute left-3 top-3 h-5 w-5 ${theme === 'dark' ? 'text-white/60' : 'text-gray-500'}`} />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery('');
                        setShowSuggestions(false);
                      }}
                      className="absolute right-3 top-3"
                    >
                      <X className={`h-5 w-5 ${theme === 'dark' ? 'text-white/60' : 'text-gray-500'}`} />
                    </button>
                  )}
                </div>
              </form>

              {/* Search Suggestions */}
              {showSuggestions && searchQuery && filteredSuggestions.length > 0 && (
                <div className={`absolute mt-2 w-full rounded-xl shadow-lg ${
                  theme === 'dark' 
                    ? 'bg-[#1a1a2e] border border-white/10' 
                    : 'bg-white border border-gray-200'
                }`}>
                  <div className="py-2 max-h-96 overflow-y-auto">
                    {filteredSuggestions.map((item, index) => (
                      <button
                        key={index}
                        onClick={() => handleSuggestionClick(item.path)}
                        className={`w-full text-left px-4 py-3 hover:bg-purple-500/10 flex items-start space-x-3 ${
                          index !== filteredSuggestions.length - 1 
                            ? theme === 'dark' ? 'border-b border-white/10' : 'border-b border-gray-100'
                            : ''
                        }`}
                      >
                        {item.type === 'course' ? (
                          <BookOpen className="h-5 w-5 text-purple-400 mt-1 flex-shrink-0" />
                        ) : (
                          <Code2 className="h-5 w-5 text-purple-400 mt-1 flex-shrink-0" />
                        )}
                        <div>
                          <h3 className={theme === 'dark' ? 'text-white' : 'text-gray-900'}>
                            {item.title}
                          </h3>
                          <p className={`text-sm ${theme === 'dark' ? 'text-white/60' : 'text-gray-500'}`}>
                            {item.description}
                          </p>
                          <div className="flex flex-wrap gap-2 mt-1">
                            {item.tags.map((tag, tagIndex) => (
                              <span
                                key={tagIndex}
                                className={`text-xs px-2 py-1 rounded-full ${
                                  theme === 'dark'
                                    ? 'bg-purple-500/20 text-purple-400'
                                    : 'bg-purple-100 text-purple-600'
                                }`}
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Rest of the navbar items */}
            {navItems.map((item, index) => (
              item.dropdown ? (
                <div key={index} className="relative group">
                  <button 
                    className={`flex items-center transition-colors py-2 px-4 rounded-lg ${
                      theme === 'dark'
                        ? 'text-white/90 hover:text-white hover:bg-white/10'
                        : 'text-gray-700 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                    onClick={() => setIsTutorialDropdownOpen(!isTutorialDropdownOpen)}
                  >
                    <item.icon className="w-5 h-5 mr-2" />
                    {item.title} <ChevronDown className="ml-1 h-4 w-4" />
                  </button>
                  
                  {isTutorialDropdownOpen && (
                    <div className={`absolute top-full left-0 mt-2 w-64 rounded-xl shadow-2xl py-3 z-50 ${
                      theme === 'dark'
                        ? 'bg-[#1a1a2e] border border-white/10'
                        : 'bg-white border border-gray-200'
                    }`}>
                      {item.items.map((subItem, subIndex) => (
                        <Link 
                          key={subIndex}
                          to={subItem.path}
                          className={`block px-4 py-3 hover:bg-purple-500/10 transition-colors ${
                            theme === 'dark'
                              ? 'text-white/90 hover:text-white'
                              : 'text-gray-700 hover:text-gray-900'
                          }`}
                        >
                          {subItem.title}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  key={index}
                  to={item.path}
                  className={`flex items-center transition-colors py-2 px-4 rounded-lg ${
                    theme === 'dark'
                      ? 'text-white/90 hover:text-white hover:bg-white/10'
                      : 'text-gray-700 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <item.icon className="w-5 h-5 mr-2" />
                  {item.title}
                </Link>
              )
            ))}

            <Link to="/signin" className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-200"></div>
              <span className="relative px-6 py-3 bg-black rounded-full text-white block flex items-center">
                <LogIn className="w-4 h-4 mr-2" />
                Sign In
              </span>
            </Link>
            <ThemeToggle />
          </div>
          
          <button 
            className="md:hidden relative group"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <div className="absolute -inset-1 bg-gradient-to-r from-pink-500 to-purple-500 rounded-lg blur opacity-25 group-hover:opacity-75 transition duration-200"></div>
            <Menu className="h-6 w-6 relative" />
          </button>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden py-6 border-t border-white/10">
            <div className="flex flex-col space-y-6">
              {navItems.map((item, index) => (
                item.dropdown ? (
                  <div key={index}>
                    {item.items.map((subItem, subIndex) => (
                      <Link
                        key={subIndex}
                        to={subItem.path}
                        className={`block px-4 py-2 rounded-lg ${
                          theme === 'dark'
                            ? 'text-white/90 hover:text-white hover:bg-white/10'
                            : 'text-gray-700 hover:text-gray-900 hover:bg-gray-100'
                        }`}
                      >
                        {subItem.title}
                      </Link>
                    ))}
                  </div>
                ) : (
                  <Link
                    key={index}
                    to={item.path}
                    className={`flex items-center px-4 py-2 rounded-lg ${
                      theme === 'dark'
                        ? 'text-white/90 hover:text-white hover:bg-white/10'
                        : 'text-gray-700 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    <item.icon className="w-5 h-5 mr-2" />
                    {item.title}
                  </Link>
                )
              ))}
              <Link to="/signin" className="relative group w-full">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-200"></div>
                <span className="relative px-6 py-3 bg-black rounded-full text-white block w-full flex items-center justify-center">
                  <LogIn className="w-4 h-4 mr-2" />
                  Sign In
                </span>
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

export default Navbar;