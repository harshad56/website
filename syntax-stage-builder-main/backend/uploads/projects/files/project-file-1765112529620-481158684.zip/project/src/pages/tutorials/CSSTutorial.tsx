import React from 'react';
import { Link } from 'react-router-dom';
import { Palette, Box, Layout, Layers } from 'lucide-react';

function CSSTutorial() {
  const topics = [
    {
      title: "CSS Fundamentals",
      description: "Master the basics of CSS styling",
      icon: Palette,
      lessons: [
        { title: "CSS Introduction", path: "/tutorials/css/intro" },
        { title: "Selectors & Specificity", path: "/tutorials/css/selectors" },
        { title: "Box Model", path: "/tutorials/css/box-model" },
        { title: "Colors & Typography", path: "/tutorials/css/typography" }
      ]
    },
    {
      title: "CSS Layout",
      description: "Learn modern CSS layout techniques",
      icon: Layout,
      lessons: [
        { title: "Flexbox", path: "/tutorials/css/flexbox" },
        { title: "CSS Grid", path: "/tutorials/css/grid" },
        { title: "Positioning", path: "/tutorials/css/positioning" },
        { title: "Responsive Layout", path: "/tutorials/css/responsive" }
      ]
    },
    {
      title: "CSS Animations",
      description: "Create engaging animations with CSS",
      icon: Box,
      lessons: [
        { title: "Transitions", path: "/tutorials/css/transitions" },
        { title: "Keyframe Animations", path: "/tutorials/css/keyframes" },
        { title: "Transform & Translate", path: "/tutorials/css/transform" },
        { title: "3D Effects", path: "/tutorials/css/3d" }
      ]
    },
    {
      title: "Advanced CSS",
      description: "Master advanced CSS concepts",
      icon: Layers,
      lessons: [
        { title: "CSS Variables", path: "/tutorials/css/variables" },
        { title: "CSS Modules", path: "/tutorials/css/modules" },
        { title: "CSS Architecture", path: "/tutorials/css/architecture" },
        { title: "Performance Optimization", path: "/tutorials/css/performance" }
      ]
    }
  ];

  return (
    <div>
      <h1 className="text-4xl font-bold text-white mb-8">CSS Tutorial</h1>
      <p className="text-xl text-white/70 mb-12">
        Master CSS and create beautiful, responsive websites
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        {topics.map((topic, index) => (
          <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
            <div className="flex items-start mb-4">
              <topic.icon className="h-8 w-8 text-purple-400 mr-4" />
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">{topic.title}</h3>
                <p className="text-white/70 mb-4">{topic.description}</p>
              </div>
            </div>
            <ul className="space-y-2">
              {topic.lessons.map((lesson, lessonIndex) => (
                <li key={lessonIndex} className="flex items-center">
                  <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                  <Link 
                    to={lesson.path}
                    className="text-white/70 hover:text-purple-400 transition-colors"
                  >
                    {lesson.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-white/5 rounded-xl p-8 backdrop-blur-lg border border-white/10">
        <h2 className="text-2xl font-bold text-white mb-4">Practice CSS</h2>
        <p className="text-white/70 mb-6">
          Test your CSS skills with our interactive playground
        </p>
        <Link 
          to="/playground" 
          className="inline-flex items-center px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
        >
          Open Playground
        </Link>
      </div>
    </div>
  );
}

export default CSSTutorial;