import { createClient } from '@supabase/supabase-js';
import { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);

// Auth helpers
export const signUp = async (email: string, password: string, name: string) => {
  const { data: auth, error: signUpError } = await supabase.auth.signUp({
    email,
    password,
  });

  if (signUpError) throw signUpError;

  // Create profile after successful signup
  const { error: profileError } = await supabase
    .from('profiles')
    .insert([{ id: auth.user?.id, name }]);

  if (profileError) throw profileError;

  return auth;
};

export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw error;
  return data;
};

// Course helpers
export const getCourses = async () => {
  const { data, error } = await supabase
    .from('courses')
    .select(`
      *,
      instructor:profiles(name)
    `);

  if (error) throw error;
  return data;
};

export const enrollInCourse = async (courseId: string) => {
  const { data, error } = await supabase
    .from('enrollments')
    .insert([{ course_id: courseId }]);

  if (error) throw error;
  return data;
};

// Problem helpers
export const getProblems = async () => {
  const { data, error } = await supabase
    .from('problems')
    .select('*');

  if (error) throw error;
  return data;
};

export const submitSolution = async (problemId: string, code: string, language: string) => {
  const { data, error } = await supabase
    .from('submissions')
    .insert([{ problem_id: problemId, code, language }]);

  if (error) throw error;
  return data;
};

// Competition helpers
export const getCompetitions = async () => {
  const { data, error } = await supabase
    .from('competitions')
    .select('*');

  if (error) throw error;
  return data;
};

export const registerForCompetition = async (competitionId: string) => {
  const { data, error } = await supabase
    .from('competition_registrations')
    .insert([{ competition_id: competitionId }]);

  if (error) throw error;
  return data;
};