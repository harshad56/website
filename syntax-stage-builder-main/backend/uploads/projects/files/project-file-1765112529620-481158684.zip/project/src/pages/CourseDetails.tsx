import React from 'react';
import { useParams } from 'react-router-dom';
import { Play, Book, Clock, Award, ChevronRight, Users, Star } from 'lucide-react';

function CourseDetails() {
  const { courseId } = useParams();

  // This would typically come from an API/database
  const courseData = {
    title: "Complete Java Programming Masterclass",
    instructor: "John Smith",
    rating: 4.8,
    students: "15K+",
    duration: "40 hours",
    level: "Beginner to Advanced",
    description: "Master Java programming with this comprehensive course. Learn everything from basic syntax to advanced concepts like multithreading and design patterns.",
    modules: [
      {
        title: "Introduction to Java",
        lessons: [
          { title: "What is Java?", duration: "15 min", type: "video" },
          { title: "Setting up Java Environment", duration: "20 min", type: "video" },
          { title: "Your First Java Program", duration: "25 min", type: "practice" }
        ]
      },
      {
        title: "Object-Oriented Programming",
        lessons: [
          { title: "Classes and Objects", duration: "30 min", type: "video" },
          { title: "Inheritance", duration: "25 min", type: "video" },
          { title: "OOP Practice Problems", duration: "45 min", type: "quiz" }
        ]
      }
    ]
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      {/* Course Header */}
      <div className="bg-white/5 rounded-xl p-8 backdrop-blur-lg border border-white/10 mb-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <h1 className="text-3xl font-bold text-white mb-4">{courseData.title}</h1>
            <p className="text-white/70 mb-6">{courseData.description}</p>
            
            <div className="flex flex-wrap gap-4 mb-6">
              <div className="flex items-center text-white/70">
                <Users className="h-5 w-5 mr-2" />
                {courseData.students} students
              </div>
              <div className="flex items-center text-white/70">
                <Star className="h-5 w-5 mr-2 text-yellow-400" />
                {courseData.rating} rating
              </div>
              <div className="flex items-center text-white/70">
                <Clock className="h-5 w-5 mr-2" />
                {courseData.duration}
              </div>
              <div className="flex items-center text-white/70">
                <Award className="h-5 w-5 mr-2" />
                {courseData.level}
              </div>
            </div>

            <div className="flex items-center mb-6">
              <img
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=48&h=48&q=80"
                alt={courseData.instructor}
                className="h-12 w-12 rounded-full border-2 border-purple-500"
              />
              <div className="ml-4">
                <p className="text-white font-medium">{courseData.instructor}</p>
                <p className="text-white/70 text-sm">Senior Java Developer</p>
              </div>
            </div>
          </div>

          <div className="md:col-span-1">
            <div className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-white mb-2">Free</h3>
                <p className="text-white/70">Start learning today</p>
              </div>
              
              <button className="relative group w-full mb-4">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-200"></div>
                <span className="relative flex items-center justify-center px-6 py-3 bg-black rounded-full text-white w-full">
                  Enroll Now
                </span>
              </button>

              <ul className="space-y-3 text-white/70">
                <li className="flex items-center">
                  <Play className="h-5 w-5 mr-3 text-purple-400" />
                  {courseData.duration} of video content
                </li>
                <li className="flex items-center">
                  <Book className="h-5 w-5 mr-3 text-purple-400" />
                  Complete course materials
                </li>
                <li className="flex items-center">
                  <Award className="h-5 w-5 mr-3 text-purple-400" />
                  Certificate of completion
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Course Content */}
      <div className="bg-white/5 rounded-xl p-8 backdrop-blur-lg border border-white/10">
        <h2 className="text-2xl font-bold text-white mb-6">Course Content</h2>
        
        <div className="space-y-4">
          {courseData.modules.map((module, moduleIndex) => (
            <div key={moduleIndex} className="border border-white/10 rounded-lg overflow-hidden">
              <div className="bg-white/5 p-4 flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white">{module.title}</h3>
                <ChevronRight className="h-5 w-5 text-white/70" />
              </div>
              
              <div className="divide-y divide-white/10">
                {module.lessons.map((lesson, lessonIndex) => (
                  <div key={lessonIndex} className="p-4 flex items-center justify-between hover:bg-white/5">
                    <div className="flex items-center">
                      {lesson.type === 'video' && <Play className="h-5 w-5 text-purple-400 mr-3" />}
                      {lesson.type === 'quiz' && <Book className="h-5 w-5 text-purple-400 mr-3" />}
                      {lesson.type === 'practice' && <Award className="h-5 w-5 text-purple-400 mr-3" />}
                      <span className="text-white">{lesson.title}</span>
                    </div>
                    <span className="text-white/70">{lesson.duration}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default CourseDetails;