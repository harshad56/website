import React from 'react';
import { Link } from 'react-router-dom';
import { Layout, Code, FileCode, Globe, Database, Palette, Shield } from 'lucide-react';

function WebDevTutorial() {
  const topics = [
    {
      title: "Frontend Development",
      description: "Master modern frontend technologies",
      icon: Layout,
      lessons: [
        { title: "HTML5 Fundamentals", path: "/tutorials/web/html" },
        { title: "CSS3 & Responsive Design", path: "/tutorials/web/css" },
        { title: "Modern JavaScript", path: "/tutorials/web/javascript" },
        { title: "React.js", path: "/tutorials/web/react" }
      ]
    },
    {
      title: "Backend Development",
      description: "Build robust server-side applications",
      icon: Database,
      lessons: [
        { title: "Node.js Basics", path: "/tutorials/web/nodejs" },
        { title: "Express.js Framework", path: "/tutorials/web/express" },
        { title: "Database Integration", path: "/tutorials/web/database" },
        { title: "RESTful APIs", path: "/tutorials/web/rest-api" }
      ]
    },
    {
      title: "Web Design",
      description: "Create beautiful and responsive websites",
      icon: Palette,
      lessons: [
        { title: "UI/UX Principles", path: "/tutorials/web/ui-ux" },
        { title: "Responsive Design", path: "/tutorials/web/responsive" },
        { title: "CSS Frameworks", path: "/tutorials/web/frameworks" },
        { title: "Web Typography", path: "/tutorials/web/typography" }
      ]
    },
    {
      title: "Web Security",
      description: "Implement security best practices",
      icon: Shield,
      lessons: [
        { title: "Authentication", path: "/tutorials/web/auth" },
        { title: "HTTPS & SSL", path: "/tutorials/web/https" },
        { title: "Security Headers", path: "/tutorials/web/security" },
        { title: "OWASP Top 10", path: "/tutorials/web/owasp" }
      ]
    }
  ];

  return (
    <div>
      <h1 className="text-4xl font-bold text-white mb-8">Web Development Tutorial</h1>
      <p className="text-xl text-white/70 mb-12">
        Master full-stack web development with our comprehensive tutorial series
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        {topics.map((topic, index) => (
          <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
            <div className="flex items-start mb-4">
              <topic.icon className="h-8 w-8 text-purple-400 mr-4" />
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">{topic.title}</h3>
                <p className="text-white/70 mb-4">{topic.description}</p>
              </div>
            </div>
            <ul className="space-y-2">
              {topic.lessons.map((lesson, lessonIndex) => (
                <li key={lessonIndex} className="flex items-center">
                  <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                  <Link 
                    to={lesson.path}
                    className="text-white/70 hover:text-purple-400 transition-colors"
                  >
                    {lesson.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-white/5 rounded-xl p-8 backdrop-blur-lg border border-white/10">
        <h2 className="text-2xl font-bold text-white mb-4">Start Building</h2>
        <p className="text-white/70 mb-6">
          Put your web development skills to practice with our interactive coding environment
        </p>
        <Link 
          to="/playground" 
          className="inline-flex items-center px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
        >
          Open Code Editor
        </Link>
      </div>
    </div>
  );
}

export default WebDevTutorial;