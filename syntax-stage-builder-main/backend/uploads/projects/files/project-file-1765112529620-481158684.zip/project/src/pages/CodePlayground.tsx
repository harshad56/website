import React, { useState } from 'react';
import { Play, Download, Copy, Save } from 'lucide-react';

function CodePlayground() {
  const [code, setCode] = useState('');
  const [language, setLanguage] = useState('javascript');
  const [output, setOutput] = useState('');

  const languages = [
    { id: 'javascript', name: 'JavaScript' },
    { id: 'python', name: 'Python' },
    { id: 'java', name: 'Java' },
    { id: 'cpp', name: 'C++' }
  ];

  const runCode = () => {
    // In a real implementation, this would send the code to a backend service
    // For now, we'll just show the code in the output
    setOutput(`Running ${language} code:\n${code}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-4">Code Playground</h1>
        <p className="text-white/70">Write, run, and share code in multiple languages</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Editor Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="bg-white/10 border border-white/20 text-white rounded-lg px-4 py-2"
            >
              {languages.map(lang => (
                <option key={lang.id} value={lang.id}>{lang.name}</option>
              ))}
            </select>
            
            <div className="flex space-x-2">
              <button
                onClick={() => {/* Save functionality */}}
                className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-lg"
                title="Save"
              >
                <Save className="h-5 w-5" />
              </button>
              <button
                onClick={() => {/* Copy functionality */}}
                className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-lg"
                title="Copy code"
              >
                <Copy className="h-5 w-5" />
              </button>
              <button
                onClick={() => {/* Download functionality */}}
                className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-lg"
                title="Download code"
              >
                <Download className="h-5 w-5" />
              </button>
            </div>
          </div>

          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full h-[500px] bg-black/50 text-white font-mono p-4 rounded-lg border border-white/20 focus:outline-none focus:border-purple-500"
            placeholder="Write your code here..."
          />

          <button
            onClick={runCode}
            className="flex items-center justify-center w-full px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
          >
            <Play className="h-5 w-5 mr-2" />
            Run Code
          </button>
        </div>

        {/* Output Section */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-white">Output</h2>
          <div className="h-[500px] bg-black/50 text-white font-mono p-4 rounded-lg border border-white/20 overflow-auto">
            <pre>{output || 'Run your code to see the output here...'}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CodePlayground;