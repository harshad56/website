import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight } from 'lucide-react';

interface TutorialNavigationProps {
  previousPath?: string;
  nextPath?: string;
  previousLabel?: string;
  nextLabel?: string;
}

function TutorialNavigation({ previousPath, nextPath, previousLabel, nextLabel }: TutorialNavigationProps) {
  const navigate = useNavigate();

  return (
    <div className="flex justify-between items-center mt-8 pt-8 border-t border-white/10">
      <button
        onClick={() => previousPath ? navigate(previousPath) : navigate(-1)}
        className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
      >
        <ArrowLeft className="h-5 w-5" />
        <span>{previousLabel || 'Back'}</span>
      </button>
      
      {nextPath && (
        <button
          onClick={() => navigate(nextPath)}
          className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-purple-500 hover:bg-purple-600 text-white transition-colors"
        >
          <span>{nextLabel || 'Next Lesson'}</span>
          <ArrowRight className="h-5 w-5" />
        </button>
      )}
    </div>
  );
}

export default TutorialNavigation;