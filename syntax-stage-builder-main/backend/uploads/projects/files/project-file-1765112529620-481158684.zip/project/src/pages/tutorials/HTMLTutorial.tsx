import React from 'react';
import { Link } from 'react-router-dom';
import { Layout, Code, FileCode, Palette } from 'lucide-react';

function HTMLTutorial() {
  const topics = [
    {
      title: "HTML Basics",
      description: "Learn the fundamentals of HTML",
      icon: Layout,
      lessons: [
        { title: "Introduction to HTML", path: "/tutorials/html/intro" },
        { title: "HTML Document Structure", path: "/tutorials/html/structure" },
        { title: "Text Elements", path: "/tutorials/html/text" },
        { title: "Links and Images", path: "/tutorials/html/media" }
      ]
    },
    {
      title: "HTML Forms",
      description: "Create interactive web forms",
      icon: Code,
      lessons: [
        { title: "Form Elements", path: "/tutorials/html/forms" },
        { title: "Input Types", path: "/tutorials/html/inputs" },
        { title: "Form Validation", path: "/tutorials/html/validation" },
        { title: "Form Handling", path: "/tutorials/html/form-handling" }
      ]
    },
    {
      title: "HTML5 Features",
      description: "Modern HTML5 elements and APIs",
      icon: FileCode,
      lessons: [
        { title: "Semantic Elements", path: "/tutorials/html/semantic" },
        { title: "Audio & Video", path: "/tutorials/html/multimedia" },
        { title: "Canvas", path: "/tutorials/html/canvas" },
        { title: "Web Storage", path: "/tutorials/html/storage" }
      ]
    },
    {
      title: "HTML Best Practices",
      description: "Write clean and maintainable HTML",
      icon: Palette,
      lessons: [
        { title: "Accessibility", path: "/tutorials/html/accessibility" },
        { title: "SEO Basics", path: "/tutorials/html/seo" },
        { title: "Performance Tips", path: "/tutorials/html/performance" },
        { title: "HTML Standards", path: "/tutorials/html/standards" }
      ]
    }
  ];

  return (
    <div>
      <h1 className="text-4xl font-bold text-white mb-8">HTML Tutorial</h1>
      <p className="text-xl text-white/70 mb-12">
        Learn HTML from scratch and build modern websites
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        {topics.map((topic, index) => (
          <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
            <div className="flex items-start mb-4">
              <topic.icon className="h-8 w-8 text-purple-400 mr-4" />
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">{topic.title}</h3>
                <p className="text-white/70 mb-4">{topic.description}</p>
              </div>
            </div>
            <ul className="space-y-2">
              {topic.lessons.map((lesson, lessonIndex) => (
                <li key={lessonIndex} className="flex items-center">
                  <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                  <Link 
                    to={lesson.path}
                    className="text-white/70 hover:text-purple-400 transition-colors"
                  >
                    {lesson.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-white/5 rounded-xl p-8 backdrop-blur-lg border border-white/10">
        <h2 className="text-2xl font-bold text-white mb-4">Practice HTML</h2>
        <p className="text-white/70 mb-6">
          Test your HTML skills with our interactive editor
        </p>
        <Link 
          to="/playground" 
          className="inline-flex items-center px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
        >
          Open Editor
        </Link>
      </div>
    </div>
  );
}

export default HTMLTutorial;