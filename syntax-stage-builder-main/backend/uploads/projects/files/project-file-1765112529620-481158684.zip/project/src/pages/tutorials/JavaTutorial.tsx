import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Code, FileCode, Terminal } from 'lucide-react';

function JavaTutorial() {
  const topics = [
    {
      title: "Introduction to Java",
      description: "Learn the basics of Java programming language",
      icon: BookOpen,
      lessons: [
        { title: "What is Java?", path: "/tutorials/java/what-is-java" },
        { title: "Setting up Java Environment", path: "/tutorials/java/environment-setup" },
        { title: "First Java Program", path: "/tutorials/java/first-program" }
      ]
    },
    {
      title: "Object-Oriented Programming",
      description: "Master OOP concepts in Java",
      icon: Code,
      lessons: [
        { title: "Classes and Objects", path: "/tutorials/java/classes-and-objects" },
        { title: "Inheritance", path: "/tutorials/java/inheritance" },
        { title: "Polymorphism", path: "/tutorials/java/polymorphism" }
      ]
    },
    {
      title: "Java Collections",
      description: "Understanding Java Collections Framework",
      icon: FileCode,
      lessons: [
        { title: "ArrayList", path: "/tutorials/java/arraylist" },
        { title: "HashMap", path: "/tutorials/java/hashmap" },
        { title: "LinkedList", path: "/tutorials/java/linkedlist" }
      ]
    },
    {
      title: "Advanced Java",
      description: "Advanced concepts and features",
      icon: Terminal,
      lessons: [
        { title: "Multithreading", path: "/tutorials/java/multithreading" },
        { title: "Exception Handling", path: "/tutorials/java/exception-handling" },
        { title: "File I/O", path: "/tutorials/java/file-io" }
      ]
    }
  ];

  return (
    <div>
      <h1 className="text-4xl font-bold text-white mb-8">Java Programming Tutorial</h1>
      <p className="text-xl text-white/70 mb-12">
        Master Java programming with our comprehensive tutorial series
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        {topics.map((topic, index) => (
          <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
            <div className="flex items-start mb-4">
              <topic.icon className="h-8 w-8 text-purple-400 mr-4" />
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">{topic.title}</h3>
                <p className="text-white/70 mb-4">{topic.description}</p>
              </div>
            </div>
            <ul className="space-y-2">
              {topic.lessons.map((lesson, lessonIndex) => (
                <li key={lessonIndex} className="flex items-center">
                  <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                  <Link 
                    to={lesson.path}
                    className="text-white/70 hover:text-purple-400 transition-colors"
                  >
                    {lesson.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-white/5 rounded-xl p-8 backdrop-blur-lg border border-white/10">
        <h2 className="text-2xl font-bold text-white mb-4">Ready to Practice?</h2>
        <p className="text-white/70 mb-6">
          Put your Java knowledge to the test with our interactive coding challenges
        </p>
        <Link 
          to="/practice" 
          className="inline-flex items-center px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
        >
          Start Coding
        </Link>
      </div>
    </div>
  );
}

export default JavaTutorial;