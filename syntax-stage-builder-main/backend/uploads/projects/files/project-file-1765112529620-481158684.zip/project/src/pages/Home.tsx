import React from 'react';
import { Link } from 'react-router-dom';
import { Code2, Trophy, Users, Rocket, BookOpen, Brain, Star, Play, ArrowRight, Zap } from 'lucide-react';

function Home() {
  const courses = [
    { 
      title: "Complete Java Course", 
      students: "50K+", 
      level: "Beginner to Pro", 
      icon: Code2,
      rating: 4.9,
      lessons: 120,
      path: "/tutorials/java"
    },
    { 
      title: "Web Development Path", 
      students: "45K+", 
      level: "Step by Step", 
      icon: Rocket,
      rating: 4.8,
      lessons: 180,
      path: "/tutorials/web"
    },
    { 
      title: "Data Structures", 
      students: "30K+", 
      level: "Advanced", 
      icon: Brain,
      rating: 4.7,
      lessons: 90,
      path: "/tutorials/dsa"
    },
  ];

  const articles = [
    {
      title: "Master Modern JavaScript",
      author: "Sarah Johnson",
      readTime: "5 min read",
      image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=500",
      category: "JavaScript",
      path: "/tutorials/javascript"
    },
    {
      title: "CSS Grid Made Simple",
      author: "Mike Chen",
      readTime: "8 min read",
      image: "https://images.unsplash.com/photo-1517134191118-9d595e4c8c2b?auto=format&fit=crop&q=80&w=500",
      category: "CSS",
      path: "/tutorials/css"
    },
    {
      title: "Python for Beginners",
      author: "Alex Turner",
      readTime: "6 min read",
      image: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?auto=format&fit=crop&q=80&w=500",
      category: "Python",
      path: "/tutorials/python"
    }
  ];

  return (
    <div className="bg-[#0A0118]">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/20 via-purple-900/20 to-pink-900/20"></div>
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2072')] bg-cover bg-center opacity-10"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 py-32">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-pink-500/10 to-purple-500/10 border border-purple-500/20 mb-8">
              <Star className="h-4 w-4 text-purple-400 mr-2" />
              <span className="text-purple-400 text-sm font-medium">Rated 4.9/5 from over 100K+ students</span>
            </div>
            <h1 className="text-6xl font-bold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-500 leading-tight">
              Master Coding with Expert-Led Courses
            </h1>
            <p className="text-xl text-white/70 mb-12 leading-relaxed">
              Join millions of learners worldwide and unlock your potential with our comprehensive programming courses. 
              Start your journey to becoming a professional developer today.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
              <Link 
                to="/tutorials"
                className="relative group"
              >
                <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-200"></div>
                <span className="relative px-8 py-4 bg-black rounded-full text-white block text-lg font-semibold">
                  Start Learning Free
                </span>
              </Link>
              <button className="px-8 py-4 rounded-full text-white border-2 border-white/20 hover:bg-white/10 transition-colors text-lg font-semibold flex items-center justify-center">
                Watch Demo <Play className="h-5 w-5 ml-2" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-purple-900/20"></div>
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="grid md:grid-cols-3 gap-12">
            {[
              {
                icon: BookOpen,
                title: "Expert-Led Courses",
                description: "Learn from industry professionals with years of experience"
              },
              {
                icon: Zap,
                title: "Interactive Learning",
                description: "Practice as you learn with hands-on coding exercises"
              },
              {
                icon: Trophy,
                title: "Certification",
                description: "Earn recognized certificates upon course completion"
              }
            ].map((feature, index) => (
              <div key={index} className="relative group">
                <div className="absolute -inset-px bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl opacity-50 group-hover:opacity-100 blur transition duration-200"></div>
                <div className="relative p-8 rounded-2xl bg-black">
                  <feature.icon className="h-12 w-12 text-purple-400 mb-6" />
                  <h3 className="text-2xl font-bold mb-4 text-white">{feature.title}</h3>
                  <p className="text-white/70">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Popular Courses */}
      <div className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-end mb-16">
            <div>
              <h2 className="text-4xl font-bold text-white mb-4">Popular Learning Paths</h2>
              <p className="text-white/70">Choose your path and start learning today</p>
            </div>
            <Link 
              to="/tutorials"
              className="text-purple-400 hover:text-purple-300 flex items-center"
            >
              View All Courses <ArrowRight className="h-5 w-5 ml-2" />
            </Link>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {courses.map((course, index) => (
              <div key={index} className="relative group">
                <div className="absolute -inset-px bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl opacity-50 group-hover:opacity-100 blur transition duration-200"></div>
                <div className="relative p-8 rounded-2xl bg-black">
                  <course.icon className="h-12 w-12 text-purple-400 mb-6" />
                  <h3 className="text-2xl font-bold mb-4 text-white">{course.title}</h3>
                  <div className="flex items-center text-white/70 mb-4">
                    <Users className="h-5 w-5 mr-2 text-purple-400" />
                    <span>{course.students} students</span>
                  </div>
                  <div className="flex items-center mb-6">
                    <div className="flex items-center">
                      <Star className="h-5 w-5 text-yellow-400" />
                      <span className="ml-2 text-white">{course.rating}</span>
                    </div>
                    <span className="mx-3 text-white/30">•</span>
                    <span className="text-white/70">{course.lessons} lessons</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-purple-400">{course.level}</span>
                    <Link 
                      to={course.path}
                      className="text-white hover:text-purple-400 font-semibold flex items-center"
                    >
                      Start Learning <ArrowRight className="h-5 w-5 ml-2" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Latest Articles */}
      <div className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-end mb-16">
            <div>
              <h2 className="text-4xl font-bold text-white mb-4">Latest Resources</h2>
              <p className="text-white/70">Stay updated with our latest tutorials and articles</p>
            </div>
            <Link 
              to="/blog"
              className="text-purple-400 hover:text-purple-300 flex items-center"
            >
              View All Articles <ArrowRight className="h-5 w-5 ml-2" />
            </Link>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {articles.map((article, index) => (
              <div key={index} className="relative group">
                <div className="absolute -inset-px bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl opacity-50 group-hover:opacity-100 blur transition duration-200"></div>
                <div className="relative rounded-2xl bg-black overflow-hidden">
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={article.image} 
                      alt={article.title} 
                      className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500" 
                    />
                  </div>
                  <div className="p-8">
                    <span className="inline-block px-3 py-1 rounded-full text-sm font-medium bg-purple-500/20 text-purple-400 mb-4">
                      {article.category}
                    </span>
                    <Link to={article.path}>
                      <h3 className="text-xl font-bold mb-4 text-white group-hover:text-purple-400 transition-colors">
                        {article.title}
                      </h3>
                    </Link>
                    <div className="flex justify-between items-center text-sm text-white/70">
                      <span className="font-medium">{article.author}</span>
                      <span>{article.readTime}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="relative py-24">
        <div className="absolute inset-0 bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-blue-500/20"></div>
        <div className="relative max-w-4xl mx-auto text-center px-4">
          <h2 className="text-5xl font-bold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-500">
            Ready to Transform Your Career?
          </h2>
          <p className="text-xl text-white/70 mb-12">
            Join our community of over 100,000 developers and start your journey today.
            Get unlimited access to all our courses and resources.
          </p>
          <Link to="/signup" className="relative group inline-block">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-200"></div>
            <span className="relative px-8 py-4 bg-black rounded-full text-white block text-lg font-semibold">
              Get Started For Free
            </span>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Home;