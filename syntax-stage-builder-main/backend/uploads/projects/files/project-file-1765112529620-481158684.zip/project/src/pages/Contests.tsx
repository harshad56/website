import React from 'react';
import { Trophy, Calendar, Clock, Users, Award, ChevronRight } from 'lucide-react';

function Contests() {
  const contests = [
    {
      title: "Weekly Coding Challenge",
      date: "March 15, 2024",
      time: "2:00 PM GMT",
      duration: "2 hours",
      participants: "1.2K",
      difficulty: "Medium",
      prizes: ["$500", "$300", "$200"],
      status: "Upcoming"
    },
    {
      title: "Data Structures Championship",
      date: "March 20, 2024",
      time: "3:00 PM GMT",
      duration: "3 hours",
      participants: "856",
      difficulty: "Hard",
      prizes: ["$1000", "$500", "$250"],
      status: "Upcoming"
    },
    {
      title: "Algorithms Grand Prix",
      date: "March 25, 2024",
      time: "1:00 PM GMT",
      duration: "4 hours",
      participants: "2.1K",
      difficulty: "Hard",
      prizes: ["$2000", "$1000", "$500"],
      status: "Upcoming"
    }
  ];

  const pastContests = [
    {
      title: "Python Challenge",
      date: "March 1, 2024",
      participants: "1.5K",
      winner: "John Doe",
      score: "950"
    },
    {
      title: "Frontend Masters",
      date: "March 5, 2024",
      participants: "1.1K",
      winner: "Jane Smith",
      score: "920"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-white mb-4">Coding Contests</h1>
        <p className="text-xl text-white/70">Compete with developers worldwide</p>
      </div>

      {/* Upcoming Contests */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-white mb-6">Upcoming Contests</h2>
        <div className="space-y-6">
          {contests.map((contest, index) => (
            <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10 hover:border-purple-500/50 transition-colors">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div className="flex-1">
                  <div className="flex items-center mb-4">
                    <Trophy className="h-6 w-6 text-purple-400 mr-3" />
                    <h3 className="text-xl font-semibold text-white">{contest.title}</h3>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div className="flex items-center text-white/70">
                      <Calendar className="h-4 w-4 mr-2" />
                      {contest.date}
                    </div>
                    <div className="flex items-center text-white/70">
                      <Clock className="h-4 w-4 mr-2" />
                      {contest.time}
                    </div>
                    <div className="flex items-center text-white/70">
                      <Users className="h-4 w-4 mr-2" />
                      {contest.participants} registered
                    </div>
                    <div className="flex items-center text-white/70">
                      <Award className="h-4 w-4 mr-2" />
                      {contest.difficulty}
                    </div>
                  </div>

                  <div className="flex items-center space-x-6">
                    <div>
                      <span className="text-white/70 text-sm">Duration:</span>
                      <span className="ml-2 text-white">{contest.duration}</span>
                    </div>
                    <div>
                      <span className="text-white/70 text-sm">Prizes:</span>
                      <div className="inline-flex items-center space-x-2 ml-2">
                        {contest.prizes.map((prize, prizeIndex) => (
                          <span key={prizeIndex} className="text-purple-400">{prize}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 md:mt-0 md:ml-6">
                  <button className="w-full md:w-auto px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors flex items-center justify-center">
                    Register Now
                    <ChevronRight className="h-4 w-4 ml-2" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Past Contests */}
      <div>
        <h2 className="text-2xl font-bold text-white mb-6">Past Contests</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {pastContests.map((contest, index) => (
            <div key={index} className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
              <h3 className="text-lg font-semibold text-white mb-4">{contest.title}</h3>
              <div className="space-y-2 text-white/70">
                <div className="flex justify-between">
                  <span>Date:</span>
                  <span>{contest.date}</span>
                </div>
                <div className="flex justify-between">
                  <span>Participants:</span>
                  <span>{contest.participants}</span>
                </div>
                <div className="flex justify-between">
                  <span>Winner:</span>
                  <span className="text-purple-400">{contest.winner}</span>
                </div>
                <div className="flex justify-between">
                  <span>Winning Score:</span>
                  <span className="text-purple-400">{contest.score}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Contests;