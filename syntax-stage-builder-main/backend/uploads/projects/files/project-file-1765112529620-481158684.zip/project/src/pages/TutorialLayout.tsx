import React from 'react';
import { Outlet } from 'react-router-dom';

function TutorialLayout() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <Outlet />
    </div>
  );
}

export default TutorialLayout;