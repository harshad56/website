import React from 'react';
import { BookOpen, Code, PlayCircle } from 'lucide-react';
import TutorialNavigation from '../../../components/TutorialNavigation';
import ProgressTracker from '../../../components/ProgressTracker';

function WhatIsJava() {
  const steps = [
    "Introduction",
    "Environment Setup",
    "First Program",
    "Variables",
    "Control Flow"
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <ProgressTracker steps={steps} currentStep={0} />
      
      <h1 className="text-3xl font-bold text-white mb-6">What is Java?</h1>
      
      <div className="space-y-8">
        {/* Introduction */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Introduction to Java</h2>
          <p className="text-white/80 leading-relaxed mb-4">
            Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible. Created by James Gosling at Sun Microsystems, Java is now owned by Oracle Corporation.
          </p>
          <div className="flex items-center space-x-4 text-purple-400">
            <BookOpen className="h-5 w-5" />
            <span>Reading time: 10 minutes</span>
          </div>
        </section>

        {/* Key Features */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Key Features</h2>
          <ul className="space-y-4">
            {[
              {
                title: "Platform Independence",
                description: "Write once, run anywhere (WORA) - Java code can run on any platform with a JVM."
              },
              {
                title: "Object-Oriented",
                description: "Based on the concept of objects containing data and code."
              },
              {
                title: "Simple and Secure",
                description: "Designed to be easy to learn and provide robust security features."
              },
              {
                title: "Distributed",
                description: "Designed to make distributed computing easy with networking capability."
              }
            ].map((feature, index) => (
              <li key={index} className="bg-white/5 rounded-lg p-4">
                <h3 className="text-lg font-medium text-purple-400 mb-2">{feature.title}</h3>
                <p className="text-white/70">{feature.description}</p>
              </li>
            ))}
          </ul>
        </section>

        {/* Example Code */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Your First Java Program</h2>
          <div className="bg-black/50 rounded-lg p-4 mb-4">
            <pre className="text-white/90 overflow-x-auto">
              <code>{`public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}`}</code>
            </pre>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-purple-400">
              <Code className="h-5 w-5" />
              <span>Simple Hello World Program</span>
            </div>
            <button className="flex items-center space-x-2 bg-purple-500/20 text-purple-400 px-4 py-2 rounded-lg hover:bg-purple-500/30 transition-colors">
              <PlayCircle className="h-5 w-5" />
              <span>Run Code</span>
            </button>
          </div>
        </section>

        {/* Applications */}
        <section className="bg-white/5 rounded-xl p-6 backdrop-blur-lg border border-white/10">
          <h2 className="text-2xl font-semibold text-white mb-4">Applications of Java</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {[
              {
                title: "Android Development",
                description: "Primary language for Android app development"
              },
              {
                title: "Enterprise Software",
                description: "Widely used in building enterprise-level applications"
              },
              {
                title: "Web Applications",
                description: "Powers many web applications through Spring Framework"
              },
              {
                title: "Cloud Computing",
                description: "Used in building scalable cloud applications"
              }
            ].map((app, index) => (
              <div key={index} className="bg-white/5 rounded-lg p-4">
                <h3 className="text-lg font-medium text-purple-400 mb-2">{app.title}</h3>
                <p className="text-white/70">{app.description}</p>
              </div>
            ))}
          </div>
        </section>

        <TutorialNavigation
          nextPath="/tutorials/java/environment-setup"
          nextLabel="Next: Setting up Java Environment"
        />
      </div>
    </div>
  );
}

export default WhatIsJava;