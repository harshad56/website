package com.example.projectodsem3.config;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import com.example.projectodsem3.service.DataCache;
import com.example.projectodsem3.service.DataPersistenceService;
import com.example.projectodsem3.service.ExpandedCsvProcessingService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataLoader implements ApplicationRunner {

	private final ExpandedCsvProcessingService expandedCsvProcessingService;
	private final DataCache dataCache;
	private final DataPersistenceService persistence;

	@Value("${app.data.autoload.enabled:true}")
	private boolean autoloadEnabled;

	@Value("${app.data.autoload.path:expanded_disease_symptom_data.csv}")
	private String autoloadPath;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		// 1) Try DB first
		if (persistence.hasData()) {
			log.info("Loading dataset from database...");
			Map<String, Object> fromDb = persistence.loadAll();
			@SuppressWarnings("unchecked") List<?> d = (List<?>) fromDb.get("diseases");
			@SuppressWarnings("unchecked") List<?> s = (List<?>) fromDb.get("symptoms");
			@SuppressWarnings("unchecked") List<?> c = (List<?>) fromDb.get("correlations");
			dataCache.setData((List) d, (List) s, (List) c);
			log.info("Loaded from DB: diseases={}, symptoms={}, correlations={}", d.size(), s.size(), c.size());
			return;
		}

		// 2) Fall back to CSV if enabled
		if (!autoloadEnabled) {
			log.info("Autoload disabled (app.data.autoload.enabled=false) and DB is empty");
			return;
		}
		FileSystemResource resource = new FileSystemResource(autoloadPath);
		if (!resource.exists()) {
			log.warn("Autoload file not found at {}. Upload via API or adjust app.data.autoload.path", autoloadPath);
			return;
		}
		log.info("Autoloading dataset from {}...", autoloadPath);
		Map<String, Object> result = expandedCsvProcessingService.processExpandedCsv(resource);
		@SuppressWarnings("unchecked") List<?> diseases = (List<?>) result.get("diseases");
		@SuppressWarnings("unchecked") List<?> symptoms = (List<?>) result.get("symptoms");
		@SuppressWarnings("unchecked") List<?> correlations = (List<?>) result.get("correlations");
		dataCache.setData((List) diseases, (List) symptoms, (List) correlations);
		log.info("Autoloaded: diseases={}, symptoms={}, correlations={}", result.get("totalDiseases"), result.get("totalSymptoms"), result.get("totalCorrelations"));

		// 3) Persist to DB for future startups
		persistence.persistAll((List) diseases, (List) symptoms, (List) correlations);
	}
}
