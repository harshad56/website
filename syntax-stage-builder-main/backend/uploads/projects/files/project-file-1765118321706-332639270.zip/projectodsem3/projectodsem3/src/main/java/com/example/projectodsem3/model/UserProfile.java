package com.example.projectodsem3.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "user_profiles")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private Integer age;

    @Enumerated(EnumType.STRING)
    @Column(name = "blood_group")
    private BloodGroup bloodGroup;

    @Column(name = "height_cm")
    private Double heightCm;

    @Column(name = "weight_kg")
    private Double weightKg;

    @Enumerated(EnumType.STRING)
    private Gender gender;

    @Column(name = "contact_number")
    private String contactNumber;

    @Column(name = "emergency_contact")
    private String emergencyContact;

    @Column(name = "medical_history", columnDefinition = "TEXT")
    private String medicalHistory;

    @Column(name = "allergies", columnDefinition = "TEXT")
    private String allergies;

    @Column(name = "current_medications", columnDefinition = "TEXT")
    private String currentMedications;

    @Column(name = "lifestyle_factors", columnDefinition = "TEXT")
    private String lifestyleFactors; // smoking, alcohol, exercise, diet

    @Column(name = "created_at")
    private LocalDate createdAt;

    @Column(name = "last_updated")
    private LocalDate lastUpdated;

    @OneToMany(mappedBy = "userProfile", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<PredictionHistory> predictionHistory;

    // Enums
    public enum BloodGroup {
        A_POSITIVE("A+"), A_NEGATIVE("A-"),
        B_POSITIVE("B+"), B_NEGATIVE("B-"),
        AB_POSITIVE("AB+"), AB_NEGATIVE("AB-"),
        O_POSITIVE("O+"), O_NEGATIVE("O-");

        private final String displayValue;

        BloodGroup(String displayValue) {
            this.displayValue = displayValue;
        }

        public String getDisplayValue() {
            return displayValue;
        }
    }

    public enum Gender {
        MALE("Male"), FEMALE("Female"), OTHER("Other");

        private final String displayValue;

        Gender(String displayValue) {
            this.displayValue = displayValue;
        }

        public String getDisplayValue() {
            return displayValue;
        }
    }

    // Helper methods
    public Double getBmi() {
        if (heightCm != null && weightKg != null && heightCm > 0) {
            double heightM = heightCm / 100.0;
            return weightKg / (heightM * heightM);
        }
        return null;
    }

    public String getBmiCategory() {
        Double bmi = getBmi();
        if (bmi == null)
            return "Unknown";

        if (bmi < 18.5)
            return "Underweight";
        else if (bmi < 25)
            return "Normal weight";
        else if (bmi < 30)
            return "Overweight";
        else
            return "Obese";
    }

    public String getAgeGroup() {
        if (age == null)
            return "Unknown";

        if (age < 18)
            return "Child/Teen";
        else if (age < 30)
            return "Young Adult";
        else if (age < 50)
            return "Adult";
        else if (age < 65)
            return "Middle-aged";
        else
            return "Senior";
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDate.now();
        lastUpdated = LocalDate.now();
    }

    @PreUpdate
    protected void onUpdate() {
        lastUpdated = LocalDate.now();
    }
}
