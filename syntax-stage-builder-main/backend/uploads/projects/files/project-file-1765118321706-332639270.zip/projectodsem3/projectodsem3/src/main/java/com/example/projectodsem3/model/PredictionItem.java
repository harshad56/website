package com.example.projectodsem3.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "prediction_items")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PredictionItem {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "disease_name")
    private String diseaseName;
    
    @Column(name = "confidence_score")
    private Double confidenceScore;
    
    @Column(name = "risk_level")
    private String riskLevel;
    
    @Column(name = "recommendations", columnDefinition = "TEXT")
    private String recommendations;
    
    @Column(name = "matched_symptoms", columnDefinition = "TEXT")
    private String matchedSymptoms;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "prediction_history_id")
    private PredictionHistory predictionHistory;
}
