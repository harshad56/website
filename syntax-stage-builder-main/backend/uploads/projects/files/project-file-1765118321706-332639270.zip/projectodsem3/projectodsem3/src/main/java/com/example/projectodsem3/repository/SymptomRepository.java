package com.example.projectodsem3.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.projectodsem3.model.Symptom;

public interface SymptomRepository extends JpaRepository<Symptom, Long> {
	Optional<Symptom> findByNameIgnoreCase(String name);
}
