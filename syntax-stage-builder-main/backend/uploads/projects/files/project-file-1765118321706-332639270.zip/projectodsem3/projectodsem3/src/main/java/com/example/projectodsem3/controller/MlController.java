package com.example.projectodsem3.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.projectodsem3.service.MlPredictionService;

@RestController
@RequestMapping("/api/medical/ml")
@CrossOrigin(origins = "*")
public class MlController {

    private final MlPredictionService mlPredictionService;

    public MlController(MlPredictionService mlPredictionService) {
        this.mlPredictionService = mlPredictionService;
    }

    // Train/rebuild model from current cached dataset
    @PostMapping("/rebuild")
    public ResponseEntity<?> rebuild() {
        mlPredictionService.forceRebuildModel();
        return ResponseEntity.ok(Map.of("message", "ML model rebuilt from correlations"));
    }

    // Predict top-K diseases using ML model without changing existing endpoints
    @PostMapping("/predict")
    public ResponseEntity<?> predict(@RequestBody MlRequest req) {
        List<MlPredictionService.MlPredictionResult> results = mlPredictionService.predict(req.getSymptoms(),
                req.getTopK() != null ? req.getTopK() : 5);
        return ResponseEntity.ok(Map.of(
                "inputSymptoms", req.getSymptoms(),
                "totalResults", results.size(),
                "predictions", results));
    }

    // Build correlation heatmap data (disease x symptom)
    @GetMapping("/heatmap")
    public ResponseEntity<?> heatmap(@RequestParam(defaultValue = "20") Integer topDiseases,
            @RequestParam(defaultValue = "20") Integer topSymptoms) {
        MlPredictionService.HeatmapData data = mlPredictionService.buildHeatmapData(topDiseases, topSymptoms);
        return ResponseEntity.ok(data);
    }

    public static class MlRequest {
        private List<String> symptoms;
        private Integer topK;

        public List<String> getSymptoms() {
            return symptoms;
        }

        public void setSymptoms(List<String> symptoms) {
            this.symptoms = symptoms;
        }

        public Integer getTopK() {
            return topK;
        }

        public void setTopK(Integer topK) {
            this.topK = topK;
        }
    }
}