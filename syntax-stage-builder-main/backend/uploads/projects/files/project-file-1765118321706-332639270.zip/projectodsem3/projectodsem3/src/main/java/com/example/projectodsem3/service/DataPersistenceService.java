package com.example.projectodsem3.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.projectodsem3.model.Disease;
import com.example.projectodsem3.model.Symptom;
import com.example.projectodsem3.model.SymptomDiseaseCorrelation;
import com.example.projectodsem3.repository.DiseaseRepository;
import com.example.projectodsem3.repository.SymptomDiseaseCorrelationRepository;
import com.example.projectodsem3.repository.SymptomRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class DataPersistenceService {

	private final DiseaseRepository diseaseRepository;
	private final SymptomRepository symptomRepository;
	private final SymptomDiseaseCorrelationRepository correlationRepository;

	@Transactional
	public void persistAll(List<Disease> diseases, List<Symptom> symptoms,
			List<SymptomDiseaseCorrelation> correlations) {
		log.info("Persisting dataset: diseases={}, symptoms={}, correlations={}", diseases.size(), symptoms.size(),
				correlations.size());

		// 1) Upsert Symptoms by name
		Map<String, Symptom> nameToSymptom = new HashMap<>();
		// preload existing to reduce queries
		if (!symptoms.isEmpty()) {
			List<String> names = symptoms.stream().map(Symptom::getName).filter(n -> n != null && !n.isBlank())
					.distinct().collect(Collectors.toList());
			for (String n : names) {
				Optional<Symptom> ex = symptomRepository.findByNameIgnoreCase(n);
				ex.ifPresent(s -> nameToSymptom.put(n.toLowerCase(), s));
			}
		}
		List<Symptom> toCreateSymptoms = new ArrayList<>();
		for (Symptom s : symptoms) {
			if (s.getName() == null)
				continue;
			String key = s.getName().toLowerCase();
			if (!nameToSymptom.containsKey(key)) {
				toCreateSymptoms.add(s);
			}
		}
		if (!toCreateSymptoms.isEmpty()) {
			symptomRepository.saveAll(toCreateSymptoms);
			for (Symptom s : toCreateSymptoms)
				nameToSymptom.put(s.getName().toLowerCase(), s);
		}

		// 2) Upsert Diseases by name
		Map<String, Disease> nameToDisease = new HashMap<>();
		if (!diseases.isEmpty()) {
			List<String> dnames = diseases.stream().map(Disease::getName).filter(n -> n != null && !n.isBlank())
					.distinct().collect(Collectors.toList());
			for (String n : dnames) {
				Optional<Disease> ex = diseaseRepository.findByNameIgnoreCase(n);
				ex.ifPresent(d -> nameToDisease.put(n.toLowerCase(), d));
			}
		}
		List<Disease> toCreateDiseases = new ArrayList<>();
		for (Disease d : diseases) {
			if (d.getName() == null)
				continue;
			String key = d.getName().toLowerCase();
			if (!nameToDisease.containsKey(key)) {
				toCreateDiseases.add(d);
			}
		}
		if (!toCreateDiseases.isEmpty()) {
			diseaseRepository.saveAll(toCreateDiseases);
			for (Disease d : toCreateDiseases)
				nameToDisease.put(d.getName().toLowerCase(), d);
		}

		// 3) Replace correlations (simplest, idempotent upload behavior)
		correlationRepository.deleteAllInBatch();
		List<SymptomDiseaseCorrelation> attached = new ArrayList<>();
		for (SymptomDiseaseCorrelation c : correlations) {
			if (c.getDisease() == null || c.getSymptom() == null)
				continue;
			Disease d = nameToDisease
					.getOrDefault(c.getDisease().getName() != null ? c.getDisease().getName().toLowerCase() : "", null);
			Symptom s = nameToSymptom
					.getOrDefault(c.getSymptom().getName() != null ? c.getSymptom().getName().toLowerCase() : "", null);
			if (d != null && s != null) {
				SymptomDiseaseCorrelation nc = new SymptomDiseaseCorrelation();
				nc.setDisease(d);
				nc.setSymptom(s);
				nc.setCorrelationWeight(c.getCorrelationWeight());
				nc.setConfidence(c.getConfidence());
				nc.setNotes(c.getNotes());
				nc.setIsPrimarySymptom(c.getIsPrimarySymptom());
				nc.setIsSecondarySymptom(c.getIsSecondarySymptom());
				nc.setSymptomOrder(c.getSymptomOrder());
				attached.add(nc);
			}
		}
		if (!attached.isEmpty()) {
			correlationRepository.saveAll(attached);
		}
		log.info("Persist complete (upsert symptoms/diseases, replace correlations). Saved correlations: {}",
				attached.size());
	}

	@Transactional(readOnly = true)
	public boolean hasData() {
		return diseaseRepository.count() > 0 && symptomRepository.count() > 0 && correlationRepository.count() > 0;
	}

	@Transactional(readOnly = true)
	public Map<String, Object> loadAll() {
		List<Disease> diseases = diseaseRepository.findAll();
		List<Symptom> symptoms = symptomRepository.findAll();
		List<SymptomDiseaseCorrelation> correlations = correlationRepository.findAll();
		Map<String, Object> map = new HashMap<>();
		map.put("diseases", diseases);
		map.put("symptoms", symptoms);
		map.put("correlations", correlations);
		return map;
	}

	@Transactional
	public void clearAllData() {
		log.info("Clearing all database data");
		correlationRepository.deleteAllInBatch();
		diseaseRepository.deleteAllInBatch();
		symptomRepository.deleteAllInBatch();
		log.info("All database data cleared successfully");
	}
}
