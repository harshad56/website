# Medical Symptom Analyzer - Disease Prediction System

A web-based medical symptom analyzer that uses machine learning algorithms to predict potential diseases based on user-input symptoms. This system provides accurate, ranked disease predictions and personalized risk assessments.

## 🏥 Project Overview

This project implements a comprehensive medical symptom analysis system that:
- **Analyzes symptoms** using machine learning algorithms
- **Predicts diseases** with confidence scoring
- **Provides risk assessments** based on multiple factors
- **Offers personalized recommendations** for healthcare
- **Processes medical data** from CSV files
- **Generates analytics** and pattern recognition
- **Supports expanded datasets** with 10,000+ medical records

## 🚀 Features

### Core Functionality
- **Disease Prediction Engine**: ML-based symptom-to-disease mapping
- **Risk Assessment System**: Multi-factor risk calculation (age, symptoms, demographics)
- **CSV Data Processing**: Import medical datasets for analysis
- **Statistical Analytics**: Disease pattern analysis and visualization
- **RESTful API**: Complete backend services for web applications
- **Expanded Dataset Support**: Handle comprehensive medical datasets with rich metadata

### Machine Learning Components
- **Weighted Symptom Matching**: Correlation-based disease scoring
- **Confidence Scoring**: Probability-based disease ranking
- **Risk Level Classification**: Low/Medium/High risk categorization
- **Pattern Recognition**: Symptom-disease relationship analysis
- **Enhanced Risk Calculation**: Severity, mortality rate, and age group factors

## 🛠️ Technology Stack

- **Backend**: Spring Boot 3.5.5, Java 17
- **Database**: H2 (development), MySQL (production ready)
- **Machine Learning**: Apache Commons Math, Custom ML algorithms
- **Data Processing**: OpenCSV for medical data import
- **API**: RESTful web services with JSON responses
- **Build Tool**: Maven

## 📁 Project Structure

```
projectodsem3/
├── src/main/java/com/example/projectodsem3/
│   ├── controller/
│   │   └── MedicalDataController.java          # REST API endpoints
│   ├── model/
│   │   ├── Disease.java                        # Disease entity
│   │   ├── Symptom.java                        # Symptom entity
│   │   └── SymptomDiseaseCorrelation.java      # Correlation mapping
│   ├── service/
│   │   ├── CsvProcessingService.java           # Basic CSV processing
│   │   ├── ExpandedCsvProcessingService.java   # Enhanced CSV processing
│   │   └── DiseasePredictionService.java       # ML prediction engine
│   └── Projectodsem3Application.java           # Main application
├── src/main/resources/
│   ├── application.properties                  # Configuration
│   └── sample_data/                            # Sample CSV files
│       ├── diseases.csv                        # Disease dataset
│       ├── symptoms.csv                        # Symptom dataset
│       └── correlations.csv                    # Symptom-disease correlations
├── expanded_disease_symptom_data.csv           # Comprehensive medical dataset
├── test_expanded_dataset.sh                    # Test script for expanded dataset
└── pom.xml                                     # Dependencies
```

## 🚀 Quick Start

### Prerequisites
- Java 17 or higher
- Maven 3.6+
- Git

### Installation & Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd projectodsem3
   ```

2. **Build the project**
   ```bash
   mvn clean install
   ```

3. **Run the application**
   ```bash
   mvn spring-boot:run
   ```

4. **Access the application**
   - Application: http://localhost:8080
   - H2 Database Console: http://localhost:8080/h2-console
   - API Documentation: Available at `/api/medical/*`

## 📊 CSV Data Formats

### 1. Basic Format (Sample Data)
#### Diseases CSV (`diseases.csv`)
```csv
name,description,symptoms,treatment,prevention,severity,category,riskscore,agegroupmin,agegroupmax,genderpreference,ischronic,iscontagious
Diabetes,Chronic condition affecting blood sugar levels,Fatigue,Increased thirst,Frequent urination,Insulin therapy,Diet management,Exercise,Regular monitoring,MEDIUM,Endocrine,7.5,20,80,Both,true,false
```

#### Symptoms CSV (`symptoms.csv`)
```csv
name,description,category,severity,iscommon,bodypart,frequency,duration,isemergency,relatedsymptoms
Fatigue,Extreme tiredness and lack of energy,General,6.5,true,Whole body,Constant,Variable,false,Weakness,Lethargy
```

#### Correlations CSV (`correlations.csv`)
```csv
symptom,disease,correlationweight,confidence,notes,primary,secondary,order
Fatigue,Diabetes,8.5,0.9,Common symptom of diabetes,true,false,1
```

### 2. Expanded Format (Your Dataset)
#### Expanded Disease-Symptom CSV (`expanded_disease_symptom_data.csv`)
```csv
Disease,Symptom,Severity,Age Group,Onset Time,Duration,Treatment,Complications,Prevention,Risk Factors,Transmission Mode,Contagious,Diagnosis Method,Mortality Rate
Arthritis,Severe headache,Mild,Adult,Sudden,Variable,No treatment,Respiratory issues,Healthy lifestyle,Smoking,Unknown,No,Blood test,High
```

**Features of Expanded Dataset:**
- **10,000+ medical records** with comprehensive information
- **Rich metadata** including severity, age groups, onset time, duration
- **Treatment and prevention** information for each disease-symptom pair
- **Risk factors** and transmission modes
- **Diagnosis methods** and mortality rates
- **Age-specific** disease patterns (Child/Adult/Senior)

## 🔌 API Endpoints

### Data Upload
- `POST /api/medical/upload/diseases` - Upload basic diseases CSV
- `POST /api/medical/upload/symptoms` - Upload basic symptoms CSV  
- `POST /api/medical/upload/correlations` - Upload basic correlations CSV
- `POST /api/medical/upload/expanded` - Upload expanded disease-symptom dataset

### Disease Prediction
- `POST /api/medical/predict` - Predict diseases from symptoms
- `GET /api/medical/symptoms` - Get all available symptoms
- `GET /api/medical/diseases` - Get all available diseases

### Analytics
- `GET /api/medical/analytics` - Get basic disease pattern analytics
- `GET /api/medical/analytics/expanded` - Get comprehensive expanded dataset analytics

## 💡 Usage Examples

### 1. Upload Expanded Medical Dataset (Recommended)
```bash
# Upload your comprehensive dataset
curl -X POST -F "file=@expanded_disease_symptom_data.csv" http://localhost:8080/api/medical/upload/expanded

# Get expanded analytics
curl http://localhost:8080/api/medical/analytics/expanded
```

### 2. Upload Basic Medical Data
```bash
# Upload diseases
curl -X POST -F "file=@sample_data/diseases.csv" http://localhost:8080/api/medical/upload/diseases

# Upload symptoms
curl -X POST -F "file=@sample_data/symptoms.csv" http://localhost:8080/api/medical/upload/symptoms

# Upload correlations
curl -X POST -F "file=@sample_data/correlations.csv" http://localhost:8080/api/medical/upload/correlations
```

### 3. Predict Diseases
```bash
curl -X POST http://localhost:8080/api/medical/predict \
  -H "Content-Type: application/json" \
  -d '{
    "symptoms": ["Severe headache", "Chest pain", "Difficulty breathing"],
    "age": 45,
    "gender": "Male"
  }'
```

### 4. Test Expanded Dataset
```bash
# Make the test script executable
chmod +x test_expanded_dataset.sh

# Run the test
./test_expanded_dataset.sh
```

## 🧠 Enhanced Machine Learning Algorithm

The expanded disease prediction system uses an **advanced weighted correlation algorithm**:

1. **Symptom Matching**: Compares input symptoms with disease-symptom correlations
2. **Weighted Scoring**: Applies correlation weights and confidence levels
3. **Demographic Factors**: Considers age, gender, and risk factors
4. **Risk Assessment**: Calculates personalized risk levels with severity and mortality factors
5. **Recommendation Generation**: Provides healthcare recommendations
6. **Enhanced Factors**: Onset time, duration, complications, and transmission modes

### Algorithm Features
- **Primary vs Secondary Symptoms**: Different weights for symptom importance
- **Age Group Matching**: Bonuses for age-appropriate diseases (Child/Adult/Senior)
- **Gender Considerations**: Gender-specific disease factors
- **Severity-Based Scoring**: Mild/Moderate/Severe classification
- **Mortality Rate Integration**: High/Moderate/Low risk assessment
- **Onset Time Analysis**: Sudden vs Gradual symptom development
- **Duration Classification**: Short-term vs Long-term conditions

## 📈 Sample Output from Expanded Dataset

```json
{
  "predictions": [
    {
      "disease": {
        "name": "Heart Disease",
        "category": "Cardiovascular",
        "severity": "Severe",
        "description": "Disease: Heart Disease, Age Group: Adult, Onset: Sudden, Duration: Variable"
      },
      "confidenceScore": 89.2,
      "matchedSymptoms": ["Severe headache", "Chest pain", "Difficulty breathing"],
      "riskLevel": "HIGH",
      "recommendations": [
        "High probability match - Consider consulting a healthcare professional",
        "Treatment: Medication, Lifestyle changes, Diet modification",
        "Prevention: Healthy lifestyle, Regular exercise"
      ]
    }
  ],
  "totalResults": 1,
  "inputSymptoms": ["Severe headache", "Chest pain", "Difficulty breathing"],
  "age": 45,
  "gender": "Male"
}
```

## 🔧 Configuration

### Database Configuration
- **Development**: H2 in-memory database
- **Production**: MySQL (configure in `application.properties`)

### File Upload Limits
- Maximum file size: 10MB
- Supported formats: CSV
- **Expanded dataset**: Optimized for large medical datasets

### Logging
- Debug level logging for development
- Configurable log levels in `application.properties`

## 🧪 Testing

### Test the Expanded System
1. Start the application
2. Upload the expanded CSV file: `expanded_disease_symptom_data.csv`
3. Use the prediction API with symptoms from the expanded dataset
4. Verify analytics and recommendations

### Sample Test Cases with Expanded Data
- **Cardiovascular**: Severe headache + Chest pain + Difficulty breathing
- **Respiratory**: Fever + Cough + Shortness of breath
- **Neurological**: Memory loss + Confusion + Sleep disturbances
- **Digestive**: Abdominal pain + Nausea + Vomiting

### Run Automated Test
```bash
./test_expanded_dataset.sh
```

## 🚨 Important Notes

- **Medical Disclaimer**: This system is for educational/research purposes only
- **Not Medical Advice**: Always consult healthcare professionals for medical decisions
- **Data Accuracy**: Ensure CSV data quality for reliable predictions
- **Security**: Implement authentication for production use
- **Dataset Size**: The expanded dataset provides much more comprehensive coverage

## 🔮 Future Enhancements

- **Advanced ML Models**: Integration with TensorFlow/PyTorch
- **Real-time Learning**: Continuous model improvement
- **Mobile App**: React Native/Flutter applications
- **AI Chatbot**: Natural language symptom input
- **Integration**: EHR system connectivity
- **Data Visualization**: Interactive dashboards for medical analytics

## 📚 Research Applications

This project serves as a foundation for:
- **Healthcare Informatics Research**
- **Medical Data Analytics**
- **Machine Learning in Medicine**
- **Public Health Studies**
- **Medical Education Tools**
- **Large-Scale Medical Dataset Analysis**

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is for educational and research purposes.

## 👥 Team

- **Harshad Bagal** - Project Lead
- **Ramavtar Varma** - Development
- **Ganesh Kodi** - Research & Analysis

**Under the guidance of Prof. Sudeshna Roy**

---

**Bharati Vidyapeeth's Institute of Management and Information Technology, Navi Mumbai**
**Batch: 2024-26 | Masters of Computer Application (SEM-III)**
