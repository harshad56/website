package com.example.projectodsem3.config;

import java.sql.Connection;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DynamicDataSourceConfig {

    private static final Logger LOGGER = Logger.getLogger(DynamicDataSourceConfig.class.getName());

    @Bean
    @Primary
    public DataSource dataSource(Environment env) {
        String url = env.getProperty("spring.datasource.url");
        String username = env.getProperty("spring.datasource.username");
        String password = env.getProperty("spring.datasource.password");
        String driver = env.getProperty("spring.datasource.driver-class-name");

        // If MySQL URL present, try it; else fall back to H2 immediately
        if (url != null && url.startsWith("jdbc:mysql")) {
            try {
                DataSource mysql = buildMysqlDataSource(url, username, password, driver);
                // Fast connectivity check with small timeout
                try (Connection c = mysql.getConnection()) {
                    // Connected successfully
                }
                LOGGER.info("Using MySQL DataSource: " + url);
                return mysql;
            } catch (Exception ex) {
                LOGGER.log(Level.WARNING,
                        "MySQL not available, falling back to H2 in-memory DB. Reason: " + ex.getMessage());
            }
        }

        // Fallback: H2 in MySQL compatibility mode
        HikariConfig hc = new HikariConfig();
        hc.setJdbcUrl(
                "jdbc:h2:mem:medical_db;MODE=MySQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE");
        hc.setDriverClassName("org.h2.Driver");
        hc.setUsername(Objects.toString(username, "sa"));
        hc.setPassword(Objects.toString(password, ""));
        hc.setMaximumPoolSize(5);
        hc.setConnectionTimeout(3000);
        LOGGER.info("Using H2 in-memory DataSource (MySQL compatibility mode)");
        return new HikariDataSource(hc);
    }

    private DataSource buildMysqlDataSource(String url, String username, String password, String driver) {
        HikariConfig hc = new HikariConfig();
        hc.setJdbcUrl(url);
        if (driver != null && !driver.isBlank())
            hc.setDriverClassName(driver);
        if (username != null)
            hc.setUsername(username);
        if (password != null)
            hc.setPassword(password);
        hc.setMaximumPoolSize(10);
        hc.setConnectionTimeout(3000); // 3s quick fail
        return new HikariDataSource(hc);
    }
}