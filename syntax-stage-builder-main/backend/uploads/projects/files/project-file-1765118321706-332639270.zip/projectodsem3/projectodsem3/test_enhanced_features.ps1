# Test Enhanced Medical Symptom Analyzer Features
# This script tests the new user profile and enhanced prediction endpoints

Write-Host "Testing Enhanced Medical Symptom Analyzer Features..." -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Green

# Wait for application to start
Write-Host "Waiting for application to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 10

# Test 1: Create User Profile
Write-Host "`n1. Testing User Profile Creation..." -ForegroundColor Cyan
$profileData = @{
    name = "John Doe"
    age = 35
    bloodGroup = "A_POSITIVE"
    heightCm = 175.0
    weightKg = 75.0
    gender = "MALE"
    contactNumber = "+1234567890"
    emergencyContact = "+1234567891"
    medicalHistory = "Hypertension, Diabetes"
    allergies = "Penicillin"
    currentMedications = "Metformin, Lisinopril"
    lifestyleFactors = "Regular exercise, healthy diet, no smoking"
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "http://localhost:8080/api/medical/user/profile" -Method POST -Body $profileData -ContentType "application/json"
    Write-Host "✓ User profile created successfully" -ForegroundColor Green
    $profile = $response.Content | ConvertFrom-Json
    Write-Host "   Profile ID: $($profile.id)" -ForegroundColor Gray
} catch {
    Write-Host "✗ Failed to create user profile: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 2: Get All User Profiles
Write-Host "`n2. Testing Get All User Profiles..." -ForegroundColor Cyan
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8080/api/medical/user/profiles" -Method GET
    Write-Host "✓ Retrieved user profiles successfully" -ForegroundColor Green
    $profiles = $response.Content | ConvertFrom-Json
    Write-Host "   Total profiles: $($profiles.Count)" -ForegroundColor Gray
} catch {
    Write-Host "✗ Failed to get user profiles: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Enhanced Disease Prediction
Write-Host "`n3. Testing Enhanced Disease Prediction..." -ForegroundColor Cyan
$predictionData = @{
    symptoms = "Chest pain,Shortness of breath"
    name = "John Doe"
    age = 35
    bloodGroup = "A_POSITIVE"
    heightCm = 175.0
    weightKg = 75.0
    gender = "MALE"
    contactNumber = "+1234567890"
    emergencyContact = "+1234567891"
    medicalHistory = "Hypertension, Diabetes"
    allergies = "Penicillin"
    currentMedications = "Metformin, Lisinopril"
    lifestyleFactors = "Regular exercise, healthy diet, no smoking"
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "http://localhost:8080/api/medical/predict/enhanced" -Method POST -Body $predictionData -ContentType "application/json"
    Write-Host "✓ Enhanced prediction successful" -ForegroundColor Green
    $result = $response.Content | ConvertFrom-Json
    Write-Host "   Predictions generated: $($result.predictions.Count)" -ForegroundColor Gray
    Write-Host "   Lifestyle score: $($result.lifestyleScore)" -ForegroundColor Gray
    Write-Host "   BMI: $($result.bmi)" -ForegroundColor Gray
    Write-Host "   Age group: $($result.ageGroup)" -ForegroundColor Gray
} catch {
    Write-Host "✗ Failed to get enhanced prediction: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 4: User Analytics
Write-Host "`n4. Testing User Analytics..." -ForegroundColor Cyan
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8080/api/medical/analytics/users" -Method GET
    Write-Host "✓ Retrieved user analytics successfully" -ForegroundColor Green
    $analytics = $response.Content | ConvertFrom-Json
    Write-Host "   Blood group distribution: $($analytics.bloodGroupDistribution.Count) groups" -ForegroundColor Gray
    Write-Host "   Average age: $($analytics.averageAge)" -ForegroundColor Gray
    Write-Host "   Average BMI: $($analytics.averageBmi)" -ForegroundColor Gray
} catch {
    Write-Host "✗ Failed to get user analytics: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 5: Create Another Profile for Analytics
Write-Host "`n5. Creating Additional Profile for Analytics..." -ForegroundColor Cyan
$profileData2 = @{
    name = "Jane Smith"
    age = 28
    bloodGroup = "O_NEGATIVE"
    heightCm = 165.0
    weightKg = 60.0
    gender = "FEMALE"
    contactNumber = "+1234567892"
    emergencyContact = "+1234567893"
    medicalHistory = "Asthma"
    allergies = "Dust, Pollen"
    currentMedications = "Albuterol inhaler"
    lifestyleFactors = "Regular exercise, vegetarian diet, good sleep"
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "http://localhost:8080/api/medical/user/profile" -Method POST -Body $profileData2 -ContentType "application/json"
    Write-Host "✓ Second user profile created successfully" -ForegroundColor Green
} catch {
    Write-Host "✗ Failed to create second profile: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 6: Enhanced Prediction for Second User
Write-Host "`n6. Testing Enhanced Prediction for Second User..." -ForegroundColor Cyan
$predictionData2 = @{
    symptoms = "Headache,Fatigue"
    name = "Jane Smith"
    age = 28
    bloodGroup = "O_NEGATIVE"
    heightCm = 165.0
    weightKg = 60.0
    gender = "FEMALE"
    contactNumber = "+1234567892"
    emergencyContact = "+1234567893"
    medicalHistory = "Asthma"
    allergies = "Dust, Pollen"
    currentMedications = "Albuterol inhaler"
    lifestyleFactors = "Regular exercise, vegetarian diet, good sleep"
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "http://localhost:8080/api/medical/predict/enhanced" -Method POST -Body $predictionData2 -ContentType "application/json"
    Write-Host "✓ Enhanced prediction for second user successful" -ForegroundColor Green
    $result = $response.Content | ConvertFrom-Json
    Write-Host "   Lifestyle score: $($result.lifestyleScore)" -ForegroundColor Gray
    Write-Host "   BMI: $($result.bmi)" -ForegroundColor Gray
} catch {
    Write-Host "✗ Failed to get enhanced prediction for second user: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n==================================================" -ForegroundColor Green
Write-Host "Enhanced Features Testing Complete!" -ForegroundColor Green
Write-Host "Check the results above for any errors." -ForegroundColor Yellow
Write-Host "`nYou can now test the web interface at: http://localhost:8080" -ForegroundColor Cyan
