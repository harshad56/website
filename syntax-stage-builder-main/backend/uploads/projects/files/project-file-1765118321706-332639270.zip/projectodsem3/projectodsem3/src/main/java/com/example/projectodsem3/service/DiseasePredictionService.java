package com.example.projectodsem3.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.projectodsem3.model.Disease;
import com.example.projectodsem3.model.SymptomDiseaseCorrelation;
import com.example.projectodsem3.service.DataCache;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DiseasePredictionService {
    
    @Autowired
    private DataCache dataCache;
    
    /**
     * Predict diseases based on input symptoms (simplified version for controller)
     */
    public List<DiseasePredictionResult> predictDiseases(List<String> symptoms, Integer age, String gender) {
        // This method will be called from the controller and will use cached data
        // Get data from cache and call the full method
        List<Disease> diseases = dataCache.getDiseases();
        List<SymptomDiseaseCorrelation> correlations = dataCache.getCorrelations();
        
        if (diseases == null || correlations == null || diseases.isEmpty() || correlations.isEmpty()) {
            return new ArrayList<>();
        }
        
        return predictDiseases(symptoms, diseases, correlations, age, gender);
    }

    /**
     * Predict diseases based on input symptoms (full version with all parameters)
     */
    public List<DiseasePredictionResult> predictDiseases(List<String> symptoms, 
                                                        List<Disease> diseases,
                                                        List<SymptomDiseaseCorrelation> correlations,
                                                        Integer age,
                                                        String gender) {
        
        List<DiseasePredictionResult> results = new ArrayList<>();
        Map<String, Disease> diseaseMap = diseases.stream()
                .collect(Collectors.toMap(d -> d.getName().toLowerCase(), d -> d));
        
        // Calculate disease scores for each disease
        for (Disease disease : diseases) {
            double score = calculateDiseaseScore(symptoms, disease, correlations, age, gender);
            if (score > 0) {
                DiseasePredictionResult result = new DiseasePredictionResult();
                result.setDisease(disease);
                result.setConfidenceScore(score);
                result.setMatchedSymptoms(findMatchedSymptoms(symptoms, disease, correlations));
                result.setRiskLevel(calculateRiskLevel(score, disease, age, gender));
                result.setRecommendations(generateRecommendations(disease, score, age, gender));
                
                results.add(result);
            }
        }
        
        // Sort by confidence score (highest first)
        results.sort((a, b) -> Double.compare(b.getConfidenceScore(), a.getConfidenceScore()));
        
        // Limit to top 10 results
        return results.stream().limit(10).collect(Collectors.toList());
    }
    
    /**
     * Calculate disease score using weighted symptom matching
     */
    private double calculateDiseaseScore(List<String> inputSymptoms, 
                                       Disease disease, 
                                       List<SymptomDiseaseCorrelation> correlations,
                                       Integer age, 
                                       String gender) {
        
        double totalScore = 0.0;
        double maxPossibleScore = 0.0;
        
        // Get correlations for this disease
        List<SymptomDiseaseCorrelation> diseaseCorrelations = correlations.stream()
                .filter(c -> c.getDisease() != null && disease != null && 
                           c.getDisease().getName() != null && disease.getName() != null &&
                           c.getDisease().getName().equals(disease.getName()))
                .collect(Collectors.toList());
        
        // Calculate base symptom matching score
        for (SymptomDiseaseCorrelation correlation : diseaseCorrelations) {
            String symptomName = correlation.getSymptom().getName().toLowerCase();
            double weight = correlation.getCorrelationWeight() != null ? correlation.getCorrelationWeight() : 1.0;
            double confidence = correlation.getConfidence() != null ? correlation.getConfidence() : 1.0;
            
            maxPossibleScore += weight * confidence;
            
            if (inputSymptoms.stream().anyMatch(s -> s.toLowerCase().contains(symptomName) || 
                                                   symptomName.contains(s.toLowerCase()))) {
                totalScore += weight * confidence;
                
                // Bonus for primary symptoms
                if (correlation.getIsPrimarySymptom() != null && correlation.getIsPrimarySymptom()) {
                    totalScore += weight * 0.5;
                }
            }
        }
        
        // Apply age factor
        if (age != null && disease.getAgeGroupMin() != null && disease.getAgeGroupMax() != null) {
            if (age >= disease.getAgeGroupMin() && age <= disease.getAgeGroupMax()) {
                totalScore *= 1.2; // 20% bonus for age match
            } else {
                totalScore *= 0.8; // 20% penalty for age mismatch
            }
        }
        
        // Apply gender factor
        if (gender != null && disease.getGenderPreference() != null) {
            if (gender.equalsIgnoreCase(disease.getGenderPreference())) {
                totalScore *= 1.1; // 10% bonus for gender match
            }
        }
        
        // Normalize score to 0-100 range
        if (maxPossibleScore > 0) {
            totalScore = (totalScore / maxPossibleScore) * 100;
        }
        
        return Math.min(100.0, Math.max(0.0, totalScore));
    }
    
    /**
     * Find symptoms that match between input and disease
     */
    private List<String> findMatchedSymptoms(List<String> inputSymptoms, 
                                           Disease disease, 
                                           List<SymptomDiseaseCorrelation> correlations) {
        
        Set<String> matchedSymptoms = new HashSet<>();
        
        List<SymptomDiseaseCorrelation> diseaseCorrelations = correlations.stream()
                .filter(c -> c.getDisease() != null && disease != null && 
                           c.getDisease().getName() != null && disease.getName() != null &&
                           c.getDisease().getName().equals(disease.getName()))
                .collect(Collectors.toList());
        
        for (SymptomDiseaseCorrelation correlation : diseaseCorrelations) {
            String symptomName = correlation.getSymptom().getName();
            
            if (inputSymptoms.stream().anyMatch(s -> s.toLowerCase().contains(symptomName.toLowerCase()) || 
                                                   symptomName.toLowerCase().contains(s.toLowerCase()))) {
                matchedSymptoms.add(symptomName);
            }
        }
        
        return new ArrayList<>(matchedSymptoms);
    }
    
    /**
     * Calculate risk level based on score and disease characteristics
     */
    private String calculateRiskLevel(double score, Disease disease, Integer age, String gender) {
        if (score >= 80) return "HIGH";
        if (score >= 60) return "MEDIUM";
        if (score >= 40) return "LOW";
        return "VERY_LOW";
    }
    
    /**
     * Generate personalized recommendations
     */
    private List<String> generateRecommendations(Disease disease, double score, Integer age, String gender) {
        List<String> recommendations = new ArrayList<>();
        
        if (score >= 70) {
            recommendations.add("High probability match - Consider consulting a healthcare professional");
        } else if (score >= 50) {
            recommendations.add("Moderate probability - Monitor symptoms and consider medical advice");
        } else {
            recommendations.add("Low probability - Continue monitoring for any changes");
        }
        
        // Check if disease is severe (which might indicate emergency)
        if (disease.getSeverity() != null && "severe".equalsIgnoreCase(disease.getSeverity())) {
            recommendations.add("⚠️ SEVERE CONDITION: Consider seeking immediate medical attention");
        }
        
        if (disease.getPrevention() != null && !disease.getPrevention().isEmpty()) {
            recommendations.add("Prevention: " + disease.getPrevention());
        }
        
        if (disease.getTreatment() != null && !disease.getTreatment().isEmpty()) {
            recommendations.add("Treatment: " + disease.getTreatment());
        }
        
        return recommendations;
    }
    
    /**
     * Perform statistical analysis on disease patterns
     */
    public Map<String, Object> analyzeDiseasePatterns(List<Disease> diseases, 
                                                     List<SymptomDiseaseCorrelation> correlations) {
        
        Map<String, Object> analysis = new HashMap<>();
        
        // Disease distribution by category
        Map<String, Long> categoryDistribution = diseases.stream()
                .filter(d -> d.getCategory() != null)
                .collect(Collectors.groupingBy(Disease::getCategory, Collectors.counting()));
        analysis.put("categoryDistribution", categoryDistribution);
        
        // Severity distribution
        Map<String, Long> severityDistribution = diseases.stream()
                .filter(d -> d.getSeverity() != null)
                .collect(Collectors.groupingBy(Disease::getSeverity, Collectors.counting()));
        analysis.put("severityDistribution", severityDistribution);
        
        // Chronic vs Acute diseases
        long chronicCount = diseases.stream()
                .filter(d -> d.getIsChronic() != null && d.getIsChronic())
                .count();
        long acuteCount = diseases.size() - chronicCount;
        analysis.put("chronicDiseases", chronicCount);
        analysis.put("acuteDiseases", acuteCount);
        
        // Contagious diseases count
        long contagiousCount = diseases.stream()
                .filter(d -> d.getIsContagious() != null && d.getIsContagious())
                .count();
        analysis.put("contagiousDiseases", contagiousCount);
        
        // Average risk score
        double avgRiskScore = diseases.stream()
                .filter(d -> d.getRiskScore() != null)
                .mapToDouble(Disease::getRiskScore)
                .average()
                .orElse(0.0);
        analysis.put("averageRiskScore", avgRiskScore);
        
        return analysis;
    }
    
    /**
     * Result class for disease predictions
     */
    public static class DiseasePredictionResult {
        private Disease disease;
        private double confidenceScore;
        private List<String> matchedSymptoms;
        private String riskLevel;
        private List<String> recommendations;
        
        // Getters and setters
        public Disease getDisease() { return disease; }
        public void setDisease(Disease disease) { this.disease = disease; }
        
        public double getConfidenceScore() { return confidenceScore; }
        public void setConfidenceScore(double confidenceScore) { this.confidenceScore = confidenceScore; }
        
        public List<String> getMatchedSymptoms() { return matchedSymptoms; }
        public void setMatchedSymptoms(List<String> matchedSymptoms) { this.matchedSymptoms = matchedSymptoms; }
        
        public String getRiskLevel() { return riskLevel; }
        public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }
        
        public List<String> getRecommendations() { return recommendations; }
        public void setRecommendations(List<String> recommendations) { this.recommendations = recommendations; }
    }
}
