package com.example.projectodsem3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projectodsem3Application {

	public static void main(String[] args) {
		SpringApplication.run(Projectodsem3Application.class, args);
	}

}
