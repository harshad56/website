#!/bin/bash

# Test Script for Expanded Disease-Symptom Dataset
# This script demonstrates how to use the new expanded CSV processing capabilities

echo "🏥 Medical Symptom Analyzer - Expanded Dataset Test"
echo "=================================================="
echo ""

# Check if the application is running
echo "🔍 Checking if the application is running..."
if ! curl -s http://localhost:8080/api/medical/symptoms > /dev/null; then
    echo "❌ Application is not running. Please start it first with: mvn spring-boot:run"
    exit 1
fi
echo "✅ Application is running on http://localhost:8080"
echo ""

# Upload the expanded dataset
echo "📤 Uploading expanded disease-symptom dataset..."
echo "File: expanded_disease_symptom_data.csv"
echo "Expected: ~10,000 lines of medical data"
echo ""

UPLOAD_RESPONSE=$(curl -s -X POST -F "file=@expanded_disease_symptom_data.csv" http://localhost:8080/api/medical/upload/expanded)

if echo "$UPLOAD_RESPONSE" | grep -q "error"; then
    echo "❌ Failed to upload expanded dataset:"
    echo "$UPLOAD_RESPONSE"
    exit 1
fi

echo "✅ Expanded dataset uploaded successfully!"
echo "Response: $UPLOAD_RESPONSE"
echo ""

# Get expanded dataset analytics
echo "📊 Getting expanded dataset analytics..."
ANALYTICS_RESPONSE=$(curl -s http://localhost:8080/api/medical/analytics/expanded)

if echo "$ANALYTICS_RESPONSE" | grep -q "error"; then
    echo "❌ Failed to get analytics:"
    echo "$ANALYTICS_RESPONSE"
    exit 1
fi

echo "✅ Analytics retrieved successfully!"
echo "Response: $ANALYTICS_RESPONSE"
echo ""

# Test disease prediction with symptoms from the expanded dataset
echo "🔮 Testing disease prediction with expanded dataset..."
echo "Testing symptoms: Severe headache, Chest pain, Difficulty breathing"
echo ""

PREDICTION_RESPONSE=$(curl -s -X POST http://localhost:8080/api/medical/predict \
  -H "Content-Type: application/json" \
  -d '{
    "symptoms": ["Severe headache", "Chest pain", "Difficulty breathing"],
    "age": 45,
    "gender": "Male"
  }')

if echo "$PREDICTION_RESPONSE" | grep -q "error"; then
    echo "❌ Failed to get prediction:"
    echo "$PREDICTION_RESPONSE"
    exit 1
fi

echo "✅ Disease prediction successful!"
echo "Response: $PREDICTION_RESPONSE"
echo ""

# Get available symptoms count
echo "📋 Getting available symptoms count..."
SYMPTOMS_RESPONSE=$(curl -s http://localhost:8080/api/medical/symptoms)
SYMPTOMS_COUNT=$(echo "$SYMPTOMS_RESPONSE" | jq '. | length' 2>/dev/null || echo "Unknown")

echo "✅ Available symptoms: $SYMPTOMS_COUNT"
echo ""

# Get available diseases count
echo "🏥 Getting available diseases count..."
DISEASES_RESPONSE=$(curl -s http://localhost:8080/api/medical/diseases)
DISEASES_COUNT=$(echo "$DISEASES_RESPONSE" | jq '. | length' 2>/dev/null || echo "Unknown")

echo "✅ Available diseases: $DISEASES_COUNT"
echo ""

# Summary
echo "🎯 Test Summary"
echo "==============="
echo "✅ Expanded dataset uploaded successfully"
echo "✅ Analytics generated from expanded data"
echo "✅ Disease prediction working with expanded dataset"
echo "✅ Symptoms count: $SYMPTOMS_COUNT"
echo "✅ Diseases count: $DISEASES_COUNT"
echo ""
echo "🚀 Your expanded medical dataset is now fully integrated!"
echo "   You can now use the system with much more comprehensive medical data."
echo ""
echo "💡 Next steps:"
echo "   - Test with different symptom combinations"
echo "   - Explore the analytics endpoint for insights"
echo "   - Build a frontend to visualize the data"
echo ""
echo "🌐 API Endpoints available:"
echo "   - POST /api/medical/upload/expanded - Upload expanded dataset"
echo "   - GET /api/medical/analytics/expanded - Get expanded analytics"
echo "   - POST /api/medical/predict - Predict diseases from symptoms"
echo "   - GET /api/medical/symptoms - Get all symptoms"
echo "   - GET /api/medical/diseases - Get all diseases"
echo ""
echo "🏁 Test completed successfully!"
