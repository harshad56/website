package com.example.projectodsem3.service;

import com.example.projectodsem3.model.Disease;
import com.example.projectodsem3.model.Symptom;
import com.example.projectodsem3.model.SymptomDiseaseCorrelation;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.*;

@Service
@Slf4j
public class CsvProcessingService {
    
    /**
     * Process diseases CSV file
     */
    public List<Disease> processDiseasesCsv(MultipartFile file) throws IOException, CsvValidationException {
        List<Disease> diseases = new ArrayList<>();
        
        try (Reader reader = new InputStreamReader(file.getInputStream());
             CSVReader csvReader = new CSVReader(reader)) {
            
            String[] headers = csvReader.readNext(); // Skip header row
            if (headers == null) {
                throw new IOException("CSV file is empty or invalid");
            }
            
            String[] line;
            while ((line = csvReader.readNext()) != null) {
                try {
                    Disease disease = parseDiseaseLine(line, headers);
                    if (disease != null) {
                        diseases.add(disease);
                    }
                } catch (Exception e) {
                    log.error("Error parsing disease line: {}", Arrays.toString(line), e);
                }
            }
        }
        
        log.info("Processed {} diseases from CSV", diseases.size());
        return diseases;
    }
    
    /**
     * Process symptoms CSV file
     */
    public List<Symptom> processSymptomsCsv(MultipartFile file) throws IOException, CsvValidationException {
        List<Symptom> symptoms = new ArrayList<>();
        
        try (Reader reader = new InputStreamReader(file.getInputStream());
             CSVReader csvReader = new CSVReader(reader)) {
            
            String[] headers = csvReader.readNext(); // Skip header row
            if (headers == null) {
                throw new IOException("CSV file is empty or invalid");
            }
            
            String[] line;
            while ((line = csvReader.readNext()) != null) {
                try {
                    Symptom symptom = parseSymptomLine(line, headers);
                    if (symptom != null) {
                        symptoms.add(symptom);
                    }
                } catch (Exception e) {
                    log.error("Error parsing symptom line: {}", Arrays.toString(line), e);
                }
            }
        }
        
        log.info("Processed {} symptoms from CSV", symptoms.size());
        return symptoms;
    }
    
    /**
     * Process symptom-disease correlations CSV file
     */
    public List<SymptomDiseaseCorrelation> processCorrelationsCsv(MultipartFile file, 
                                                                 Map<String, Symptom> symptomMap,
                                                                 Map<String, Disease> diseaseMap) 
            throws IOException, CsvValidationException {
        List<SymptomDiseaseCorrelation> correlations = new ArrayList<>();
        
        try (Reader reader = new InputStreamReader(file.getInputStream());
             CSVReader csvReader = new CSVReader(reader)) {
            
            String[] headers = csvReader.readNext(); // Skip header row
            if (headers == null) {
                throw new IOException("CSV file is empty or invalid");
            }
            
            String[] line;
            while ((line = csvReader.readNext()) != null) {
                try {
                    SymptomDiseaseCorrelation correlation = parseCorrelationLine(line, headers, symptomMap, diseaseMap);
                    if (correlation != null) {
                        correlations.add(correlation);
                    }
                } catch (Exception e) {
                    log.error("Error parsing correlation line: {}", Arrays.toString(line), e);
                }
            }
        }
        
        log.info("Processed {} correlations from CSV", correlations.size());
        return correlations;
    }
    
    private Disease parseDiseaseLine(String[] line, String[] headers) {
        try {
            Disease disease = new Disease();
            
            for (int i = 0; i < Math.min(headers.length, line.length); i++) {
                String header = headers[i].trim().toLowerCase();
                String value = line[i] != null ? line[i].trim() : "";
                
                switch (header) {
                    case "name":
                        disease.setName(value);
                        break;
                    case "description":
                        disease.setDescription(value);
                        break;
                    case "symptoms":
                        disease.setSymptoms(value);
                        break;
                    case "treatment":
                        disease.setTreatment(value);
                        break;
                    case "prevention":
                        disease.setPrevention(value);
                        break;
                    case "severity":
                        disease.setSeverity(value);
                        break;
                    case "category":
                        disease.setCategory(value);
                        break;
                    case "riskscore":
                        disease.setRiskScore(parseDouble(value));
                        break;
                    case "agegroupmin":
                        disease.setAgeGroupMin(parseInteger(value));
                        break;
                    case "agegroupmax":
                        disease.setAgeGroupMax(parseInteger(value));
                        break;
                    case "genderpreference":
                        disease.setGenderPreference(value);
                        break;
                    case "ischronic":
                        disease.setIsChronic(parseBoolean(value));
                        break;
                    case "iscontagious":
                        disease.setIsContagious(parseBoolean(value));
                        break;
                }
            }
            
            // Parse symptom list from symptoms string
            if (disease.getSymptoms() != null && !disease.getSymptoms().isEmpty()) {
                Set<String> symptomSet = new HashSet<>();
                String[] symptomArray = disease.getSymptoms().split(",");
                for (String symptom : symptomArray) {
                    symptomSet.add(symptom.trim());
                }
                disease.setSymptomList(symptomSet);
            }
            
            return disease.getName() != null ? disease : null;
            
        } catch (Exception e) {
            log.error("Error parsing disease line: {}", Arrays.toString(line), e);
            return null;
        }
    }
    
    private Symptom parseSymptomLine(String[] line, String[] headers) {
        try {
            Symptom symptom = new Symptom();
            
            for (int i = 0; i < Math.min(headers.length, line.length); i++) {
                String header = headers[i].trim().toLowerCase();
                String value = line[i] != null ? line[i].trim() : "";
                
                switch (header) {
                    case "name":
                        symptom.setName(value);
                        break;
                    case "description":
                        symptom.setDescription(value);
                        break;
                    case "category":
                        symptom.setCategory(value);
                        break;
                    case "severity":
                        symptom.setSeverity(parseDouble(value));
                        break;
                    case "iscommon":
                        symptom.setIsCommon(parseBoolean(value));
                        break;
                    case "bodypart":
                        symptom.setBodyPart(value);
                        break;
                    case "frequency":
                        symptom.setFrequency(value);
                        break;
                    case "duration":
                        symptom.setDuration(value);
                        break;
                    case "isemergency":
                        symptom.setIsEmergency(parseBoolean(value));
                        break;
                    case "relatedsymptoms":
                        symptom.setRelatedSymptoms(value);
                        break;
                }
            }
            
            return symptom.getName() != null ? symptom : null;
            
        } catch (Exception e) {
            log.error("Error parsing symptom line: {}", Arrays.toString(line), e);
            return null;
        }
    }
    
    private SymptomDiseaseCorrelation parseCorrelationLine(String[] line, String[] headers,
                                                          Map<String, Symptom> symptomMap,
                                                          Map<String, Disease> diseaseMap) {
        try {
            SymptomDiseaseCorrelation correlation = new SymptomDiseaseCorrelation();
            
            String symptomName = null;
            String diseaseName = null;
            
            for (int i = 0; i < Math.min(headers.length, line.length); i++) {
                String header = headers[i].trim().toLowerCase();
                String value = line[i] != null ? line[i].trim() : "";
                
                switch (header) {
                    case "symptom":
                    case "symptomname":
                        symptomName = value;
                        break;
                    case "disease":
                    case "diseasename":
                        diseaseName = value;
                        break;
                    case "correlationweight":
                    case "weight":
                        correlation.setCorrelationWeight(parseDouble(value));
                        break;
                    case "confidence":
                        correlation.setConfidence(parseDouble(value));
                        break;
                    case "notes":
                        correlation.setNotes(value);
                        break;
                    case "isprimarysymptom":
                    case "primary":
                        correlation.setIsPrimarySymptom(parseBoolean(value));
                        break;
                    case "issecondarysymptom":
                    case "secondary":
                        correlation.setIsSecondarySymptom(parseBoolean(value));
                        break;
                    case "symptomorder":
                    case "order":
                        correlation.setSymptomOrder(parseInteger(value));
                        break;
                }
            }
            
            // Set the actual entities
            if (symptomName != null && diseaseName != null) {
                Symptom symptom = symptomMap.get(symptomName.toLowerCase());
                Disease disease = diseaseMap.get(diseaseName.toLowerCase());
                
                if (symptom != null && disease != null) {
                    correlation.setSymptom(symptom);
                    correlation.setDisease(disease);
                    return correlation;
                }
            }
            
            return null;
            
        } catch (Exception e) {
            log.error("Error parsing correlation line: {}", Arrays.toString(line), e);
            return null;
        }
    }
    
    private Double parseDouble(String value) {
        try {
            return value.isEmpty() ? null : Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }
    
    private Integer parseInteger(String value) {
        try {
            return value.isEmpty() ? null : Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }
    
    private Boolean parseBoolean(String value) {
        if (value.isEmpty()) return null;
        String lowerValue = value.toLowerCase();
        return lowerValue.equals("true") || lowerValue.equals("1") || lowerValue.equals("yes");
    }
}
