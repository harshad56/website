package com.example.projectodsem3.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.projectodsem3.model.UserProfile;
import com.example.projectodsem3.service.DiseasePredictionService;
import com.example.projectodsem3.service.DataCache;

@Service
public class EnhancedPredictionService {
    
    @Autowired
    private DiseasePredictionService diseasePredictionService;
    
    @Autowired
    private DataCache dataCache;
    
    // Blood group disease risk factors
    private static final Map<String, List<String>> BLOOD_GROUP_RISKS = Map.of(
        "A+", Arrays.asList("Heart disease", "Stomach cancer", "Diabetes"),
        "A-", Arrays.asList("Heart disease", "Stomach cancer", "Diabetes"),
        "B+", Arrays.asList("Pancreatic cancer", "Ovarian cancer", "Diabetes"),
        "B-", Arrays.asList("Pancreatic cancer", "Ovarian cancer", "Diabetes"),
        "AB+", Arrays.asList("Heart disease", "Stomach cancer", "Memory problems"),
        "AB-", Arrays.asList("Heart disease", "Stomach cancer", "Memory problems"),
        "O+", Arrays.asList("Stomach ulcers", "Heart disease", "Blood clots"),
        "O-", Arrays.asList("Stomach ulcers", "Heart disease", "Blood clots")
    );
    
    // BMI risk factors
    private static final Map<String, List<String>> BMI_RISKS = Map.of(
        "Underweight", Arrays.asList("Anemia", "Osteoporosis", "Weakened immune system"),
        "Normal weight", Arrays.asList("Generally low risk"),
        "Overweight", Arrays.asList("Heart disease", "Diabetes", "High blood pressure"),
        "Obese", Arrays.asList("Heart disease", "Diabetes", "High blood pressure", "Sleep apnea", "Joint problems")
    );
    
    // Age group risk factors
    private static final Map<String, List<String>> AGE_RISKS = Map.of(
        "Child/Teen", Arrays.asList("Infections", "Allergies", "Asthma"),
        "Young Adult", Arrays.asList("STIs", "Mental health issues", "Substance abuse"),
        "Adult", Arrays.asList("Heart disease", "Diabetes", "Cancer", "Stress-related conditions"),
        "Middle-aged", Arrays.asList("Heart disease", "Diabetes", "Cancer", "Arthritis", "Vision problems"),
        "Senior", Arrays.asList("Heart disease", "Diabetes", "Cancer", "Arthritis", "Dementia", "Falls")
    );
    
    public EnhancedPredictionResult predictDiseasesWithUserProfile(
            List<String> symptoms, 
            UserProfile userProfile) {
        
        // Get base predictions
        List<DiseasePredictionService.DiseasePredictionResult> baseResults = diseasePredictionService.predictDiseases(symptoms, userProfile.getAge(), userProfile.getGender().getDisplayValue());
        
        // Enhance with user profile factors
        List<EnhancedPredictionItem> enhancedPredictions = baseResults.stream()
                .map(prediction -> enhancePrediction(prediction, userProfile))
                .sorted((a, b) -> Double.compare(b.getEnhancedConfidence(), a.getEnhancedConfidence()))
                .collect(Collectors.toList());
        
        // Calculate personalized risk factors
        List<String> riskFactors = calculatePersonalizedRiskFactors(userProfile);
        
        // Calculate lifestyle score
        Integer lifestyleScore = calculateLifestyleScore(userProfile);
        
        // Generate health insights
        List<HealthInsight> healthInsights = generateHealthInsights(userProfile);
        
        return EnhancedPredictionResult.builder()
                .predictions(enhancedPredictions)
                .userProfile(userProfile)
                .riskFactors(riskFactors)
                .lifestyleScore(lifestyleScore)
                .healthInsights(healthInsights)
                .bmi(userProfile.getBmi())
                .bmiCategory(userProfile.getBmiCategory())
                .ageGroup(userProfile.getAgeGroup())
                .bloodGroupCompatibility(getBloodGroupCompatibility(userProfile.getBloodGroup()))
                .build();
    }
    
    private EnhancedPredictionItem enhancePrediction(DiseasePredictionService.DiseasePredictionResult basePrediction, UserProfile userProfile) {
        double enhancedConfidence = basePrediction.getConfidenceScore();
        
        // Blood group factor
        double bloodGroupFactor = getBloodGroupFactor(basePrediction.getDisease().getName(), userProfile.getBloodGroup());
        enhancedConfidence *= bloodGroupFactor;
        
        // BMI factor
        double bmiFactor = getBmiFactor(basePrediction.getDisease().getName(), userProfile.getBmiCategory());
        enhancedConfidence *= bmiFactor;
        
        // Age factor
        double ageFactor = getAgeFactor(basePrediction.getDisease().getName(), userProfile.getAgeGroup());
        enhancedConfidence *= ageFactor;
        
        // Ensure confidence stays within bounds
        enhancedConfidence = Math.min(100.0, Math.max(0.0, enhancedConfidence));
        
        return EnhancedPredictionItem.builder()
                .diseaseName(basePrediction.getDisease().getName())
                .baseConfidence(basePrediction.getConfidenceScore())
                .enhancedConfidence(enhancedConfidence)
                .riskLevel(basePrediction.getRiskLevel())
                .recommendations(enhanceRecommendations(String.join(", ", basePrediction.getRecommendations()), userProfile))
                .matchedSymptoms(String.join(", ", basePrediction.getMatchedSymptoms()))
                .bloodGroupRisk(bloodGroupFactor)
                .bmiRisk(bmiFactor)
                .ageRisk(ageFactor)
                .build();
    }
    
    private double getBloodGroupFactor(String diseaseName, UserProfile.BloodGroup bloodGroup) {
        if (bloodGroup == null) return 1.0;
        
        String bloodGroupStr = bloodGroup.getDisplayValue();
        List<String> highRiskDiseases = BLOOD_GROUP_RISKS.get(bloodGroupStr);
        
        if (highRiskDiseases != null && highRiskDiseases.stream()
                .anyMatch(disease -> diseaseName.toLowerCase().contains(disease.toLowerCase()))) {
            return 1.3; // 30% higher risk
        }
        return 1.0;
    }
    
    private double getBmiFactor(String diseaseName, String bmiCategory) {
        if (bmiCategory == null) return 1.0;
        
        List<String> highRiskDiseases = BMI_RISKS.get(bmiCategory);
        
        if (highRiskDiseases != null && highRiskDiseases.stream()
                .anyMatch(disease -> diseaseName.toLowerCase().contains(disease.toLowerCase()))) {
            return 1.25; // 25% higher risk
        }
        return 1.0;
    }
    
    private double getAgeFactor(String diseaseName, String ageGroup) {
        if (ageGroup == null) return 1.0;
        
        List<String> highRiskDiseases = AGE_RISKS.get(ageGroup);
        
        if (highRiskDiseases != null && highRiskDiseases.stream()
                .anyMatch(disease -> diseaseName.toLowerCase().contains(disease.toLowerCase()))) {
            return 1.2; // 20% higher risk
        }
        return 1.0;
    }
    
    private List<String> calculatePersonalizedRiskFactors(UserProfile userProfile) {
        List<String> riskFactors = new ArrayList<>();
        
        // Blood group risks
        if (userProfile.getBloodGroup() != null) {
            String bloodGroupStr = userProfile.getBloodGroup().getDisplayValue();
            List<String> bloodRisks = BLOOD_GROUP_RISKS.get(bloodGroupStr);
            if (bloodRisks != null) {
                riskFactors.addAll(bloodRisks.stream()
                        .map(risk -> "Blood group " + bloodGroupStr + " risk: " + risk)
                        .collect(Collectors.toList()));
            }
        }
        
        // BMI risks
        if (userProfile.getBmiCategory() != null) {
            List<String> bmiRisks = BMI_RISKS.get(userProfile.getBmiCategory());
            if (bmiRisks != null) {
                riskFactors.addAll(bmiRisks.stream()
                        .map(risk -> "BMI " + userProfile.getBmiCategory() + " risk: " + risk)
                        .collect(Collectors.toList()));
            }
        }
        
        // Age risks
        if (userProfile.getAgeGroup() != null) {
            List<String> ageRisks = AGE_RISKS.get(userProfile.getAgeGroup());
            if (ageRisks != null) {
                riskFactors.addAll(ageRisks.stream()
                        .map(risk -> "Age group " + userProfile.getAgeGroup() + " risk: " + risk)
                        .collect(Collectors.toList()));
            }
        }
        
        return riskFactors;
    }
    
    private Integer calculateLifestyleScore(UserProfile userProfile) {
        int score = 100; // Start with perfect score
        
        if (userProfile.getLifestyleFactors() != null) {
            String factors = userProfile.getLifestyleFactors().toLowerCase();
            
            if (factors.contains("smoking")) score -= 20;
            if (factors.contains("alcohol")) score -= 15;
            if (factors.contains("sedentary") || factors.contains("no exercise")) score -= 25;
            if (factors.contains("poor diet") || factors.contains("junk food")) score -= 20;
            if (factors.contains("stress")) score -= 10;
            
            if (factors.contains("regular exercise")) score += 15;
            if (factors.contains("healthy diet")) score += 20;
            if (factors.contains("good sleep")) score += 10;
        }
        
        return Math.max(0, Math.min(100, score));
    }
    
    private List<HealthInsight> generateHealthInsights(UserProfile userProfile) {
        List<HealthInsight> insights = new ArrayList<>();
        
        // BMI insights
        if (userProfile.getBmi() != null) {
            if (userProfile.getBmi() < 18.5) {
                insights.add(new HealthInsight("BMI", "Underweight", 
                    "Consider consulting a nutritionist to develop a healthy weight gain plan."));
            } else if (userProfile.getBmi() > 30) {
                insights.add(new HealthInsight("BMI", "Obese", 
                    "Focus on gradual weight loss through diet and exercise. Consult a healthcare provider."));
            }
        }
        
        // Age insights
        if (userProfile.getAge() != null) {
            if (userProfile.getAge() >= 50) {
                insights.add(new HealthInsight("Age", "50+", 
                    "Consider regular health screenings for cancer, heart disease, and diabetes."));
            }
        }
        
        // Blood group insights
        if (userProfile.getBloodGroup() != null) {
            String bloodGroupStr = userProfile.getBloodGroup().getDisplayValue();
            if (bloodGroupStr.equals("O-")) {
                insights.add(new HealthInsight("Blood Group", "O-", 
                    "Universal donor! Your blood type is in high demand for emergencies."));
            }
        }
        
        return insights;
    }
    
    private String getBloodGroupCompatibility(UserProfile.BloodGroup bloodGroup) {
        if (bloodGroup == null) return "Unknown";
        
        switch (bloodGroup) {
            case A_POSITIVE:
                return "Can receive: A+, A-, O+, O- | Can donate to: A+, AB+";
            case A_NEGATIVE:
                return "Can receive: A-, O- | Can donate to: A+, A-, AB+, AB-";
            case B_POSITIVE:
                return "Can receive: B+, B-, O+, O- | Can donate to: B+, AB+";
            case B_NEGATIVE:
                return "Can receive: B-, O- | Can donate to: B+, B-, AB+, AB-";
            case AB_POSITIVE:
                return "Can receive: All blood types | Can donate to: AB+ only";
            case AB_NEGATIVE:
                return "Can receive: A-, B-, AB-, O- | Can donate to: AB+, AB-";
            case O_POSITIVE:
                return "Can receive: O+, O- | Can donate to: A+, B+, AB+, O+";
            case O_NEGATIVE:
                return "Can receive: O- only | Can donate to: All blood types";
            default:
                return "Unknown";
        }
    }
    
    private String enhanceRecommendations(String baseRecommendations, UserProfile userProfile) {
        StringBuilder enhanced = new StringBuilder(baseRecommendations);
        
        // Add personalized recommendations
        if (userProfile.getBmiCategory() != null) {
            switch (userProfile.getBmiCategory()) {
                case "Underweight":
                    enhanced.append("\n• Consider consulting a nutritionist for healthy weight gain");
                    break;
                case "Overweight":
                case "Obese":
                    enhanced.append("\n• Focus on gradual weight loss through diet and exercise");
                    enhanced.append("\n• Consider consulting a healthcare provider for a personalized plan");
                    break;
            }
        }
        
        if (userProfile.getAge() != null && userProfile.getAge() >= 50) {
            enhanced.append("\n• Schedule regular health screenings");
            enhanced.append("\n• Monitor blood pressure and cholesterol levels");
        }
        
        return enhanced.toString();
    }
    
    // Data classes for enhanced results
    public static class EnhancedPredictionResult {
        private List<EnhancedPredictionItem> predictions;
        private UserProfile userProfile;
        private List<String> riskFactors;
        private Integer lifestyleScore;
        private List<HealthInsight> healthInsights;
        private Double bmi;
        private String bmiCategory;
        private String ageGroup;
        private String bloodGroupCompatibility;
        
        // Builder pattern
        public static Builder builder() {
            return new Builder();
        }
        
        public static class Builder {
            private EnhancedPredictionResult result = new EnhancedPredictionResult();
            
            public Builder predictions(List<EnhancedPredictionItem> predictions) {
                result.predictions = predictions;
                return this;
            }
            
            public Builder userProfile(UserProfile userProfile) {
                result.userProfile = userProfile;
                return this;
            }
            
            public Builder riskFactors(List<String> riskFactors) {
                result.riskFactors = riskFactors;
                return this;
            }
            
            public Builder lifestyleScore(Integer lifestyleScore) {
                result.lifestyleScore = lifestyleScore;
                return this;
            }
            
            public Builder healthInsights(List<HealthInsight> healthInsights) {
                result.healthInsights = healthInsights;
                return this;
            }
            
            public Builder bmi(Double bmi) {
                result.bmi = bmi;
                return this;
            }
            
            public Builder bmiCategory(String bmiCategory) {
                result.bmiCategory = bmiCategory;
                return this;
            }
            
            public Builder ageGroup(String ageGroup) {
                result.ageGroup = ageGroup;
                return this;
            }
            
            public Builder bloodGroupCompatibility(String bloodGroupCompatibility) {
                result.bloodGroupCompatibility = bloodGroupCompatibility;
                return this;
            }
            
            public EnhancedPredictionResult build() {
                return result;
            }
        }
        
        // Getters
        public List<EnhancedPredictionItem> getPredictions() { return predictions; }
        public UserProfile getUserProfile() { return userProfile; }
        public List<String> getRiskFactors() { return riskFactors; }
        public Integer getLifestyleScore() { return lifestyleScore; }
        public List<HealthInsight> getHealthInsights() { return healthInsights; }
        public Double getBmi() { return bmi; }
        public String getBmiCategory() { return bmiCategory; }
        public String getAgeGroup() { return ageGroup; }
        public String getBloodGroupCompatibility() { return bloodGroupCompatibility; }
    }
    
    public static class EnhancedPredictionItem {
        private String diseaseName;
        private Double baseConfidence;
        private Double enhancedConfidence;
        private String riskLevel;
        private String recommendations;
        private String matchedSymptoms;
        private Double bloodGroupRisk;
        private Double bmiRisk;
        private Double ageRisk;
        
        // Builder pattern
        public static Builder builder() {
            return new Builder();
        }
        
        public static class Builder {
            private EnhancedPredictionItem item = new EnhancedPredictionItem();
            
            public Builder diseaseName(String diseaseName) {
                item.diseaseName = diseaseName;
                return this;
            }
            
            public Builder baseConfidence(Double baseConfidence) {
                item.baseConfidence = baseConfidence;
                return this;
            }
            
            public Builder enhancedConfidence(Double enhancedConfidence) {
                item.enhancedConfidence = enhancedConfidence;
                return this;
            }
            
            public Builder riskLevel(String riskLevel) {
                item.riskLevel = riskLevel;
                return this;
            }
            
            public Builder recommendations(String recommendations) {
                item.recommendations = recommendations;
                return this;
            }
            
            public Builder matchedSymptoms(String matchedSymptoms) {
                item.matchedSymptoms = matchedSymptoms;
                return this;
            }
            
            public Builder bloodGroupRisk(Double bloodGroupRisk) {
                item.bloodGroupRisk = bloodGroupRisk;
                return this;
            }
            
            public Builder bmiRisk(Double bmiRisk) {
                item.bmiRisk = bmiRisk;
                return this;
            }
            
            public Builder ageRisk(Double ageRisk) {
                item.ageRisk = ageRisk;
                return this;
            }
            
            public EnhancedPredictionItem build() {
                return item;
            }
        }
        
        // Getters
        public String getDiseaseName() { return diseaseName; }
        public Double getBaseConfidence() { return baseConfidence; }
        public Double getEnhancedConfidence() { return enhancedConfidence; }
        public String getRiskLevel() { return riskLevel; }
        public String getRecommendations() { return recommendations; }
        public String getMatchedSymptoms() { return matchedSymptoms; }
        public Double getBloodGroupRisk() { return bloodGroupRisk; }
        public Double getBmiRisk() { return bmiRisk; }
        public Double getAgeRisk() { return ageRisk; }
    }
    
    public static class HealthInsight {
        private String category;
        private String value;
        private String recommendation;
        
        public HealthInsight(String category, String value, String recommendation) {
            this.category = category;
            this.value = value;
            this.recommendation = recommendation;
        }
        
        // Getters
        public String getCategory() { return category; }
        public String getValue() { return value; }
        public String getRecommendation() { return recommendation; }
    }
}
