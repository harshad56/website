package com.example.projectodsem3.repository;

import com.example.projectodsem3.model.PredictionHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PredictionHistoryRepository extends JpaRepository<PredictionHistory, Long> {
}
