package com.example.projectodsem3.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "symptoms")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Symptom {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, unique = true)
    private String name;
    
    @Column(length = 500)
    private String description;
    
    @Column(length = 100)
    private String category;
    
    @Column
    private Double severity;
    
    @Column
    private Boolean isCommon;
    
    @Column
    private String bodyPart;
    
    @Column
    private String frequency;
    
    @Column
    private String duration;
    
    @Column
    private Boolean isEmergency;
    
    @Column
    private String relatedSymptoms;
}
