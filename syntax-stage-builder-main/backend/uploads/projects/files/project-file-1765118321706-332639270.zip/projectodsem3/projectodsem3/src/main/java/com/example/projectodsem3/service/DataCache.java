package com.example.projectodsem3.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.projectodsem3.model.Disease;
import com.example.projectodsem3.model.Symptom;
import com.example.projectodsem3.model.SymptomDiseaseCorrelation;

@Component
public class DataCache {

	private final List<Disease> diseases = new ArrayList<>();
	private final List<Symptom> symptoms = new ArrayList<>();
	private final List<SymptomDiseaseCorrelation> correlations = new ArrayList<>();

	public synchronized void setData(List<Disease> newDiseases,
			List<Symptom> newSymptoms,
			List<SymptomDiseaseCorrelation> newCorrelations) {
		diseases.clear();
		symptoms.clear();
		correlations.clear();
		if (newDiseases != null)
			diseases.addAll(newDiseases);
		if (newSymptoms != null)
			symptoms.addAll(newSymptoms);
		if (newCorrelations != null)
			correlations.addAll(newCorrelations);
	}

	public synchronized List<Disease> getDiseases() {
		return Collections.unmodifiableList(diseases);
	}

	public synchronized List<Symptom> getSymptoms() {
		return Collections.unmodifiableList(symptoms);
	}

	public synchronized List<SymptomDiseaseCorrelation> getCorrelations() {
		return Collections.unmodifiableList(correlations);
	}

	public synchronized boolean isLoaded() {
		return !diseases.isEmpty() && !symptoms.isEmpty() && !correlations.isEmpty();
	}

	public synchronized void clearData() {
		diseases.clear();
		symptoms.clear();
		correlations.clear();
	}
}
