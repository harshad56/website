package com.example.projectodsem3.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.util.List;
import java.util.Set;

@Entity
@Table(name = "diseases")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Disease {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, unique = true)
    private String name;
    
    @Column(length = 1000)
    private String description;
    
    @Column(length = 500)
    private String symptoms;
    
    @Column(length = 500)
    private String treatment;
    
    @Column(length = 500)
    private String prevention;
    
    @Column(length = 100)
    private String severity;
    
    @Column(length = 100)
    private String category;
    
    @Column
    private Double riskScore;
    
    @ElementCollection
    @CollectionTable(name = "disease_symptoms", joinColumns = @JoinColumn(name = "disease_id"))
    @Column(name = "symptom")
    private Set<String> symptomList;
    
    @Column
    private Integer ageGroupMin;
    
    @Column
    private Integer ageGroupMax;
    
    @Column
    private String genderPreference;
    
    @Column
    private Boolean isChronic;
    
    @Column
    private Boolean isContagious;
}
