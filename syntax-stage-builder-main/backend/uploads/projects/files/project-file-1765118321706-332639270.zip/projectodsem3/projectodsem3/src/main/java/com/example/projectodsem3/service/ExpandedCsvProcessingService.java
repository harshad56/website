package com.example.projectodsem3.service;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.projectodsem3.model.Disease;
import com.example.projectodsem3.model.Symptom;
import com.example.projectodsem3.model.SymptomDiseaseCorrelation;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ExpandedCsvProcessingService {
    
    /**
     * Process the expanded disease-symptom CSV file (from upload)
     */
    public Map<String, Object> processExpandedCsv(MultipartFile file) throws IOException, CsvValidationException {
        try (Reader reader = new InputStreamReader(file.getInputStream())) {
            return processExpandedCsv(reader);
        }
    }

    /**
     * Process the expanded disease-symptom CSV file (from Resource on disk)
     */
    public Map<String, Object> processExpandedCsv(Resource resource) throws IOException, CsvValidationException {
        try (Reader reader = new InputStreamReader(resource.getInputStream())) {
            return processExpandedCsv(reader);
        }
    }

    /**
     * Shared implementation reading from a Reader
     */
    private Map<String, Object> processExpandedCsv(Reader reader) throws IOException, CsvValidationException {
        Map<String, Object> result = new HashMap<>();

        Map<String, Disease> diseases = new HashMap<>();
        Map<String, Symptom> symptoms = new HashMap<>();
        List<SymptomDiseaseCorrelation> correlations = new ArrayList<>();

        try (CSVReader csvReader = new CSVReader(reader)) {
            String[] headers = csvReader.readNext();
            if (headers == null) {
                throw new IOException("CSV file is empty or invalid");
            }
            log.info("Processing expanded CSV with headers: {}", Arrays.toString(headers));

            String[] line;
            int lineCount = 0;
            while ((line = csvReader.readNext()) != null) {
                lineCount++;
                try {
                    processExpandedLine(line, headers, diseases, symptoms, correlations);
                } catch (Exception e) {
                    log.error("Error processing line {}: {}", lineCount, Arrays.toString(line), e);
                }
            }
            log.info("Processed {} lines from expanded CSV", lineCount);
        }

        List<Disease> diseaseList = new ArrayList<>(diseases.values());
        List<Symptom> symptomList = new ArrayList<>(symptoms.values());

        result.put("diseases", diseaseList);
        result.put("symptoms", symptomList);
        result.put("correlations", correlations);
        result.put("totalDiseases", diseaseList.size());
        result.put("totalSymptoms", symptomList.size());
        result.put("totalCorrelations", correlations.size());
        return result;
    }
    
    /**
     * Process a single line from the expanded CSV
     */
    private void processExpandedLine(String[] line, String[] headers, 
                                   Map<String, Disease> diseases, 
                                   Map<String, Symptom> symptoms,
                                   List<SymptomDiseaseCorrelation> correlations) {
        
        // Extract data from the line
        String diseaseName = getValue(line, headers, "Disease");
        String symptomName = getValue(line, headers, "Symptom");
        String severity = getValue(line, headers, "Severity");
        String ageGroup = getValue(line, headers, "Age Group");
        String onsetTime = getValue(line, headers, "Onset Time");
        String duration = getValue(line, headers, "Duration");
        String treatment = getValue(line, headers, "Treatment");
        String complications = getValue(line, headers, "Complications");
        String prevention = getValue(line, headers, "Prevention");
        String riskFactors = getValue(line, headers, "Risk Factors");
        String transmissionMode = getValue(line, headers, "Transmission Mode");
        String contagious = getValue(line, headers, "Contagious");
        String diagnosisMethod = getValue(line, headers, "Diagnosis Method");
        String mortalityRate = getValue(line, headers, "Mortality Rate");
        
        if (diseaseName == null || symptomName == null) {
            return; // Skip invalid lines
        }
        
        // Create or update Disease
        Disease disease = diseases.computeIfAbsent(diseaseName, k -> {
            Disease d = new Disease();
            d.setName(diseaseName);
            d.setSeverity(severity);
            d.setCategory(determineCategory(diseaseName));
            d.setRiskScore(calculateRiskScore(severity, mortalityRate, ageGroup));
            d.setAgeGroupMin(getAgeGroupMin(ageGroup));
            d.setAgeGroupMax(getAgeGroupMax(ageGroup));
            d.setGenderPreference("Both"); // Default, can be enhanced
            d.setIsChronic("Long-term".equalsIgnoreCase(duration));
            d.setIsContagious("Y".equalsIgnoreCase(contagious));
            d.setTreatment(treatment);
            d.setPrevention(prevention);
            d.setDescription(String.format("Disease: %s, Age Group: %s, Onset: %s, Duration: %s", 
                                        diseaseName, ageGroup, onsetTime, duration));
            return d;
        });
        
        // Create or update Symptom
        Symptom symptom = symptoms.computeIfAbsent(symptomName, k -> {
            Symptom s = new Symptom();
            s.setName(symptomName);
            s.setSeverity(parseSeverityToDouble(severity));
            s.setCategory(determineSymptomCategory(symptomName));
            s.setIsCommon(true); // Most symptoms in this dataset are common
            s.setBodyPart(determineBodyPart(symptomName));
            s.setFrequency("Variable");
            s.setDuration(duration);
            s.setIsEmergency(isEmergencySymptom(symptomName, severity));
            s.setDescription(String.format("Symptom: %s, Severity: %s, Age Group: %s", 
                                        symptomName, severity, ageGroup));
            return s;
        });
        
        // Create correlation
        SymptomDiseaseCorrelation correlation = new SymptomDiseaseCorrelation();
        correlation.setSymptom(symptom);
        correlation.setDisease(disease);
        correlation.setCorrelationWeight(calculateCorrelationWeight(severity, ageGroup, onsetTime));
        correlation.setConfidence(calculateConfidence(severity, diagnosisMethod, mortalityRate));
        correlation.setNotes(String.format("Onset: %s, Duration: %s, Risk: %s", 
                                        onsetTime, duration, riskFactors));
        correlation.setIsPrimarySymptom(isPrimarySymptom(severity, onsetTime));
        correlation.setIsSecondarySymptom(!isPrimarySymptom(severity, onsetTime));
        correlation.setSymptomOrder(1); // Default order
        
        correlations.add(correlation);
    }
    
    /**
     * Get value from line based on header
     */
    private String getValue(String[] line, String[] headers, String headerName) {
        for (int i = 0; i < headers.length; i++) {
            if (headers[i].trim().equalsIgnoreCase(headerName)) {
                return i < line.length ? (line[i] != null ? line[i].trim() : "") : "";
            }
        }
        return "";
    }
    
    /**
     * Determine disease category based on disease name
     */
    private String determineCategory(String diseaseName) {
        String lowerName = diseaseName.toLowerCase();
        
        if (lowerName.contains("heart") || lowerName.contains("stroke") || lowerName.contains("hypertension")) {
            return "Cardiovascular";
        } else if (lowerName.contains("diabetes") || lowerName.contains("thyroid")) {
            return "Endocrine";
        } else if (lowerName.contains("asthma") || lowerName.contains("pneumonia") || lowerName.contains("copd")) {
            return "Respiratory";
        } else if (lowerName.contains("arthritis") || lowerName.contains("gout")) {
            return "Musculoskeletal";
        } else if (lowerName.contains("depression") || lowerName.contains("schizophrenia") || lowerName.contains("bipolar")) {
            return "Mental Health";
        } else if (lowerName.contains("cancer") || lowerName.contains("tumor")) {
            return "Oncology";
        } else if (lowerName.contains("kidney") || lowerName.contains("liver")) {
            return "Gastroenterology";
        } else if (lowerName.contains("alzheimer") || lowerName.contains("parkinson") || lowerName.contains("multiple sclerosis")) {
            return "Neurological";
        } else if (lowerName.contains("hiv") || lowerName.contains("aids") || lowerName.contains("tuberculosis")) {
            return "Infectious";
        } else {
            return "General";
        }
    }
    
    /**
     * Calculate risk score based on severity, mortality rate, and age group
     */
    private Double calculateRiskScore(String severity, String mortalityRate, String ageGroup) {
        double score = 5.0; // Base score
        
        // Severity factor
        switch (severity.toLowerCase()) {
            case "severe": score += 3.0; break;
            case "moderate": score += 2.0; break;
            case "mild": score += 1.0; break;
        }
        
        // Mortality rate factor
        switch (mortalityRate.toLowerCase()) {
            case "high": score += 3.0; break;
            case "moderate": score += 2.0; break;
            case "low": score += 1.0; break;
        }
        
        // Age group factor
        switch (ageGroup.toLowerCase()) {
            case "senior": score += 2.0; break;
            case "adult": score += 1.0; break;
            case "child": score += 0.5; break;
        }
        
        return Math.min(10.0, score);
    }
    
    /**
     * Get minimum age for age group
     */
    private Integer getAgeGroupMin(String ageGroup) {
        switch (ageGroup.toLowerCase()) {
            case "child": return 0;
            case "adult": return 18;
            case "senior": return 65;
            default: return 0;
        }
    }
    
    /**
     * Get maximum age for age group
     */
    private Integer getAgeGroupMax(String ageGroup) {
        switch (ageGroup.toLowerCase()) {
            case "child": return 17;
            case "adult": return 64;
            case "senior": return 120;
            default: return 120;
        }
    }
    
    /**
     * Parse severity string to double
     */
    private Double parseSeverityToDouble(String severity) {
        switch (severity.toLowerCase()) {
            case "severe": return 8.5;
            case "moderate": return 6.0;
            case "mild": return 3.5;
            default: return 5.0;
        }
    }
    
    /**
     * Determine symptom category
     */
    private String determineSymptomCategory(String symptomName) {
        String lowerName = symptomName.toLowerCase();
        
        if (lowerName.contains("pain") || lowerName.contains("ache")) {
            return "Pain";
        } else if (lowerName.contains("fever") || lowerName.contains("chills")) {
            return "Fever";
        } else if (lowerName.contains("cough") || lowerName.contains("breathing") || lowerName.contains("throat")) {
            return "Respiratory";
        } else if (lowerName.contains("head") || lowerName.contains("dizzy")) {
            return "Neurological";
        } else if (lowerName.contains("stomach") || lowerName.contains("abdominal") || lowerName.contains("nausea")) {
            return "Digestive";
        } else if (lowerName.contains("joint") || lowerName.contains("muscle")) {
            return "Musculoskeletal";
        } else if (lowerName.contains("skin") || lowerName.contains("rash")) {
            return "Dermatological";
        } else {
            return "General";
        }
    }
    
    /**
     * Determine body part for symptom
     */
    private String determineBodyPart(String symptomName) {
        String lowerName = symptomName.toLowerCase();
        
        if (lowerName.contains("head") || lowerName.contains("brain")) {
            return "Head";
        } else if (lowerName.contains("chest") || lowerName.contains("heart")) {
            return "Chest";
        } else if (lowerName.contains("stomach") || lowerName.contains("abdominal")) {
            return "Abdomen";
        } else if (lowerName.contains("joint") || lowerName.contains("muscle")) {
            return "Joints/Muscles";
        } else if (lowerName.contains("skin")) {
            return "Skin";
        } else {
            return "Whole body";
        }
    }
    
    /**
     * Check if symptom is emergency
     */
    private Boolean isEmergencySymptom(String symptomName, String severity) {
        String lowerName = symptomName.toLowerCase();
        return "severe".equalsIgnoreCase(severity) && 
               (lowerName.contains("chest pain") || lowerName.contains("difficulty breathing") || 
                lowerName.contains("severe headache") || lowerName.contains("unconscious"));
    }
    
    /**
     * Calculate correlation weight
     */
    private Double calculateCorrelationWeight(String severity, String ageGroup, String onsetTime) {
        double weight = 5.0; // Base weight
        
        // Severity factor
        switch (severity.toLowerCase()) {
            case "severe": weight += 3.0; break;
            case "moderate": weight += 2.0; break;
            case "mild": weight += 1.0; break;
        }
        
        // Age group factor
        switch (ageGroup.toLowerCase()) {
            case "senior": weight += 1.0; break;
            case "adult": weight += 0.5; break;
        }
        
        // Onset time factor
        if ("sudden".equalsIgnoreCase(onsetTime)) {
            weight += 1.0;
        }
        
        return Math.min(10.0, weight);
    }
    
    /**
     * Calculate confidence level
     */
    private Double calculateConfidence(String severity, String diagnosisMethod, String mortalityRate) {
        double confidence = 0.7; // Base confidence
        
        // Severity factor
        switch (severity.toLowerCase()) {
            case "severe": confidence += 0.2; break;
            case "moderate": confidence += 0.1; break;
        }
        
        // Diagnosis method factor
        if ("blood test".equalsIgnoreCase(diagnosisMethod) || "imaging".equalsIgnoreCase(diagnosisMethod)) {
            confidence += 0.1;
        }
        
        return Math.min(1.0, confidence);
    }
    
    /**
     * Determine if symptom is primary
     */
    private Boolean isPrimarySymptom(String severity, String onsetTime) {
        return "severe".equalsIgnoreCase(severity) || "sudden".equalsIgnoreCase(onsetTime);
    }
    
    /**
     * Get statistical analysis of the expanded dataset
     */
    public Map<String, Object> getExpandedDatasetAnalytics(List<Disease> diseases, 
                                                          List<Symptom> symptoms, 
                                                          List<SymptomDiseaseCorrelation> correlations) {
        
        Map<String, Object> analytics = new HashMap<>();
        
        // Disease distribution by category
        Map<String, Long> categoryDistribution = diseases.stream()
                .filter(d -> d.getCategory() != null)
                .collect(Collectors.groupingBy(Disease::getCategory, Collectors.counting()));
        analytics.put("categoryDistribution", categoryDistribution);
        
        // Severity distribution
        Map<String, Long> severityDistribution = diseases.stream()
                .filter(d -> d.getSeverity() != null)
                .collect(Collectors.groupingBy(Disease::getSeverity, Collectors.counting()));
        analytics.put("severityDistribution", severityDistribution);
        
        // Age group distribution
        Map<String, Long> ageGroupDistribution = diseases.stream()
                .filter(d -> d.getAgeGroupMin() != null)
                .collect(Collectors.groupingBy(d -> {
                    if (d.getAgeGroupMin() < 18) return "Child";
                    else if (d.getAgeGroupMin() < 65) return "Adult";
                    else return "Senior";
                }, Collectors.counting()));
        analytics.put("ageGroupDistribution", ageGroupDistribution);
        
        // Symptom category distribution
        Map<String, Long> symptomCategoryDistribution = symptoms.stream()
                .filter(s -> s.getCategory() != null)
                .collect(Collectors.groupingBy(Symptom::getCategory, Collectors.counting()));
        analytics.put("symptomCategoryDistribution", symptomCategoryDistribution);
        
        // Emergency symptoms count
        long emergencySymptoms = symptoms.stream()
                .filter(s -> s.getIsEmergency() != null && s.getIsEmergency())
                .count();
        analytics.put("emergencySymptoms", emergencySymptoms);
        
        // Chronic vs Acute diseases
        long chronicCount = diseases.stream()
                .filter(d -> d.getIsChronic() != null && d.getIsChronic())
                .count();
        long acuteCount = diseases.size() - chronicCount;
        analytics.put("chronicDiseases", chronicCount);
        analytics.put("acuteDiseases", acuteCount);
        
        // Contagious diseases count
        long contagiousCount = diseases.stream()
                .filter(d -> d.getIsContagious() != null && d.getIsContagious())
                .count();
        analytics.put("contagiousDiseases", contagiousCount);
        
        // Average risk scores
        double avgRiskScore = diseases.stream()
                .filter(d -> d.getRiskScore() != null)
                .mapToDouble(Disease::getRiskScore)
                .average()
                .orElse(0.0);
        analytics.put("averageRiskScore", avgRiskScore);
        
        // High-risk diseases (risk score > 7)
        long highRiskDiseases = diseases.stream()
                .filter(d -> d.getRiskScore() != null && d.getRiskScore() > 7.0)
                .count();
        analytics.put("highRiskDiseases", highRiskDiseases);
        
        return analytics;
    }
}
