package com.example.projectodsem3.controller;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.projectodsem3.model.Disease;
import com.example.projectodsem3.model.PredictionHistory;
import com.example.projectodsem3.model.PredictionItem;
import com.example.projectodsem3.model.Symptom;
import com.example.projectodsem3.model.SymptomDiseaseCorrelation;
import com.example.projectodsem3.model.UserProfile;
import com.example.projectodsem3.repository.PredictionHistoryRepository;
import com.example.projectodsem3.repository.PredictionItemRepository;
import com.example.projectodsem3.repository.UserProfileRepository;
import com.example.projectodsem3.service.CsvProcessingService;
import com.example.projectodsem3.service.DataCache;
import com.example.projectodsem3.service.DataPersistenceService;
import com.example.projectodsem3.service.DiseasePredictionService;
import com.example.projectodsem3.service.EnhancedPredictionService;
import com.example.projectodsem3.service.ExpandedCsvProcessingService;

@RestController
@RequestMapping("/api/medical")
@CrossOrigin(origins = "*")
public class MedicalDataController {

    @Autowired
    private CsvProcessingService csvProcessingService;

    @Autowired
    private DiseasePredictionService diseasePredictionService;

    @Autowired
    private ExpandedCsvProcessingService expandedCsvProcessingService;

    @Autowired
    private DataCache dataCache;

    @Autowired
    private DataPersistenceService dataPersistenceService;

    @Autowired
    private PredictionHistoryRepository predictionHistoryRepository;

    @Autowired
    private PredictionItemRepository predictionItemRepository;

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private EnhancedPredictionService enhancedPredictionService;

    @PostMapping("/upload/expanded")
    public ResponseEntity<Map<String, Object>> uploadExpandedCsv(@RequestParam("file") MultipartFile file) {
        try {
            Map<String, Object> result = expandedCsvProcessingService.processExpandedCsv(file);
            @SuppressWarnings("unchecked")
            List<Disease> diseases = (List<Disease>) result.get("diseases");
            @SuppressWarnings("unchecked")
            List<Symptom> symptoms = (List<Symptom>) result.get("symptoms");
            @SuppressWarnings("unchecked")
            List<SymptomDiseaseCorrelation> correlations = (List<SymptomDiseaseCorrelation>) result.get("correlations");
            dataPersistenceService.persistAll(diseases, symptoms, correlations);
            dataCache.setData(diseases, symptoms, correlations);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Expanded medical dataset uploaded successfully");
            response.put("totalDiseases", result.get("totalDiseases"));
            response.put("totalSymptoms", result.get("totalSymptoms"));
            response.put("totalCorrelations", result.get("totalCorrelations"));
            response.put("diseases", diseases.stream().map(Disease::getName).collect(Collectors.toList()));
            response.put("symptoms", symptoms.stream().map(Symptom::getName).collect(Collectors.toList()));
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Failed to process expanded CSV: " + e.getMessage()));
        }
    }

    @PostMapping("/predict")
    public ResponseEntity<?> predictDiseases(@RequestBody DiseasePredictionRequest request) {
        try {
            if (!dataCache.isLoaded()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Please upload disease, symptom, and correlation data first"));
            }

            List<String> symptoms = Arrays.asList(request.getSymptoms().split(","));
            List<DiseasePredictionService.DiseasePredictionResult> results = diseasePredictionService
                    .predictDiseases(symptoms, request.getAge(), request.getGender());

            // Save prediction history
            PredictionHistory history = new PredictionHistory();
            history.setInputSymptoms(String.join(", ", symptoms));
            history.setAge(request.getAge());
            history.setGender(request.getGender());
            history.setTimestamp(java.time.LocalDateTime.now());

            // Create prediction items
            List<PredictionItem> items = results.stream()
                    .map(pred -> {
                        PredictionItem item = new PredictionItem();
                        item.setDiseaseName(pred.getDisease().getName());
                        item.setConfidenceScore(pred.getConfidenceScore());
                        item.setRiskLevel(pred.getRiskLevel());
                        item.setRecommendations(String.join(", ", pred.getRecommendations()));
                        item.setMatchedSymptoms(String.join(", ", pred.getMatchedSymptoms()));
                        item.setPredictionHistory(history);
                        return item;
                    })
                    .collect(Collectors.toList());

            history.setPredictions(items);
            predictionHistoryRepository.save(history);

            // Create response structure
            Map<String, Object> response = new HashMap<>();
            response.put("totalResults", results.size());
            response.put("gender", request.getGender());
            response.put("inputSymptoms", symptoms);
            response.put("predictions", results);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Prediction failed: " + e.getMessage()));
        }
    }

    @PostMapping("/predict/enhanced")
    public ResponseEntity<?> predictDiseasesEnhanced(@RequestBody EnhancedPredictionRequest request) {
        try {
            if (!dataCache.isLoaded()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Please upload disease, symptom, and correlation data first"));
            }

            // Create or update user profile
            UserProfile userProfile = createOrUpdateUserProfile(request);

            List<String> symptoms = Arrays.asList(request.getSymptoms().split(","));
            EnhancedPredictionService.EnhancedPredictionResult result = enhancedPredictionService
                    .predictDiseasesWithUserProfile(symptoms, userProfile);

            // Save enhanced prediction history
            saveEnhancedPredictionHistory(result, userProfile);

            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Enhanced prediction failed: " + e.getMessage()));
        }
    }

    @PostMapping("/user/profile")
    public ResponseEntity<?> createUserProfile(@RequestBody UserProfileRequest request) {
        try {
            UserProfile userProfile = new UserProfile();
            userProfile.setName(request.getName());
            userProfile.setAge(request.getAge());
            userProfile.setBloodGroup(UserProfile.BloodGroup.valueOf(request.getBloodGroup()));
            userProfile.setHeightCm(request.getHeightCm());
            userProfile.setWeightKg(request.getWeightKg());
            userProfile.setGender(UserProfile.Gender.valueOf(request.getGender()));
            userProfile.setContactNumber(request.getContactNumber());
            userProfile.setEmergencyContact(request.getEmergencyContact());
            userProfile.setMedicalHistory(request.getMedicalHistory());
            userProfile.setAllergies(request.getAllergies());
            userProfile.setCurrentMedications(request.getCurrentMedications());
            userProfile.setLifestyleFactors(request.getLifestyleFactors());

            UserProfile saved = userProfileRepository.save(userProfile);
            return ResponseEntity.ok(saved);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Failed to create user profile: " + e.getMessage()));
        }
    }

    @GetMapping("/user/profile/{id}")
    public ResponseEntity<?> getUserProfile(@PathVariable Long id) {
        try {
            Optional<UserProfile> profile = userProfileRepository.findById(id);
            if (profile.isPresent()) {
                return ResponseEntity.ok(profile.get());
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Failed to get user profile: " + e.getMessage()));
        }
    }

    @GetMapping("/user/profiles")
    public ResponseEntity<?> getAllUserProfiles() {
        try {
            List<UserProfile> profiles = userProfileRepository.findAll();

            // Convert to simple DTOs to avoid circular reference
            List<Map<String, Object>> profileDTOs = profiles.stream()
                    .map(profile -> {
                        Map<String, Object> dto = new HashMap<>();
                        dto.put("id", profile.getId());
                        dto.put("name", profile.getName());
                        dto.put("age", profile.getAge());
                        dto.put("bloodGroup", Map.of("displayValue", profile.getBloodGroup().getDisplayValue()));
                        dto.put("heightCm", profile.getHeightCm());
                        dto.put("weightKg", profile.getWeightKg());
                        dto.put("gender", Map.of("displayValue", profile.getGender().getDisplayValue()));
                        dto.put("contactNumber", profile.getContactNumber());
                        dto.put("emergencyContact", profile.getEmergencyContact());
                        dto.put("medicalHistory", profile.getMedicalHistory());
                        dto.put("allergies", profile.getAllergies());
                        dto.put("currentMedications", profile.getCurrentMedications());
                        dto.put("lifestyleFactors", profile.getLifestyleFactors());
                        dto.put("bmi", profile.getBmi());
                        dto.put("bmiCategory", profile.getBmiCategory());
                        dto.put("ageGroup", profile.getAgeGroup());
                        dto.put("createdAt", profile.getCreatedAt());
                        dto.put("lastUpdated", profile.getLastUpdated());
                        return dto;
                    })
                    .collect(Collectors.toList());

            return ResponseEntity.ok(profileDTOs);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Failed to get user profiles: " + e.getMessage()));
        }
    }

    @GetMapping("/analytics/users")
    public ResponseEntity<?> getUserAnalytics() {
        try {
            Map<String, Object> analytics = new HashMap<>();

            // Blood group distribution
            Map<String, Long> bloodGroupStats = new HashMap<>();
            for (UserProfile.BloodGroup bg : UserProfile.BloodGroup.values()) {
                long count = userProfileRepository.countByBloodGroup(bg);
                bloodGroupStats.put(bg.getDisplayValue(), count);
            }
            analytics.put("bloodGroupDistribution", bloodGroupStats);

            // Age statistics
            Double avgAge = userProfileRepository.getAverageAge();
            analytics.put("averageAge", avgAge);

            // BMI statistics - calculated from height and weight
            List<UserProfile> allProfiles = userProfileRepository.findAll();
            double avgBmi = allProfiles.stream()
                    .filter(p -> p.getHeightCm() != null && p.getWeightKg() != null)
                    .mapToDouble(UserProfile::getBmi)
                    .average()
                    .orElse(0.0);
            analytics.put("averageBmi", avgBmi);

            // Gender distribution
            long maleCount = userProfileRepository.findByGender(UserProfile.Gender.MALE).size();
            long femaleCount = userProfileRepository.findByGender(UserProfile.Gender.FEMALE).size();
            long otherCount = userProfileRepository.findByGender(UserProfile.Gender.OTHER).size();

            Map<String, Long> genderStats = Map.of(
                    "Male", maleCount,
                    "Female", femaleCount,
                    "Other", otherCount);
            analytics.put("genderDistribution", genderStats);

            return ResponseEntity.ok(analytics);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Failed to get user analytics: " + e.getMessage()));
        }
    }

    @GetMapping("/analytics/predictions/insights")
    public ResponseEntity<Map<String, Object>> predictionInsights() {
        // Simple aggregates: counts by riskLevel; top diseases by items count
        List<PredictionItem> items = predictionItemRepository.findAll();
        Map<String, Long> byRisk = items.stream().collect(Collectors
                .groupingBy(i -> Optional.ofNullable(i.getRiskLevel()).orElse("UNKNOWN"), Collectors.counting()));
        Map<String, Long> topDiseases = items.stream()
                .collect(Collectors.groupingBy(i -> i.getDiseaseName(), Collectors.counting()))
                .entrySet().stream().sorted((a, b) -> Long.compare(b.getValue(), a.getValue())).limit(10)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> a, LinkedHashMap::new));
        Map<String, Object> res = new HashMap<>();
        res.put("byRisk", byRisk);
        res.put("topDiseases", topDiseases);
        res.put("totalPredictions", items.size());
        return ResponseEntity.ok(res);
    }

    /**
     * Get expanded dataset analytics
     */
    @GetMapping("/analytics/expanded")
    public ResponseEntity<Map<String, Object>> getExpandedDatasetAnalytics() {
        try {
            if (!dataCache.isLoaded()) {
                Map<String, Object> error = new HashMap<>();
                error.put("error", "No dataset loaded");
                return ResponseEntity.badRequest().body(error);
            }

            Map<String, Object> analytics = expandedCsvProcessingService.getExpandedDatasetAnalytics(
                    dataCache.getDiseases(), dataCache.getSymptoms(), dataCache.getCorrelations());

            Map<String, Object> response = new HashMap<>();
            response.put("expandedAnalytics", analytics);
            response.put("totalDiseases", dataCache.getDiseases().size());
            response.put("totalSymptoms", dataCache.getSymptoms().size());
            response.put("totalCorrelations", dataCache.getCorrelations().size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Failed to generate expanded analytics: " + e.getMessage()));
        }
    }

    /**
     * Get all available symptoms
     */
    @GetMapping("/symptoms")
    public ResponseEntity<List<String>> getAllSymptoms() {
        if (!dataCache.isLoaded())
            return ResponseEntity.ok(Collections.emptyList());
        List<String> symptomNames = dataCache.getSymptoms().stream()
                .map(Symptom::getName)
                .collect(Collectors.toList());
        return ResponseEntity.ok(symptomNames);
    }

    /**
     * Get all available diseases
     */
    @GetMapping("/diseases")
    public ResponseEntity<List<Map<String, Object>>> getAllDiseases() {
        if (!dataCache.isLoaded())
            return ResponseEntity.ok(Collections.emptyList());
        List<Map<String, Object>> diseaseData = dataCache.getDiseases().stream()
                .map(disease -> {
                    Map<String, Object> data = new HashMap<>();
                    data.put("id", disease.getId());
                    data.put("name", disease.getName());
                    data.put("category", disease.getCategory());
                    data.put("severity", disease.getSeverity());
                    data.put("description", disease.getDescription());
                    return data;
                })
                .collect(Collectors.toList());
        return ResponseEntity.ok(diseaseData);
    }

    /**
     * Get all symptom-disease correlations
     */
    @GetMapping("/correlations")
    public ResponseEntity<List<Map<String, Object>>> getAllCorrelations() {
        if (!dataCache.isLoaded())
            return ResponseEntity.ok(Collections.emptyList());
        List<Map<String, Object>> correlationData = dataCache.getCorrelations().stream()
                .map(correlation -> {
                    Map<String, Object> data = new HashMap<>();
                    data.put("id", correlation.getId());
                    data.put("symptomName", correlation.getSymptom().getName());
                    data.put("diseaseName", correlation.getDisease().getName());
                    // Updated to match entity fields
                    data.put("correlationWeight", correlation.getCorrelationWeight());
                    data.put("confidence", correlation.getConfidence());
                    return data;
                })
                .collect(Collectors.toList());
        return ResponseEntity.ok(correlationData);
    }

    /**
     * Delete user profile by ID
     */
    @PostMapping("/user/profile/{id}/delete")
    public ResponseEntity<?> deleteUserProfile(@PathVariable Long id) {
        try {
            Optional<UserProfile> profile = userProfileRepository.findById(id);
            if (profile.isPresent()) {
                userProfileRepository.deleteById(id);
                return ResponseEntity.ok(Map.of("message", "Profile deleted successfully", "deletedId", id));
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Failed to delete profile: " + e.getMessage()));
        }
    }

    /**
     * Clear all database data (use with caution)
     */
    @PostMapping("/database/clear")
    public ResponseEntity<?> clearDatabase() {
        try {
            dataPersistenceService.clearAllData();
            dataCache.clearData();
            return ResponseEntity.ok(Map.of("message", "Database cleared successfully"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Failed to clear database: " + e.getMessage()));
        }
    }

    private UserProfile createOrUpdateUserProfile(EnhancedPredictionRequest request) {
        // Try to find existing profile by name and contact
        Optional<UserProfile> existingProfile = userProfileRepository.findByNameIgnoreCase(request.getName());

        UserProfile userProfile;
        if (existingProfile.isPresent()) {
            userProfile = existingProfile.get();
            // Update fields
            userProfile.setAge(request.getAge());
            userProfile.setBloodGroup(UserProfile.BloodGroup.valueOf(request.getBloodGroup()));
            userProfile.setHeightCm(request.getHeightCm());
            userProfile.setWeightKg(request.getWeightKg());
            userProfile.setGender(UserProfile.Gender.valueOf(request.getGender()));
        } else {
            userProfile = new UserProfile();
            userProfile.setName(request.getName());
            userProfile.setAge(request.getAge());
            userProfile.setBloodGroup(UserProfile.BloodGroup.valueOf(request.getBloodGroup()));
            userProfile.setHeightCm(request.getHeightCm());
            userProfile.setWeightKg(request.getWeightKg());
            userProfile.setGender(UserProfile.Gender.valueOf(request.getGender()));
        }

        return userProfileRepository.save(userProfile);
    }

    private void saveEnhancedPredictionHistory(EnhancedPredictionService.EnhancedPredictionResult result,
            UserProfile userProfile) {
        PredictionHistory history = new PredictionHistory();
        history.setUserProfile(userProfile);
        history.setInputSymptoms(
                String.join(", ", Arrays.asList(result.getPredictions().get(0).getMatchedSymptoms().split(","))));
        history.setAge(userProfile.getAge());
        history.setGender(userProfile.getGender().getDisplayValue());
        history.setBloodGroup(userProfile.getBloodGroup().getDisplayValue());
        history.setBmi(userProfile.getBmi());
        history.setBmiCategory(userProfile.getBmiCategory());
        history.setRiskFactors(String.join(", ", result.getRiskFactors()));
        history.setLifestyleScore(result.getLifestyleScore());
        history.setTimestamp(java.time.LocalDateTime.now());

        // Create prediction items
        List<PredictionItem> items = result.getPredictions().stream()
                .map(pred -> {
                    PredictionItem item = new PredictionItem();
                    item.setDiseaseName(pred.getDiseaseName());
                    item.setConfidenceScore(pred.getEnhancedConfidence());
                    item.setRiskLevel(pred.getRiskLevel());
                    item.setRecommendations(pred.getRecommendations());
                    item.setMatchedSymptoms(pred.getMatchedSymptoms());
                    item.setPredictionHistory(history);
                    return item;
                })
                .collect(Collectors.toList());

        history.setPredictions(items);
        predictionHistoryRepository.save(history);
    }

    // Request/Response classes
    public static class DiseasePredictionRequest {
        private String symptoms;
        private Integer age;
        private String gender;

        // Getters and setters
        public String getSymptoms() {
            return symptoms;
        }

        public void setSymptoms(String symptoms) {
            this.symptoms = symptoms;
        }

        public Integer getAge() {
            return age;
        }

        public void setAge(Integer age) {
            this.age = age;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }
    }

    public static class EnhancedPredictionRequest {
        private String symptoms;
        private String name;
        private Integer age;
        private String bloodGroup;
        private Double heightCm;
        private Double weightKg;
        private String gender;
        private String contactNumber;
        private String emergencyContact;
        private String medicalHistory;
        private String allergies;
        private String currentMedications;
        private String lifestyleFactors;

        // Getters and setters
        public String getSymptoms() {
            return symptoms;
        }

        public void setSymptoms(String symptoms) {
            this.symptoms = symptoms;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getAge() {
            return age;
        }

        public void setAge(Integer age) {
            this.age = age;
        }

        public String getBloodGroup() {
            return bloodGroup;
        }

        public void setBloodGroup(String bloodGroup) {
            this.bloodGroup = bloodGroup;
        }

        public Double getHeightCm() {
            return heightCm;
        }

        public void setHeightCm(Double heightCm) {
            this.heightCm = heightCm;
        }

        public Double getWeightKg() {
            return weightKg;
        }

        public void setWeightKg(Double weightKg) {
            this.weightKg = weightKg;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public String getContactNumber() {
            return contactNumber;
        }

        public void setContactNumber(String contactNumber) {
            this.contactNumber = contactNumber;
        }

        public String getEmergencyContact() {
            return emergencyContact;
        }

        public void setEmergencyContact(String emergencyContact) {
            this.emergencyContact = emergencyContact;
        }

        public String getMedicalHistory() {
            return medicalHistory;
        }

        public void setMedicalHistory(String medicalHistory) {
            this.medicalHistory = medicalHistory;
        }

        public String getAllergies() {
            return allergies;
        }

        public void setAllergies(String allergies) {
            this.allergies = allergies;
        }

        public String getCurrentMedications() {
            return currentMedications;
        }

        public void setCurrentMedications(String currentMedications) {
            this.currentMedications = currentMedications;
        }

        public String getLifestyleFactors() {
            return lifestyleFactors;
        }

        public void setLifestyleFactors(String lifestyleFactors) {
            this.lifestyleFactors = lifestyleFactors;
        }
    }

    public static class UserProfileRequest {
        private String name;
        private Integer age;
        private String bloodGroup;
        private Double heightCm;
        private Double weightKg;
        private String gender;
        private String contactNumber;
        private String emergencyContact;
        private String medicalHistory;
        private String allergies;
        private String currentMedications;
        private String lifestyleFactors;

        // Getters and setters
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getAge() {
            return age;
        }

        public void setAge(Integer age) {
            this.age = age;
        }

        public String getBloodGroup() {
            return bloodGroup;
        }

        public void setBloodGroup(String bloodGroup) {
            this.bloodGroup = bloodGroup;
        }

        public Double getHeightCm() {
            return heightCm;
        }

        public void setHeightCm(Double heightCm) {
            this.heightCm = heightCm;
        }

        public Double getWeightKg() {
            return weightKg;
        }

        public void setWeightKg(Double weightKg) {
            this.weightKg = weightKg;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public String getContactNumber() {
            return contactNumber;
        }

        public void setContactNumber(String contactNumber) {
            this.contactNumber = contactNumber;
        }

        public String getEmergencyContact() {
            return emergencyContact;
        }

        public void setEmergencyContact(String emergencyContact) {
            this.emergencyContact = emergencyContact;
        }

        public String getMedicalHistory() {
            return medicalHistory;
        }

        public void setMedicalHistory(String medicalHistory) {
            this.medicalHistory = medicalHistory;
        }

        public String getAllergies() {
            return allergies;
        }

        public void setAllergies(String allergies) {
            this.allergies = allergies;
        }

        public String getCurrentMedications() {
            return currentMedications;
        }

        public void setCurrentMedications(String currentMedications) {
            this.currentMedications = currentMedications;
        }

        public String getLifestyleFactors() {
            return lifestyleFactors;
        }

        public void setLifestyleFactors(String lifestyleFactors) {
            this.lifestyleFactors = lifestyleFactors;
        }
    }
}
