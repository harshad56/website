package com.example.projectodsem3.controller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StaticPageController {

    @GetMapping(value = { "/heatmap", "/heatmap.html" })
    public ResponseEntity<Resource> heatmap() {
        Resource res = new ClassPathResource("static/heatmap.html");
        if (!res.exists())
            return ResponseEntity.notFound().build();
        return ResponseEntity.ok().contentType(MediaType.TEXT_HTML).body(res);
    }
}