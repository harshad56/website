package com.example.projectodsem3.repository;

import com.example.projectodsem3.model.PredictionItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PredictionItemRepository extends JpaRepository<PredictionItem, Long> {
}
