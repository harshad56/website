package com.example.projectodsem3.service;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.projectodsem3.model.Disease;
import com.example.projectodsem3.model.Symptom;
import com.example.projectodsem3.model.SymptomDiseaseCorrelation;

/**
 * Lightweight Naive Bayes-style classifier built from current DataCache.
 * - No external ML deps
 * - Trains lazily from correlations
 * - Does not affect existing services
 */
@Service
public class MlPredictionService {

    private final DataCache dataCache;

    private final AtomicBoolean modelBuilt = new AtomicBoolean(false);

    // Model structures
    private Map<String, Integer> symptomIndex = new HashMap<>();
    private List<String> indexToSymptom = new ArrayList<>();
    private Map<String, Integer> diseaseIndex = new HashMap<>();
    private List<String> indexToDisease = new ArrayList<>();

    // Likelihoods: P(symptom|disease) with Laplace smoothing stored as log-prob
    // dims: diseases x symptoms
    private double[][] logLikelihood;
    private double[] logPriors; // log P(disease)

    public MlPredictionService(DataCache dataCache) {
        this.dataCache = dataCache;
    }

    public synchronized void rebuildModelIfNeeded() {
        if (modelBuilt.get())
            return;
        buildModel();
    }

    public synchronized void forceRebuildModel() {
        buildModel();
    }

    private void buildModel() {
        List<SymptomDiseaseCorrelation> correlations = dataCache.getCorrelations();
        List<Disease> diseases = dataCache.getDiseases();
        List<Symptom> symptoms = dataCache.getSymptoms();

        if (correlations.isEmpty() || diseases.isEmpty() || symptoms.isEmpty()) {
            // Not enough data
            modelBuilt.set(false);
            return;
        }

        // Index diseases
        diseaseIndex.clear();
        indexToDisease.clear();
        for (Disease d : diseases) {
            diseaseIndex.put(d.getName(), indexToDisease.size());
            indexToDisease.add(d.getName());
        }

        // Index symptoms (from repo symptoms list)
        symptomIndex.clear();
        indexToSymptom.clear();
        for (Symptom s : symptoms) {
            symptomIndex.put(s.getName(), indexToSymptom.size());
            indexToSymptom.add(s.getName());
        }

        int D = indexToDisease.size();
        int S = indexToSymptom.size();
        double alpha = 1.0; // Laplace smoothing

        // Count matrices
        double[][] symptomCounts = new double[D][S];
        double[] diseaseTotals = new double[D];

        // Aggregate counts weighted by correlationWeight (>= 0)
        for (SymptomDiseaseCorrelation c : correlations) {
            String dName = c.getDisease().getName();
            String sName = c.getSymptom().getName();
            Integer di = diseaseIndex.get(dName);
            Integer si = symptomIndex.get(sName);
            if (di == null || si == null)
                continue;
            double w = Optional.ofNullable(c.getCorrelationWeight()).orElse(1.0);
            symptomCounts[di][si] += Math.max(0.0, w);
            diseaseTotals[di] += Math.max(0.0, w);
        }

        // Priors as normalized diseaseTotals, fallback to uniform
        logPriors = new double[D];
        double total = Arrays.stream(diseaseTotals).sum();
        if (total <= 0) {
            double uniform = Math.log(1.0 / D);
            Arrays.fill(logPriors, uniform);
        } else {
            for (int di = 0; di < D; di++) {
                double prior = (diseaseTotals[di] + alpha) / (total + alpha * D);
                logPriors[di] = Math.log(prior);
            }
        }

        // Likelihoods with Laplace smoothing across symptoms
        logLikelihood = new double[D][S];
        for (int di = 0; di < D; di++) {
            double denom = diseaseTotals[di] + alpha * S;
            for (int si = 0; si < S; si++) {
                double num = symptomCounts[di][si] + alpha;
                logLikelihood[di][si] = Math.log(num / denom);
            }
        }
        modelBuilt.set(true);
    }

    public List<MlPredictionResult> predict(List<String> inputSymptoms, int topK) {
        rebuildModelIfNeeded();
        if (!modelBuilt.get())
            return Collections.emptyList();

        // Build input mask
        boolean[] x = new boolean[indexToSymptom.size()];
        for (String s : inputSymptoms) {
            Integer si = symptomIndex.get(s);
            if (si != null)
                x[si] = true;
        }

        // Score diseases: log posterior ~ logPrior + sum logLikelihood for present
        // symptoms
        double[] scores = new double[indexToDisease.size()];
        for (int di = 0; di < indexToDisease.size(); di++) {
            double score = logPriors[di];
            for (int si = 0; si < x.length; si++) {
                if (x[si])
                    score += logLikelihood[di][si];
            }
            scores[di] = score;
        }

        // Normalize via softmax for confidence-like percentage
        double max = Arrays.stream(scores).max().orElse(0);
        double sumExp = 0;
        double[] expScores = new double[scores.length];
        for (int i = 0; i < scores.length; i++) {
            expScores[i] = Math.exp(scores[i] - max);
            sumExp += expScores[i];
        }

        List<MlPredictionResult> results = new ArrayList<>();
        for (int di = 0; di < scores.length; di++) {
            double prob = sumExp > 0 ? (expScores[di] / sumExp) : 0.0;
            results.add(new MlPredictionResult(indexToDisease.get(di), prob * 100.0));
        }

        return results.stream()
                .sorted((a, b) -> Double.compare(b.confidence, a.confidence))
                .limit(Math.max(1, topK))
                .collect(Collectors.toList());
    }

    public HeatmapData buildHeatmapData(int topDiseases, int topSymptoms) {
        List<SymptomDiseaseCorrelation> correlations = dataCache.getCorrelations();
        if (correlations.isEmpty())
            return new HeatmapData(Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

        // Count top symptoms and diseases by frequency
        Map<String, Long> symFreq = correlations.stream()
                .collect(Collectors.groupingBy(c -> c.getSymptom().getName(), Collectors.counting()));
        Map<String, Long> disFreq = correlations.stream()
                .collect(Collectors.groupingBy(c -> c.getDisease().getName(), Collectors.counting()));

        List<String> topSym = symFreq.entrySet().stream()
                .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
                .limit(topSymptoms)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        List<String> topDis = disFreq.entrySet().stream()
                .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
                .limit(topDiseases)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        // Matrix entries (row = disease, col = symptom)
        List<Cell> cells = new ArrayList<>();
        Map<String, Integer> disIdx = new HashMap<>();
        Map<String, Integer> symIdx = new HashMap<>();
        for (int i = 0; i < topDis.size(); i++)
            disIdx.put(topDis.get(i), i);
        for (int j = 0; j < topSym.size(); j++)
            symIdx.put(topSym.get(j), j);

        // Use average correlationWeight when multiple entries
        Map<String, List<Double>> agg = new HashMap<>();
        for (SymptomDiseaseCorrelation c : correlations) {
            String d = c.getDisease().getName();
            String s = c.getSymptom().getName();
            if (!disIdx.containsKey(d) || !symIdx.containsKey(s))
                continue;
            String key = d + "||" + s;
            agg.computeIfAbsent(key, k -> new ArrayList<>())
                    .add(Optional.ofNullable(c.getCorrelationWeight()).orElse(0.0));
        }
        for (Map.Entry<String, List<Double>> e : agg.entrySet()) {
            String[] parts = e.getKey().split("\\|\\|");
            String d = parts[0];
            String s = parts[1];
            int i = disIdx.get(d);
            int j = symIdx.get(s);
            double avg = e.getValue().stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
            cells.add(new Cell(i, j, avg));
        }

        return new HeatmapData(topDis, topSym, cells);
    }

    // DTOs
    public static class MlPredictionResult {
        public final String diseaseName;
        public final double confidence; // 0..100

        public MlPredictionResult(String diseaseName, double confidence) {
            this.diseaseName = diseaseName;
            this.confidence = confidence;
        }
    }

    public static class HeatmapData {
        public final List<String> diseases; // rows
        public final List<String> symptoms; // cols
        public final List<Cell> cells; // entries

        public HeatmapData(List<String> diseases, List<String> symptoms, List<Cell> cells) {
            this.diseases = diseases;
            this.symptoms = symptoms;
            this.cells = cells;
        }
    }

    public static class Cell {
        public final int i; // row index (disease)
        public final int j; // col index (symptom)
        public final double value; // correlation strength

        public Cell(int i, int j, double value) {
            this.i = i;
            this.j = j;
            this.value = value;
        }
    }
}