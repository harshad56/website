# Requires: running app at http://localhost:8080

function Invoke-Json($method, $url, $json) {
  Invoke-WebRequest -Uri $url -Method $method -ContentType 'application/json' -Body $json | Select-Object -ExpandProperty Content
}

Write-Host 'Uploading expanded dataset (if needed)...'
try {
  $upload = Invoke-WebRequest -Uri 'http://localhost:8080/api/medical/upload/expanded' -Method POST -Form @{file=Get-Item 'expanded_disease_symptom_data.csv'} | Select-Object -ExpandProperty Content
  Write-Host $upload
} catch { Write-Host 'Upload skipped or failed (maybe already loaded).' }

# Scenarios
$scenarios = @(
  @{ name='Cardio Acute'; symptoms=@('Severe headache','Chest pain','Difficulty breathing'); age=52; gender='Male' },
  @{ name='Respiratory'; symptoms=@('Fever','Cough','Shortness of breath'); age=28; gender='Female' },
  @{ name='Neurological'; symptoms=@('Memory loss','Confusion','Sleep disturbances'); age=67; gender='Male' },
  @{ name='Digestive'; symptoms=@('Abdominal pain','Nausea','Vomiting'); age=34; gender='Female' }
)

foreach ($s in $scenarios) {
  Write-Host "`n=== Scenario: $($s.name) ===" -ForegroundColor Cyan
  $body = @{ symptoms=$s.symptoms; age=$s.age; gender=$s.gender } | ConvertTo-Json
  $resp = Invoke-Json POST 'http://localhost:8080/api/medical/predict' $body
  Write-Host $resp
}

Write-Host "`n=== Analytics (expanded) ===" -ForegroundColor Green
Invoke-WebRequest -Uri 'http://localhost:8080/api/medical/analytics/expanded' -UseBasicParsing | Select-Object -ExpandProperty Content
