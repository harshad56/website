package com.example.projectodsem3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.projectodsem3.model.Disease;
import com.example.projectodsem3.model.SymptomDiseaseCorrelation;

public interface SymptomDiseaseCorrelationRepository extends JpaRepository<SymptomDiseaseCorrelation, Long> {
	List<SymptomDiseaseCorrelation> findByDisease(Disease disease);
}
