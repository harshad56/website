package com.example.projectodsem3.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "symptom_disease_correlations")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SymptomDiseaseCorrelation {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "symptom_id", nullable = false)
    private Symptom symptom;
    
    @ManyToOne
    @JoinColumn(name = "disease_id", nullable = false)
    private Disease disease;
    
    @Column(nullable = false)
    private Double correlationWeight;
    
    @Column
    private Double confidence;
    
    @Column
    private String notes;
    
    @Column
    private Boolean isPrimarySymptom;
    
    @Column
    private Boolean isSecondarySymptom;
    
    @Column
    private Integer symptomOrder;
}
