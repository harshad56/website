package com.example.projectodsem3.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.projectodsem3.model.UserProfile;

@Repository
public interface UserProfileRepository extends JpaRepository<UserProfile, Long> {
    
    Optional<UserProfile> findByNameIgnoreCase(String name);
    
    List<UserProfile> findByAgeBetween(Integer minAge, Integer maxAge);
    
    List<UserProfile> findByBloodGroup(UserProfile.BloodGroup bloodGroup);
    
    List<UserProfile> findByGender(UserProfile.Gender gender);
    
    @Query("SELECT u FROM UserProfile u WHERE u.medicalHistory LIKE %:condition%")
    List<UserProfile> findByMedicalHistoryContaining(@Param("condition") String condition);
    
    @Query("SELECT u FROM UserProfile u WHERE u.allergies LIKE %:allergy%")
    List<UserProfile> findByAllergiesContaining(@Param("allergy") String allergy);
    
    @Query("SELECT COUNT(u) FROM UserProfile u WHERE u.bloodGroup = :bloodGroup")
    Long countByBloodGroup(@Param("bloodGroup") UserProfile.BloodGroup bloodGroup);
    
    @Query("SELECT AVG(u.age) FROM UserProfile u")
    Double getAverageAge();
}
