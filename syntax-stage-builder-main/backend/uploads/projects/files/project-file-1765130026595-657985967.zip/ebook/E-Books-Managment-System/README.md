# E Books Managment System
 This project is a web application developed using Maven as a build automation and dependency management tool. The main focus of this project is on server-side development, leveraging JSP and Servlets to handle requests and generate dynamic content. The backend logic written in Java with Servlets handles the communication with the database.

### Design
<p align="center">
  <img src="https://github.com/Mahelchandupa/E-Books-Managment-System/assets/110615431/fedf17c8-021b-4c64-94ea-df5d04c807bd" width="250" alt="Screenshot 1">
  <img src="https://github.com/Mahelchandupa/E-Books-Managment-System/assets/110615431/2a4e3d3f-dcc6-4772-9350-6383f8b6cf05" width="250" alt="Screenshot 2">
  <img src="https://github.com/Mahelchandupa/E-Books-Managment-System/assets/110615431/ddbdcf59-06fd-4c9f-bc6f-ceca9e2edf1e" width="250" alt="Screenshot 2">
</p>
