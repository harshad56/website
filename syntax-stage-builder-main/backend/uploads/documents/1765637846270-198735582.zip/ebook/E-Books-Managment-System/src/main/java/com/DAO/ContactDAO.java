package com.DAO;

import com.entity.Contact;

public interface ContactDAO {
    public boolean contactData(Contact cs);

}
